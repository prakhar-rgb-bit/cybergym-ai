package com.example.engine

import com.example.model.TrafficFeature
import kotlin.random.Random

object FeatureExtractor {

    fun extractFeatures(
        packetCount: Long,
        packetRate: Double,
        byteRate: Double,
        failedConns: Int,
        dstPort: Int,
        protocol: String,
        isUnderAttack: Boolean = false,
        attackTypeHint: String = "NORMAL"
    ): TrafficFeature {
        val srcEntropy = if (isUnderAttack && attackTypeHint == "DDOS") Random.nextInt(120, 850) else Random.nextInt(5, 30)
        val connDuration = when (attackTypeHint) {
            "DDOS" -> Random.nextLong(20L, 80L)
            "PORT_SCAN" -> Random.nextLong(5L, 30L)
            "BRUTE_FORCE" -> Random.nextLong(150L, 400L)
            "DATA_EXFILTRATION" -> Random.nextLong(3500L, 12000L)
            else -> Random.nextLong(180L, 600L)
        }

        val tcpFlags = when (attackTypeHint) {
            "DDOS" -> "SYN, ACK (High SYN Burst)"
            "PORT_SCAN" -> "SYN, FIN, NULL (Stealth Scan)"
            "BRUTE_FORCE" -> "PSH, ACK (Auth Payloads)"
            "DATA_EXFILTRATION" -> "PSH, ACK (Egress Stream)"
            else -> "ACK, PSH (Standard HTTP/TLS)"
        }

        val avgPacketSize = when (attackTypeHint) {
            "DDOS" -> Random.nextInt(64, 256)
            "DATA_EXFILTRATION" -> Random.nextInt(1400, 1500)
            else -> Random.nextInt(500, 1100)
        }

        return TrafficFeature(
            packetCount = packetCount,
            packetRate = packetRate,
            byteRate = byteRate,
            srcIpFrequency = srcEntropy,
            dstIpFrequency = if (attackTypeHint == "DDOS") 1 else Random.nextInt(2, 8),
            srcPort = Random.nextInt(40000, 65535),
            dstPort = dstPort,
            protocol = protocol,
            connectionDuration = connDuration,
            failedConnections = failedConns,
            tcpFlags = tcpFlags,
            flowDuration = Random.nextLong(3000L, 15000L),
            packetSize = avgPacketSize,
            requestFrequency = packetRate / 15.0
        )
    }
}
