package com.example.engine

import com.example.model.AnomalyClassification
import com.example.model.AnomalyResult
import com.example.model.TrafficFeature
import kotlin.math.min

object AnomalyDetectionEngine {

    /**
     * Simulates an Isolation Forest anomaly scoring pipeline on extracted flow features.
     * Evaluates multi-dimensional anomaly paths against baseline statistical distributions.
     */
    fun evaluateAnomaly(feature: TrafficFeature): AnomalyResult {
        var rawAnomalyScore = 12.0
        val contributing = mutableListOf<String>()

        // 1. Packet Rate anomaly (Baseline ~100-300 PPS)
        if (feature.packetRate > 2500.0) {
            rawAnomalyScore += 45.0
            contributing.add("Severe packet surge: ${(feature.packetRate / 200.0).format(1)}x baseline threshold")
        } else if (feature.packetRate > 900.0) {
            rawAnomalyScore += 25.0
            contributing.add("Elevated packet frequency: ${feature.packetRate.toInt()} PPS")
        }

        // 2. Failed connection burst (Baseline < 5)
        if (feature.failedConnections > 25) {
            rawAnomalyScore += 28.0
            contributing.add("Unusual connection failure spike (${feature.failedConnections} drops/sec)")
        } else if (feature.failedConnections > 8) {
            rawAnomalyScore += 14.0
            contributing.add("Moderate failed connection rate (${feature.failedConnections} drops/sec)")
        }

        // 3. Source IP distribution entropy
        if (feature.srcIpFrequency > 100) {
            rawAnomalyScore += 22.0
            contributing.add("High source IP dispersion (${feature.srcIpFrequency} unique sources targeting single host)")
        }

        // 4. Abnormal TCP flags
        if (feature.tcpFlags.contains("SYN Burst") || feature.tcpFlags.contains("Stealth Scan")) {
            rawAnomalyScore += 18.0
            contributing.add("Abnormal TCP flag signature: ${feature.tcpFlags}")
        }

        // 5. Byte rate egress/ingress anomaly
        if (feature.byteRate > 1500.0) {
            rawAnomalyScore += 20.0
            contributing.add("Egress byte velocity outlier (${feature.byteRate.toInt()} KB/s)")
        }

        val finalScore = min(99.0, rawAnomalyScore)
        val classification = when {
            finalScore >= 75.0 -> AnomalyClassification.CRITICAL
            finalScore >= 50.0 -> AnomalyClassification.HIGHLY_SUSPICIOUS
            finalScore >= 30.0 -> AnomalyClassification.SUSPICIOUS
            else -> AnomalyClassification.NORMAL
        }

        if (contributing.isEmpty()) {
            contributing.add("Traffic parameters within nominal isolation tree bounds")
            contributing.add("Uniform packet interval and valid handshake sequence")
        }

        return AnomalyResult(
            anomalyScore = finalScore,
            classification = classification,
            contributingFeatures = contributing,
            isAnomaly = finalScore >= 45.0
        )
    }

    private fun Double.format(digits: Int) = String.format("%.${digits}f", this)
}
