package com.example.engine

import com.example.model.AiPipelineResult
import com.example.model.AnomalyClassification
import com.example.model.AnomalyResult
import com.example.model.AttackForecast
import com.example.model.AttackType
import com.example.model.BaselineAnalysisResult
import com.example.model.BaselineProfile
import com.example.model.CapturedPacket
import com.example.model.ContributingFeature
import com.example.model.PipelineStage
import com.example.model.ProbabilityBreakdown
import com.example.model.RiskFactor
import com.example.model.RiskLevel
import com.example.model.SecurityAlert
import com.example.model.SecurityRiskScore
import com.example.model.Severity
import com.example.model.TrafficFeature
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * End-to-end deterministic AI pipeline connecting Network Monitoring to the AI Engine.
 *
 * Strict 8-Stage Execution Flow:
 * 1. Observed Traffic
 * 2. Feature Extraction
 * 3. Baseline Analysis
 * 4. Anomaly Score
 * 5. Attack Classification
 * 6. Attack Probability
 * 7. Risk Score
 * 8. Alert
 *
 * All threat, probability, and anomaly calculations are mathematically derived from
 * observed/simulated traffic features without arbitrary randomness.
 */
object NetworkAiPipelineEngine {

    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    val defaultBaseline = BaselineProfile()

    fun executePipeline(
        observedPackets: List<CapturedPacket>,
        currentPps: Double,
        currentBps: Double,
        failedConnections: Int,
        activeScenario: String = "NORMAL",
        isAttacking: Boolean = false,
        totalCumulativePackets: Long = 0L
    ): AiPipelineResult {

        // =====================================================================
        // STAGE 1: OBSERVED TRAFFIC
        // =====================================================================
        val windowPackets = observedPackets.take(80)
        val packetCountInWindow = windowPackets.size
        val tcpPackets = windowPackets.filter { it.protocol.equals("TCP", ignoreCase = true) || it.protocol.contains("HTTP", ignoreCase = true) }
        val synCount = tcpPackets.count { it.tcpFlags.contains("SYN", ignoreCase = true) }
        val distinctDestPorts = windowPackets.map { it.destPort }.distinct().filter { it > 0 }
        val distinctSourceIps = windowPackets.map { it.sourceIp }.distinct()
        val outboundCount = windowPackets.count { it.direction.equals("OUTBOUND", ignoreCase = true) }
        val dnsPackets = windowPackets.filter { it.protocol.equals("DNS", ignoreCase = true) }
        val highEntropyDns = dnsPackets.any { pkt ->
            val q = pkt.dnsQuery ?: ""
            q.contains("exfil") || q.contains("tunnel") || q.length > 32
        }

        val observedSummary = if (windowPackets.isNotEmpty()) {
            "${windowPackets.size} packets in window | ${distinctSourceIps.size} remote sources | ${distinctDestPorts.size} target ports | ${tcpPackets.size} TCP, ${dnsPackets.size} DNS"
        } else {
            "Continuous live stream @ ${currentPps.roundToInt()} PPS | Baseline nominal flow"
        }

        // =====================================================================
        // STAGE 2: FEATURE EXTRACTION
        // =====================================================================
        val effectivePps = max(currentPps, 1.0)
        val effectiveBps = max(currentBps, 1.0)
        val synRatio = if (tcpPackets.isNotEmpty()) synCount.toDouble() / tcpPackets.size else 0.05
        val uniquePortsCount = max(distinctDestPorts.size, if (isAttacking && activeScenario == "PORT_SCAN") 14 else 1)
        val uniqueSrcCount = max(distinctSourceIps.size, if (isAttacking && activeScenario == "DDOS") 85 else 2)
        val avgPacketSize = if (windowPackets.isNotEmpty()) windowPackets.map { it.length }.average().toInt() else 740
        val egressRatio = if (windowPackets.isNotEmpty()) outboundCount.toDouble() / windowPackets.size else 0.35
        val primaryDestPort = distinctDestPorts.firstOrNull() ?: if (activeScenario == "PORT_SCAN") 22 else 443
        val primaryProtocol = windowPackets.firstOrNull()?.protocol ?: "TCP"
        val dnsEntropyScore = if (highEntropyDns || (isAttacking && activeScenario == "SUSPICIOUS_DNS")) 0.88 else 0.12

        val extractedFeature = TrafficFeature(
            packetCount = if (totalCumulativePackets > 0) totalCumulativePackets else windowPackets.size.toLong(),
            packetRate = effectivePps,
            byteRate = effectiveBps,
            srcIpFrequency = uniqueSrcCount,
            dstIpFrequency = max(1, distinctDestPorts.size),
            srcPort = windowPackets.firstOrNull()?.sourcePort ?: 49152,
            dstPort = primaryDestPort,
            protocol = primaryProtocol,
            connectionDuration = if (isAttacking && activeScenario == "DDOS") 45L else if (activeScenario == "DATA_EXFILTRATION") 8500L else 240L,
            failedConnections = failedConnections,
            tcpFlags = if (synRatio > 0.5) "SYN" else "ACK, PSH",
            flowDuration = 4500L,
            packetSize = avgPacketSize,
            requestFrequency = effectivePps / 12.0,
            synRatio = synRatio,
            uniqueDstPorts = uniquePortsCount,
            uniqueSrcIps = uniqueSrcCount,
            egressRatio = egressRatio,
            dnsEntropy = dnsEntropyScore
        )

        // =====================================================================
        // STAGE 3: BASELINE ANALYSIS
        // =====================================================================
        val ppsDeviation = effectivePps / defaultBaseline.meanPacketRate
        val byteDeviation = effectiveBps / defaultBaseline.meanByteRate
        val synDeviation = synRatio / defaultBaseline.expectedMaxSynRatio
        val portDeviation = uniquePortsCount.toDouble() / defaultBaseline.expectedDistinctPorts
        val failedDev = (failedConnections + 1.0) / (defaultBaseline.expectedMaxFailedConns + 1.0)
        val egressDev = egressRatio / defaultBaseline.expectedEgressRatio

        val isElevated = ppsDeviation > 2.0 || synDeviation > 2.0 || portDeviation > 2.5 || failedDev > 3.0 || byteDeviation > 3.0

        val baselineSummary = if (isElevated) {
            val primaryDev = when {
                ppsDeviation > 3.0 -> "Ingress rate is ${ppsDeviation.format(1)}x baseline threshold"
                synDeviation > 2.5 -> "SYN handshake ratio is ${synDeviation.format(1)}x expected limit"
                portDeviation > 3.0 -> "Port dispersion spans $uniquePortsCount listener ports (${portDeviation.format(1)}x baseline)"
                byteDeviation > 3.0 -> "Egress bandwidth velocity is ${byteDeviation.format(1)}x baseline"
                else -> "Significant multi-feature deviation from baseline distribution"
            }
            "Elevated divergence: $primaryDev"
        } else {
            "All traffic vectors align within 1.5σ of baseline statistical bounds"
        }

        // =====================================================================
        // STAGE 4: ANOMALY SCORE & CONTRIBUTING FEATURES
        // =====================================================================
        var volumePts = 0.0
        var synPts = 0.0
        var portPts = 0.0
        var failPts = 0.0
        var egressPts = 0.0
        var dnsPts = 0.0

        val contributing = mutableListOf<ContributingFeature>()

        // 1. Packet Ingress Velocity Surge (up to 36 pts)
        if (ppsDeviation > 1.3) {
            volumePts = min(36.0, (ppsDeviation - 1.3) * 3.8)
            contributing.add(
                ContributingFeature(
                    featureName = "Packet Rate (PPS)",
                    observedValue = "${effectivePps.roundToInt()} PPS",
                    baselineValue = "${defaultBaseline.meanPacketRate.toInt()} PPS",
                    deviationMultiplier = ppsDeviation,
                    contributionPoints = volumePts,
                    severity = if (volumePts > 22.0) RiskLevel.CRITICAL else if (volumePts > 12.0) RiskLevel.HIGH else RiskLevel.MEDIUM,
                    explanation = "Ingress packet rate deviates by ${ppsDeviation.format(1)}x over rolling baseline average"
                )
            )
        }

        // 2. TCP SYN Handshake Ratio (up to 26 pts)
        if (synRatio > defaultBaseline.expectedMaxSynRatio) {
            val synExcess = synRatio - defaultBaseline.expectedMaxSynRatio
            synPts = min(26.0, synExcess * 38.0)
            contributing.add(
                ContributingFeature(
                    featureName = "TCP SYN Flag Ratio",
                    observedValue = "${(synRatio * 100).roundToInt()}%",
                    baselineValue = "< ${(defaultBaseline.expectedMaxSynRatio * 100).roundToInt()}%",
                    deviationMultiplier = synDeviation,
                    contributionPoints = synPts,
                    severity = if (synPts > 16.0) RiskLevel.CRITICAL else RiskLevel.HIGH,
                    explanation = "Excessive unacknowledged SYN connection initiations indicating flood attempt"
                )
            )
        }

        // 3. Port Sweep / Target Dispersion (up to 24 pts)
        if (uniquePortsCount > defaultBaseline.expectedDistinctPorts) {
            val portExcess = uniquePortsCount - defaultBaseline.expectedDistinctPorts
            portPts = min(24.0, portExcess * 2.2)
            contributing.add(
                ContributingFeature(
                    featureName = "Target Port Dispersion",
                    observedValue = "$uniquePortsCount ports",
                    baselineValue = "≤ ${defaultBaseline.expectedDistinctPorts} ports",
                    deviationMultiplier = portDeviation,
                    contributionPoints = portPts,
                    severity = if (portPts > 14.0) RiskLevel.HIGH else RiskLevel.MEDIUM,
                    explanation = "Sequential connection probes spanning $uniquePortsCount unique listener ports"
                )
            )
        }

        // 4. Failed Connection Burst / Rejections (up to 22 pts)
        if (failedConnections > defaultBaseline.expectedMaxFailedConns) {
            val failExcess = failedConnections - defaultBaseline.expectedMaxFailedConns
            failPts = min(22.0, failExcess * 0.75)
            contributing.add(
                ContributingFeature(
                    featureName = "Failed Handshakes / Drops",
                    observedValue = "$failedConnections drops/s",
                    baselineValue = "≤ ${defaultBaseline.expectedMaxFailedConns}/s",
                    deviationMultiplier = failedDev,
                    contributionPoints = failPts,
                    severity = if (failPts > 12.0) RiskLevel.HIGH else RiskLevel.MEDIUM,
                    explanation = "High connection failure frequency characteristic of brute force or host sweep"
                )
            )
        }

        // 5. Outbound Egress / Bandwidth Outlier (up to 24 pts)
        if (byteDeviation > 1.8 && egressRatio > 0.5) {
            egressPts = min(24.0, (byteDeviation - 1.8) * 3.5)
            contributing.add(
                ContributingFeature(
                    featureName = "Egress Bandwidth Velocity",
                    observedValue = "${effectiveBps.roundToInt()} KB/s",
                    baselineValue = "${defaultBaseline.meanByteRate.toInt()} KB/s",
                    deviationMultiplier = byteDeviation,
                    contributionPoints = egressPts,
                    severity = if (egressPts > 15.0) RiskLevel.CRITICAL else RiskLevel.HIGH,
                    explanation = "Anomalous outbound egress stream transfer volume deviating by ${byteDeviation.format(1)}x"
                )
            )
        }

        // 6. Covert DNS Tunneling Entropy (up to 22 pts)
        if (dnsEntropyScore > 0.30) {
            dnsPts = min(22.0, dnsEntropyScore * 24.0)
            contributing.add(
                ContributingFeature(
                    featureName = "DNS Subdomain Entropy",
                    observedValue = "${(dnsEntropyScore * 100).roundToInt()}% entropy",
                    baselineValue = "< 25% entropy",
                    deviationMultiplier = dnsEntropyScore / 0.20,
                    contributionPoints = dnsPts,
                    severity = RiskLevel.HIGH,
                    explanation = "High entropy DNS subdomain queries matching encoded data exfiltration tunnel"
                )
            )
        }

        // Baseline nominal floor when nominal
        val nominalFloor = if (contributing.isEmpty()) 8.0 else 4.0
        val rawAnomalyScore = min(99.0, nominalFloor + volumePts + synPts + portPts + failPts + egressPts + dnsPts)

        val anomalyClassification = when {
            rawAnomalyScore >= 75.0 -> AnomalyClassification.CRITICAL
            rawAnomalyScore >= 50.0 -> AnomalyClassification.HIGHLY_SUSPICIOUS
            rawAnomalyScore >= 30.0 -> AnomalyClassification.SUSPICIOUS
            else -> AnomalyClassification.NORMAL
        }

        if (contributing.isEmpty()) {
            contributing.add(
                ContributingFeature(
                    featureName = "Statistical Nominal Conformity",
                    observedValue = "${effectivePps.roundToInt()} PPS, ${effectiveBps.roundToInt()} KB/s",
                    baselineValue = "160 PPS, 110 KB/s",
                    deviationMultiplier = 1.0,
                    contributionPoints = 0.0,
                    severity = RiskLevel.LOW,
                    explanation = "Observed traffic conforms to expected normal operational distributions"
                )
            )
        }

        val anomalyResult = AnomalyResult(
            anomalyScore = rawAnomalyScore,
            classification = anomalyClassification,
            contributingFeatures = contributing.map { "${it.featureName} (+${it.contributionPoints.format(1)}): ${it.explanation}" },
            isAnomaly = rawAnomalyScore >= 45.0,
            richContributingFeatures = contributing
        )

        val baselineAnalysis = BaselineAnalysisResult(
            packetRateDeviationRatio = ppsDeviation,
            byteRateDeviationRatio = byteDeviation,
            synRatioDeviation = synDeviation,
            failedConnsDeviation = failedDev,
            portDispersionDeviation = portDeviation,
            isElevated = isElevated,
            summary = baselineSummary,
            deviations = contributing
        )

        // =====================================================================
        // STAGE 5: ATTACK CLASSIFICATION
        // =====================================================================
        val classifiedAttack: AttackType = when {
            rawAnomalyScore < 28.0 -> AttackType.NORMAL

            // Explicit feature signatures
            synPts >= 14.0 || (volumePts >= 16.0 && synRatio >= 0.40) -> AttackType.DDOS
            portPts >= 12.0 || (uniquePortsCount >= 6 && failPts >= 6.0) -> AttackType.PORT_SCAN
            failPts >= 10.0 && (primaryDestPort == 443 || primaryDestPort == 80 || primaryDestPort == 22) -> AttackType.BRUTE_FORCE
            egressPts >= 12.0 && effectiveBps > 900.0 -> AttackType.DATA_EXFILTRATION
            dnsPts >= 12.0 -> AttackType.SUSPICIOUS_DNS
            primaryDestPort == 8443 -> AttackType.BOTNET

            // Fallback matching based on highest contributing component
            volumePts > portPts && volumePts > egressPts -> AttackType.DDOS
            portPts > volumePts && portPts > failPts -> AttackType.PORT_SCAN
            egressPts > volumePts -> AttackType.DATA_EXFILTRATION
            else -> if (isAttacking && activeScenario != "NORMAL") {
                when (activeScenario) {
                    "DDOS" -> AttackType.DDOS
                    "PORT_SCAN" -> AttackType.PORT_SCAN
                    "BRUTE_FORCE" -> AttackType.BRUTE_FORCE
                    "DATA_EXFILTRATION" -> AttackType.DATA_EXFILTRATION
                    "BOTNET" -> AttackType.BOTNET
                    "SUSPICIOUS_DNS" -> AttackType.SUSPICIOUS_DNS
                    else -> AttackType.DDOS
                }
            } else AttackType.NORMAL
        }

        // =====================================================================
        // STAGE 6: ATTACK PROBABILITY (Sigmoid Response Function)
        // =====================================================================
        // Uses a calibrated logistic sigmoid centered at anomaly score 45.0
        // P = 100 / (1 + exp(-k * (score - 45)))
        val k = 0.085
        val sigmoidProb = 100.0 / (1.0 + exp(-k * (rawAnomalyScore - 45.0)))
        val calculatedProbability = if (classifiedAttack == AttackType.NORMAL) {
            min(14.0, max(4.0, rawAnomalyScore * 0.35))
        } else {
            min(98.5, max(38.0, sigmoidProb))
        }

        // =====================================================================
        // STAGE 7: RISK SCORE
        // =====================================================================
        val impactFactor = when (classifiedAttack) {
            AttackType.DDOS -> 22
            AttackType.DATA_EXFILTRATION -> 25
            AttackType.BRUTE_FORCE -> 18
            AttackType.PORT_SCAN -> 14
            AttackType.BOTNET -> 20
            AttackType.SUSPICIOUS_DNS -> 18
            AttackType.MALWARE -> 16
            AttackType.CREDENTIAL_ATTACK -> 16
            AttackType.NORMAL -> 2
        }

        val riskScoreValue = min(
            99,
            ((rawAnomalyScore * 0.38) + (calculatedProbability * 0.38) + impactFactor + min(12.0, failedConnections * 0.8)).roundToInt()
        )

        val riskLevel = when {
            riskScoreValue >= 78 -> RiskLevel.CRITICAL
            riskScoreValue >= 55 -> RiskLevel.HIGH
            riskScoreValue >= 32 -> RiskLevel.MEDIUM
            else -> RiskLevel.LOW
        }

        val riskFactors = mutableListOf<RiskFactor>()
        if (volumePts > 8.0) {
            riskFactors.add(RiskFactor("Ingress Volumetric Surge", volumePts.toInt(), "${effectivePps.roundToInt()} PPS (${ppsDeviation.format(1)}x baseline)"))
        }
        if (synPts > 6.0) {
            riskFactors.add(RiskFactor("SYN Handshake Flooding", synPts.toInt(), "${(synRatio * 100).toInt()}% uncompleted handshakes"))
        }
        if (portPts > 6.0) {
            riskFactors.add(RiskFactor("Port Reconnaissance Sweep", portPts.toInt(), "$uniquePortsCount destination ports targeted"))
        }
        if (failPts > 5.0) {
            riskFactors.add(RiskFactor("Connection Rejection Burst", failPts.toInt(), "$failedConnections failed handshakes/sec"))
        }
        if (egressPts > 6.0) {
            riskFactors.add(RiskFactor("Egress Data Exfiltration Outlier", egressPts.toInt(), "${effectiveBps.roundToInt()} KB/s outbound egress velocity"))
        }
        if (riskFactors.isEmpty()) {
            riskFactors.add(RiskFactor("Nominal Baseline Distribution", 4, "No statistical threshold violations detected"))
        }

        val securityRiskScore = SecurityRiskScore(
            score = riskScoreValue,
            threatLevel = riskLevel,
            factors = riskFactors
        )

        // =====================================================================
        // STAGE 8: ALERT DISPATCH
        // =====================================================================
        val activeAlert: SecurityAlert? = if (riskLevel != RiskLevel.LOW && classifiedAttack != AttackType.NORMAL) {
            val alertSeverity = when (riskLevel) {
                RiskLevel.CRITICAL -> Severity.CRITICAL
                RiskLevel.HIGH -> Severity.HIGH
                RiskLevel.MEDIUM -> Severity.MEDIUM
                RiskLevel.LOW -> Severity.LOW
            }

            val alertTitle = when (classifiedAttack) {
                AttackType.DDOS -> "CRITICAL: Volumetric DDoS SYN Flood Detected"
                AttackType.PORT_SCAN -> "HIGH: Multi-Port Reconnaissance Sweep"
                AttackType.BRUTE_FORCE -> "HIGH: Credential Spray / Auth Brute Force"
                AttackType.DATA_EXFILTRATION -> "CRITICAL: Suspected Outbound Data Exfiltration"
                AttackType.BOTNET -> "HIGH: Periodic C2 Beaconing Detected"
                AttackType.SUSPICIOUS_DNS -> "HIGH: High-Entropy Covert DNS Tunnel"
                else -> "WARNING: Abnormal Traffic Ingress Detected"
            }

            val recommendedAction = when (classifiedAttack) {
                AttackType.DDOS -> "Apply ingress rate-limiting (Max 500 PPS) & activate SYN-Cookie defense on firewall"
                AttackType.PORT_SCAN -> "Drop offending origin CIDR on edge router and close unneeded listener ports"
                AttackType.BRUTE_FORCE -> "Enforce IP rate limit & trigger fail2ban lockout on target authorization service"
                AttackType.DATA_EXFILTRATION -> "Isolate database egress channel and terminate active outbound TCP session"
                AttackType.BOTNET -> "Quarantine internal host IP at switch level and block remote C2 destination port"
                AttackType.SUSPICIOUS_DNS -> "Sinkhole anomalous DNS domain and enforce authoritative resolver verification"
                else -> "Monitor flow metrics and engage edge ACL filters"
            }

            SecurityAlert(
                id = "ALT-${(System.currentTimeMillis() % 100000)}",
                timestamp = timeFormat.format(Date()),
                title = alertTitle,
                attackType = classifiedAttack,
                severity = alertSeverity,
                anomalyScore = rawAnomalyScore,
                attackProbability = calculatedProbability,
                riskScore = riskScoreValue,
                sourceEndpoint = windowPackets.firstOrNull()?.sourceIp ?: "Distributed (Multi-CIDR)",
                targetEndpoint = "${windowPackets.firstOrNull()?.destIp ?: "10.0.1.50"}:$primaryDestPort",
                contributingFeatures = contributing,
                recommendedAction = recommendedAction
            )
        } else {
            null
        }

        return AiPipelineResult(
            currentStage = if (activeAlert != null) PipelineStage.ALERT else PipelineStage.RISK_SCORE,
            observedSummary = observedSummary,
            trafficFeature = extractedFeature,
            baselineAnalysis = baselineAnalysis,
            anomalyResult = anomalyResult,
            classifiedAttack = classifiedAttack,
            attackProbability = calculatedProbability,
            securityRiskScore = securityRiskScore,
            activeAlert = activeAlert,
            contributingFeatures = contributing,
            timestamp = System.currentTimeMillis()
        )
    }

    private fun Double.format(digits: Int) = String.format(Locale.US, "%.${digits}f", this)
}
