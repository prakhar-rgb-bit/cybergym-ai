package com.example.engine

import com.example.model.AnomalyResult
import com.example.model.AttackForecast
import com.example.model.AttackType
import com.example.model.RiskFactor
import com.example.model.RiskLevel
import com.example.model.SecurityRiskScore
import com.example.model.TrafficFeature
import kotlin.math.min

object RiskEngine {

    fun calculateRiskScore(
        feature: TrafficFeature,
        anomaly: AnomalyResult,
        forecast: AttackForecast,
        failedConns: Int
    ): SecurityRiskScore {
        var baseScore = 18
        val factors = mutableListOf<RiskFactor>()

        // 1. Traffic Anomaly factor
        if (anomaly.anomalyScore > 60.0) {
            val weight = 22
            baseScore += weight
            factors.add(RiskFactor("Severe Traffic Anomaly", weight, "Isolation forest score ${anomaly.anomalyScore.toInt()}/100 exceeds baseline threshold"))
        } else if (anomaly.anomalyScore > 35.0) {
            val weight = 12
            baseScore += weight
            factors.add(RiskFactor("Elevated Traffic Variation", weight, "Packet frequency and flag entropy deviate from nominal profile"))
        }

        // 2. Connection Spike factor
        if (feature.packetRate > 2000.0) {
            val weight = 20
            baseScore += weight
            factors.add(RiskFactor("Volumetric Connection Spike", weight, "Ingress rate reached ${feature.packetRate.toInt()} PPS (${(feature.packetRate / 180).toInt()}x baseline)"))
        } else if (feature.packetRate > 800.0) {
            val weight = 10
            baseScore += weight
            factors.add(RiskFactor("Moderate Connection Ingress", weight, "Packet rate above 800 PPS"))
        }

        // 3. Unusual Port Behavior / Reconnaissance
        if (feature.dstPort != 443 && feature.dstPort != 80 && feature.dstPort != 53) {
            val weight = 12
            baseScore += weight
            factors.add(RiskFactor("Unusual Port Target", weight, "Traffic targeting non-standard listener port :${feature.dstPort}"))
        }

        // 4. Repeated Connection / Drop Pattern
        if (failedConns > 15) {
            val weight = 16
            baseScore += weight
            factors.add(RiskFactor("Failed Connection Surge", weight, "$failedConns rejected handshakes/sec indicating brute force or sweep"))
        } else if (failedConns > 5) {
            val weight = 8
            baseScore += weight
            factors.add(RiskFactor("Intermittent Handshake Drops", weight, "$failedConns dropped connections/sec"))
        }

        // 5. Forecasted Vector Threat Factor
        if (forecast.attackType != AttackType.NORMAL && forecast.probability > 70.0) {
            val weight = 18
            baseScore += weight
            factors.add(RiskFactor("Known Threat Pattern: ${forecast.attackType.displayName}", weight, "AI attack probability elevated at ${forecast.probability.toInt()}%"))
        } else if (forecast.attackType != AttackType.NORMAL && forecast.probability > 40.0) {
            val weight = 10
            baseScore += weight
            factors.add(RiskFactor("Emerging Threat Vector: ${forecast.attackType.displayName}", weight, "Probabilistic estimate ${forecast.probability.toInt()}%"))
        }

        val finalScore = min(98, baseScore)
        val level = when {
            finalScore >= 75 -> RiskLevel.CRITICAL
            finalScore >= 55 -> RiskLevel.HIGH
            finalScore >= 35 -> RiskLevel.MEDIUM
            else -> RiskLevel.LOW
        }

        if (factors.isEmpty()) {
            factors.add(RiskFactor("Baseline Nominal Traffic", 5, "Standard TLS/DNS handshakes with zero security breaches"))
        }

        return SecurityRiskScore(
            score = finalScore,
            threatLevel = level,
            factors = factors
        )
    }
}
