package com.example.engine

import com.example.model.AttackType
import com.example.model.DefenseAction
import com.example.model.DefenseEvaluation
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

object DefenseEvaluator {

    fun evaluateDefense(
        activeThreat: AttackType,
        chosenAction: DefenseAction,
        elapsedSeconds: Double
    ): DefenseEvaluation {
        val isOptimal = when (activeThreat) {
            AttackType.DDOS -> chosenAction.id in listOf("rate_limit", "block_ip", "firewall_rule")
            AttackType.PORT_SCAN -> chosenAction.id in listOf("block_ip", "block_port", "firewall_rule")
            AttackType.BRUTE_FORCE -> chosenAction.id in listOf("block_ip", "rate_limit", "firewall_rule")
            AttackType.DATA_EXFILTRATION -> chosenAction.id in listOf("isolate_host", "block_ip", "firewall_rule")
            AttackType.BOTNET -> chosenAction.id in listOf("isolate_host", "block_ip", "deep_packet")
            AttackType.MALWARE -> chosenAction.id in listOf("isolate_host", "investigate_logs")
            else -> true
        }

        // Response time score (penalty for > 10 seconds)
        val responseScore = max(60.0, 100.0 - (elapsedSeconds * 3.5))
        val decisionQuality = if (isOptimal) Random.nextDouble(88.0, 96.0) else Random.nextDouble(55.0, 70.0)
        val detectionAccuracy = if (isOptimal) Random.nextDouble(91.0, 97.0) else Random.nextDouble(65.0, 78.0)
        val damagePrevented = if (isOptimal) max(75.0, 100.0 - (elapsedSeconds * 2.0)) else Random.nextDouble(40.0, 60.0)
        val defenseEffectiveness = if (isOptimal) (chosenAction.effectivenessScore * 0.95) + Random.nextDouble(1.0, 4.0) else 58.0

        val finalScore = ((decisionQuality * 0.3) + (detectionAccuracy * 0.25) + (damagePrevented * 0.25) + (responseScore * 0.2)).toInt()

        val badge = when {
            elapsedSeconds <= 3.0 && isOptimal -> "Fast Responder"
            finalScore >= 92 -> "Perfect Defense"
            activeThreat == AttackType.DDOS && isOptimal -> "DDoS Defender"
            activeThreat == AttackType.PORT_SCAN && isOptimal -> "Threat Hunter"
            else -> null
        }

        val aiFeedback = if (isOptimal) {
            "Excellent tactical execution! Applied '${chosenAction.name}' within ${elapsedSeconds.format(1)}s of forecast alert. Threat vector neutralized with minimal impact to core services."
        } else {
            "Action '${chosenAction.name}' provided partial mitigation, but an isolation or rate-limiting control would have contained the attack vector faster with less collateral degradation."
        }

        return DefenseEvaluation(
            detectionAccuracy = detectionAccuracy,
            responseTimeSeconds = elapsedSeconds,
            defenseEffectiveness = defenseEffectiveness,
            damagePrevented = damagePrevented,
            decisionQuality = decisionQuality,
            finalScore = min(100, finalScore),
            aiFeedback = aiFeedback,
            badgeUnlocked = badge
        )
    }

    private fun Double.format(digits: Int) = String.format("%.${digits}f", this)
}
