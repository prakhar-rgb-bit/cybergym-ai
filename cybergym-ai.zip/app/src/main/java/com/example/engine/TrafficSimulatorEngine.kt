package com.example.engine

import com.example.model.AttackType
import com.example.model.CapturedPacket
import com.example.model.RiskLevel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong
import kotlin.random.Random

object TrafficSimulatorEngine {

    private val counter = AtomicLong(100L)
    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    private val normalDomains = listOf("api.github.com", "android.clients.google.com", "connectivitycheck.gstatic.com", "soc.cybergym.io", "cdn.cloudflare.net")
    private val remoteServers = listOf("142.250.190.46", "104.244.42.1", "151.101.65.140", "185.199.108.153", "8.8.8.8")
    private val localDeviceIp = "192.168.1.45"
    private val gatewayIp = "192.168.1.1"

    fun generatePacket(scenario: String = "NORMAL", stepIndex: Int = 0): CapturedPacket {
        val id = counter.incrementAndGet()
        val time = timeFormat.format(Date())

        return when (scenario) {
            "DDOS" -> {
                val randOrigin = "${Random.nextInt(45, 200)}.${Random.nextInt(1, 254)}.${Random.nextInt(1, 254)}.${Random.nextInt(1, 254)}"
                val dstPort = if (Random.nextBoolean()) 443 else 80
                CapturedPacket(
                    id = id,
                    packetNumber = id,
                    timestamp = time,
                    protocol = "TCP",
                    sourceIp = randOrigin,
                    destIp = "10.0.1.50",
                    sourcePort = Random.nextInt(49152, 65530),
                    destPort = dstPort,
                    length = Random.nextInt(64, 128),
                    status = "ATTACK_BURST",
                    riskLevel = RiskLevel.CRITICAL,
                    anomalyScore = 92.0 + Random.nextDouble(0.0, 6.0),
                    tcpFlags = "SYN",
                    direction = "INBOUND",
                    info = "TCP SYN Flood -> Port $dstPort (Volumetric Surge)",
                    aiAnalysisReason = "High packet velocity from uncoordinated distributed botnet CIDRs"
                )
            }
            "PORT_SCAN" -> {
                val scanPorts = listOf(21, 22, 23, 25, 53, 80, 110, 143, 443, 445, 3306, 3389, 5432, 8080)
                val targetPort = scanPorts[stepIndex % scanPorts.size]
                val attackerIp = "45.154.255.88"
                CapturedPacket(
                    id = id,
                    packetNumber = id,
                    timestamp = time,
                    protocol = "TCP",
                    sourceIp = attackerIp,
                    destIp = "192.168.1.1",
                    sourcePort = 44210 + (stepIndex % 100),
                    destPort = targetPort,
                    length = 60,
                    status = "SUSPICIOUS",
                    riskLevel = RiskLevel.HIGH,
                    anomalyScore = 78.0,
                    tcpFlags = "SYN, FIN",
                    direction = "INBOUND",
                    info = "Stealth Port Sweep -> :$targetPort (Reconnaissance)",
                    aiAnalysisReason = "Rapid sequential port probing without handshake completion"
                )
            }
            "BRUTE_FORCE" -> {
                val attackerIp = "103.208.220.12"
                CapturedPacket(
                    id = id,
                    packetNumber = id,
                    timestamp = time,
                    protocol = "HTTPS",
                    sourceIp = attackerIp,
                    destIp = "10.0.1.50",
                    sourcePort = 51240,
                    destPort = 443,
                    length = 840,
                    status = "SUSPICIOUS",
                    riskLevel = RiskLevel.HIGH,
                    anomalyScore = 81.0,
                    tcpFlags = "PSH, ACK",
                    direction = "INBOUND",
                    info = "POST /api/auth/login HTTP/2 401 Unauthorized",
                    aiAnalysisReason = "Repeated rapid authentication payload with elevated 401 failure rate"
                )
            }
            "SUSPICIOUS_DNS" -> {
                val hashSubdomain = "exfil_${Random.nextInt(10000, 99999)}.malicious-tunnel.cc"
                CapturedPacket(
                    id = id,
                    packetNumber = id,
                    timestamp = time,
                    protocol = "DNS",
                    sourceIp = localDeviceIp,
                    destIp = "8.8.8.8",
                    sourcePort = 53120 + Random.nextInt(10),
                    destPort = 53,
                    length = 240,
                    status = "SUSPICIOUS",
                    riskLevel = RiskLevel.HIGH,
                    anomalyScore = 74.0,
                    dnsQuery = hashSubdomain,
                    direction = "OUTBOUND",
                    info = "DNS Query TXT $hashSubdomain",
                    aiAnalysisReason = "High entropy DNS subdomain query indicating covert data exfiltration tunnel"
                )
            }
            "DATA_EXFILTRATION" -> {
                CapturedPacket(
                    id = id,
                    packetNumber = id,
                    timestamp = time,
                    protocol = "TCP",
                    sourceIp = "10.0.1.60",
                    destIp = "194.26.29.114",
                    sourcePort = 5432,
                    destPort = 443,
                    length = 1460,
                    status = "HIGH_RISK",
                    riskLevel = RiskLevel.CRITICAL,
                    anomalyScore = 88.0,
                    tcpFlags = "PSH, ACK",
                    direction = "OUTBOUND",
                    info = "Outbound egress payload stream to untrusted ASN (1460 B)",
                    aiAnalysisReason = "Anomalous sustained high-volume egress transfer from database host"
                )
            }
            "BOTNET" -> {
                CapturedPacket(
                    id = id,
                    packetNumber = id,
                    timestamp = time,
                    protocol = "TCP",
                    sourceIp = localDeviceIp,
                    destIp = "185.220.101.5",
                    sourcePort = 49822,
                    destPort = 8443,
                    length = 180,
                    status = "SUSPICIOUS",
                    riskLevel = RiskLevel.HIGH,
                    anomalyScore = 69.0,
                    tcpFlags = "PSH, ACK",
                    direction = "OUTBOUND",
                    info = "Periodic Heartbeat Beacon -> C2 Server (Port 8443)",
                    aiAnalysisReason = "Consistent beaconing interval with low jitter characteristic of botnet agent"
                )
            }
            else -> {
                // NORMAL - realistic mix of HTTPS, HTTP, TCP, UDP, DNS, ICMP
                val roll = Random.nextDouble()
                when {
                    roll < 0.18 -> {
                        // DNS Query
                        val domain = normalDomains.random()
                        CapturedPacket(
                            id = id,
                            packetNumber = id,
                            timestamp = time,
                            protocol = "DNS",
                            sourceIp = localDeviceIp,
                            destIp = "8.8.8.8",
                            sourcePort = Random.nextInt(52000, 58000),
                            destPort = 53,
                            length = Random.nextInt(90, 180),
                            status = "NORMAL",
                            riskLevel = RiskLevel.LOW,
                            anomalyScore = 10.0 + Random.nextDouble(0.0, 5.0),
                            dnsQuery = domain,
                            direction = "OUTBOUND",
                            info = "Standard query 0x${Random.nextInt(0x1000, 0xFFFF).toString(16)} A $domain",
                            aiAnalysisReason = "Nominal DNS name resolution query"
                        )
                    }
                    roll < 0.28 -> {
                        // ICMP Echo
                        CapturedPacket(
                            id = id,
                            packetNumber = id,
                            timestamp = time,
                            protocol = "ICMP",
                            sourceIp = localDeviceIp,
                            destIp = "8.8.8.8",
                            sourcePort = 0,
                            destPort = 0,
                            length = 84,
                            status = "NORMAL",
                            riskLevel = RiskLevel.LOW,
                            anomalyScore = 6.0 + Random.nextDouble(0.0, 4.0),
                            direction = "OUTBOUND",
                            info = "Echo (ping) request id=0x${Random.nextInt(0x1000, 0x9999).toString(16)} seq=${(id % 100)} ttl=64",
                            aiAnalysisReason = "Standard network round-trip ping probe"
                        )
                    }
                    roll < 0.40 -> {
                        // UDP (NTP, QUIC, SSDP)
                        val udpPort = listOf(123, 1900, 4433, 5353).random()
                        val udpDesc = when (udpPort) {
                            123 -> "NTP Network Time Protocol synchronization"
                            1900 -> "SSDP UPnP Discovery broadcast"
                            5353 -> "mDNS Multicast DNS announcement"
                            else -> "QUIC UDP media stream chunk"
                        }
                        CapturedPacket(
                            id = id,
                            packetNumber = id,
                            timestamp = time,
                            protocol = "UDP",
                            sourceIp = localDeviceIp,
                            destIp = if (udpPort == 1900) "239.255.255.250" else remoteServers.random(),
                            sourcePort = Random.nextInt(49152, 65000),
                            destPort = udpPort,
                            length = Random.nextInt(72, 380),
                            status = "NORMAL",
                            riskLevel = RiskLevel.LOW,
                            anomalyScore = 12.0 + Random.nextDouble(0.0, 6.0),
                            direction = "OUTBOUND",
                            info = "UDP Len=${Random.nextInt(40, 240)} -> :$udpPort ($udpDesc)",
                            aiAnalysisReason = "Standard broadcast or time synchronization UDP datagram"
                        )
                    }
                    roll < 0.52 -> {
                        // Cleartext HTTP
                        val remote = remoteServers.random()
                        CapturedPacket(
                            id = id,
                            packetNumber = id,
                            timestamp = time,
                            protocol = "HTTP",
                            sourceIp = localDeviceIp,
                            destIp = remote,
                            sourcePort = Random.nextInt(49152, 65000),
                            destPort = 80,
                            length = Random.nextInt(280, 650),
                            status = "NORMAL",
                            riskLevel = RiskLevel.LOW,
                            anomalyScore = 14.0 + Random.nextDouble(0.0, 5.0),
                            tcpFlags = "ACK, PSH",
                            direction = "OUTBOUND",
                            info = "GET /api/v2/telemetry HTTP/1.1 (Host: $remote)",
                            aiAnalysisReason = "Standard cleartext HTTP service query"
                        )
                    }
                    roll < 0.72 -> {
                        // Plain TCP (Control, Handshake, Custom)
                        val remote = remoteServers.random()
                        val flags = listOf("SYN", "ACK", "PSH, ACK", "FIN, ACK").random()
                        CapturedPacket(
                            id = id,
                            packetNumber = id,
                            timestamp = time,
                            protocol = "TCP",
                            sourceIp = localDeviceIp,
                            destIp = remote,
                            sourcePort = Random.nextInt(49152, 65000),
                            destPort = listOf(22, 5432, 8080, 9000).random(),
                            length = Random.nextInt(60, 240),
                            status = "NORMAL",
                            riskLevel = RiskLevel.LOW,
                            anomalyScore = 15.0 + Random.nextDouble(0.0, 6.0),
                            tcpFlags = flags,
                            direction = "OUTBOUND",
                            info = "TCP Seq=${Random.nextInt(1000, 99999)} Ack=${Random.nextInt(1000, 99999)} Win=65535",
                            aiAnalysisReason = "Nominal TCP transport session maintenance"
                        )
                    }
                    else -> {
                        // HTTPS (TLS 1.3)
                        val remote = remoteServers.random()
                        CapturedPacket(
                            id = id,
                            packetNumber = id,
                            timestamp = time,
                            protocol = "HTTPS",
                            sourceIp = localDeviceIp,
                            destIp = remote,
                            sourcePort = Random.nextInt(49152, 65000),
                            destPort = 443,
                            length = Random.nextInt(320, 1420),
                            status = "NORMAL",
                            riskLevel = RiskLevel.LOW,
                            anomalyScore = 11.0 + Random.nextDouble(0.0, 5.0),
                            tcpFlags = "ACK",
                            direction = "OUTBOUND",
                            info = "TLS 1.3 Application Data Record (Encrypted $remote:443)",
                            aiAnalysisReason = "Secure encrypted TLS session to verified cloud endpoint"
                        )
                    }
                }
            }
        }
    }
}
