package com.example.viewmodel

import android.content.Context
import android.content.Intent
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.CyberRepository
import com.example.engine.AnomalyDetectionEngine
import com.example.engine.AttackForecastEngine
import com.example.engine.DefenseEvaluator
import com.example.engine.FeatureExtractor
import com.example.engine.NetworkAiPipelineEngine
import com.example.engine.RiskEngine
import com.example.engine.TrafficSimulatorEngine
import com.example.model.AiPipelineResult
import com.example.model.AnomalyResult
import com.example.model.AttackForecast
import com.example.model.AttackType
import com.example.model.CaptureState
import com.example.model.CapturedPacket
import com.example.model.ContributingFeature
import com.example.model.DefenseAction
import com.example.model.DefenseEvaluation
import com.example.model.ForecastTimelineEvent
import com.example.model.Incident
import com.example.model.IncidentStatus
import com.example.model.LiveDemoPhase
import com.example.model.Mission
import com.example.model.MonitoringMode
import com.example.model.NetworkEndpoint
import com.example.model.NodeState
import com.example.model.PipelineStage
import com.example.model.ProbabilityBreakdown
import com.example.model.RiskLevel
import com.example.model.SecurityAlert
import com.example.model.SecurityRiskScore
import com.example.model.Severity
import com.example.model.TrafficFeature
import com.example.model.TrafficFilterCriteria
import com.example.service.CyberVpnService
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

enum class ScreenRoute(val title: String) {
    LANDING("Landing"),
    DASHBOARD("Main SOC Dashboard"),
    FORECAST("AI Attack Forecast"),
    NETWORK_MONITOR("Network Monitor"),
    CYBER_GYM("Cyber Gym"),
    LIVE_DEMO("One-Click Live Demo"),
    RED_TEAM("Red Team Simulator"),
    BLUE_TEAM("Blue Team Defense"),
    MISSIONS("Training Missions"),
    INCIDENT_CENTER("Incident Center"),
    THREAT_INTEL("Threat Intelligence"),
    ANALYTICS("Security Analytics"),
    REPORTS("Audit Reports"),
    LEADERBOARD("Leaderboard & XP"),
    ADMIN("Admin Portal"),
    AUTH("Authentication"),
    SETTINGS("Settings & Profile")
}

data class TimeSeriesPoint(
    val timestamp: String,
    val pps: Double,
    val anomalyScore: Double,
    val attackProbability: Double
)

class CyberGymViewModel(
    val repository: CyberRepository = CyberRepository()
) : ViewModel() {

    private val _currentScreen = MutableStateFlow(ScreenRoute.LANDING)
    val currentScreen: StateFlow<ScreenRoute> = _currentScreen.asStateFlow()

    // Real-time Network Telemetry
    private val _packetRate = MutableStateFlow(140.0) // PPS
    val packetRate: StateFlow<Double> = _packetRate.asStateFlow()

    private val _byteRate = MutableStateFlow(95.0) // KB/s
    val byteRate: StateFlow<Double> = _byteRate.asStateFlow()

    private val _totalPackets = MutableStateFlow(84200L)
    val totalPackets: StateFlow<Long> = _totalPackets.asStateFlow()

    private val _activeConnections = MutableStateFlow(32)
    val activeConnections: StateFlow<Int> = _activeConnections.asStateFlow()

    private val _failedConnections = MutableStateFlow(2)
    val failedConnections: StateFlow<Int> = _failedConnections.asStateFlow()

    private val _trafficFeature = MutableStateFlow(TrafficFeature())
    val trafficFeature: StateFlow<TrafficFeature> = _trafficFeature.asStateFlow()

    private val _anomalyResult = MutableStateFlow(AnomalyDetectionEngine.evaluateAnomaly(TrafficFeature()))
    val anomalyResult: StateFlow<AnomalyResult> = _anomalyResult.asStateFlow()

    private val _attackForecast = MutableStateFlow(
        AttackForecastEngine.forecastAttack(TrafficFeature(), _anomalyResult.value, "NORMAL")
    )
    val attackForecast: StateFlow<AttackForecast> = _attackForecast.asStateFlow()

    private val _probabilitiesBreakdown = MutableStateFlow<List<ProbabilityBreakdown>>(emptyList())
    val probabilitiesBreakdown: StateFlow<List<ProbabilityBreakdown>> = _probabilitiesBreakdown.asStateFlow()

    private val _timeSeriesHistory = MutableStateFlow<List<TimeSeriesPoint>>(emptyList())
    val timeSeriesHistory: StateFlow<List<TimeSeriesPoint>> = _timeSeriesHistory.asStateFlow()

    // Wireshark-inspired Network Monitoring State
    private val _monitoringMode = MutableStateFlow(MonitoringMode.IDLE)
    val monitoringMode: StateFlow<MonitoringMode> = _monitoringMode.asStateFlow()

    private val _captureState = MutableStateFlow(CaptureState.STOPPED)
    val captureState: StateFlow<CaptureState> = _captureState.asStateFlow()

    private val _graphTimeWindow = MutableStateFlow("30 SEC") // 10 SEC, 30 SEC, 1 MIN, 5 MIN
    val graphTimeWindow: StateFlow<String> = _graphTimeWindow.asStateFlow()

    private val _filterCriteria = MutableStateFlow(TrafficFilterCriteria())
    val filterCriteria: StateFlow<TrafficFilterCriteria> = _filterCriteria.asStateFlow()

    private val _selectedPacket = MutableStateFlow<CapturedPacket?>(null)
    val selectedPacket: StateFlow<CapturedPacket?> = _selectedPacket.asStateFlow()

    val capturedPackets: StateFlow<List<CapturedPacket>> = repository.capturedPackets

    val filteredPackets: StateFlow<List<CapturedPacket>> = combine(
        repository.capturedPackets,
        _filterCriteria
    ) { packets, criteria ->
        packets.filter { packet ->
            val matchesQuery = if (criteria.query.isBlank()) true else {
                val q = criteria.query.trim().lowercase()
                packet.sourceIp.lowercase().contains(q) ||
                packet.destIp.lowercase().contains(q) ||
                packet.protocol.lowercase().contains(q) ||
                packet.sourcePort.toString().contains(q) ||
                packet.destPort.toString().contains(q) ||
                packet.status.lowercase().contains(q) ||
                packet.riskLevel.name.lowercase().contains(q) ||
                packet.info.lowercase().contains(q)
            }

            val matchesProtocol = when (criteria.protocol.uppercase()) {
                "ALL" -> true
                "SUSPICIOUS" -> packet.status == "SUSPICIOUS" || packet.riskLevel == RiskLevel.MEDIUM || packet.riskLevel == RiskLevel.HIGH
                "HIGH_RISK", "HIGH RISK" -> packet.riskLevel == RiskLevel.CRITICAL || packet.status == "ATTACK_BURST" || packet.status == "HIGH_RISK"
                "DNS" -> packet.protocol.equals("DNS", ignoreCase = true) || packet.destPort == 53 || packet.sourcePort == 53 || packet.dnsQuery != null
                "HTTPS" -> packet.protocol.equals("HTTPS", ignoreCase = true) || (packet.protocol.equals("TCP", ignoreCase = true) && (packet.destPort == 443 || packet.sourcePort == 443))
                "HTTP" -> packet.protocol.equals("HTTP", ignoreCase = true) || (packet.protocol.equals("TCP", ignoreCase = true) && (packet.destPort == 80 || packet.sourcePort == 80))
                "TCP" -> packet.protocol.equals("TCP", ignoreCase = true)
                "UDP" -> packet.protocol.equals("UDP", ignoreCase = true)
                "ICMP" -> packet.protocol.equals("ICMP", ignoreCase = true)
                else -> packet.protocol.equals(criteria.protocol, ignoreCase = true)
            }

            matchesQuery && matchesProtocol
        }.let { list ->
            when (criteria.sortBy) {
                "TIME_ASC" -> list.sortedBy { it.id }
                "RISK" -> list.sortedWith(compareByDescending<CapturedPacket> { it.riskLevel.ordinal }.thenByDescending { it.anomalyScore })
                "ANOMALY" -> list.sortedByDescending { it.anomalyScore }
                "LENGTH" -> list.sortedByDescending { it.length }
                else -> list.sortedByDescending { it.id }
            }
        }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // End-to-End AI Network Monitoring Pipeline Result (8 Stages)
    private val _aiPipelineResult = MutableStateFlow(
        NetworkAiPipelineEngine.executePipeline(
            observedPackets = emptyList(),
            currentPps = 140.0,
            currentBps = 95.0,
            failedConnections = 1
        )
    )
    val aiPipelineResult: StateFlow<AiPipelineResult> = _aiPipelineResult.asStateFlow()

    // Active AI Dispatched Security Alert
    private val _activeSecurityAlert = MutableStateFlow<SecurityAlert?>(null)
    val activeSecurityAlert: StateFlow<SecurityAlert?> = _activeSecurityAlert.asStateFlow()

    private val _securityAlertsHistory = MutableStateFlow<List<SecurityAlert>>(emptyList())
    val securityAlertsHistory: StateFlow<List<SecurityAlert>> = _securityAlertsHistory.asStateFlow()

    // Overall Security Risk Score
    private val _securityRiskScore = MutableStateFlow(
        RiskEngine.calculateRiskScore(
            TrafficFeature(),
            _anomalyResult.value,
            _attackForecast.value,
            2
        )
    )
    val securityRiskScore: StateFlow<SecurityRiskScore> = _securityRiskScore.asStateFlow()

    // 6-Phase Forecast Timeline
    private val _forecastTimeline = MutableStateFlow(
        listOf(
            ForecastTimelineEvent("18:28", "Baseline Traffic", AttackType.NORMAL, 8.0, 12.0, RiskLevel.LOW, false),
            ForecastTimelineEvent("18:30", "Ingress Surge", AttackType.NORMAL, 22.0, 34.0, RiskLevel.MEDIUM, false),
            ForecastTimelineEvent("18:31", "Isolation Anomaly", AttackType.DDOS, 48.0, 68.0, RiskLevel.HIGH, false),
            ForecastTimelineEvent("18:32", "Ensemble Consensus", AttackType.DDOS, 74.0, 84.0, RiskLevel.HIGH, false),
            ForecastTimelineEvent("18:32", "Threat Forecast (Current)", AttackType.DDOS, 82.0, 92.0, RiskLevel.CRITICAL, true),
            ForecastTimelineEvent("Next 2-5m", "Full Volumetric Saturation", AttackType.DDOS, 96.0, 98.0, RiskLevel.CRITICAL, false)
        )
    )
    val forecastTimeline: StateFlow<List<ForecastTimelineEvent>> = _forecastTimeline.asStateFlow()

    // Simulation / Red Team state
    private val _activeScenario = MutableStateFlow("NORMAL")
    val activeScenario: StateFlow<String> = _activeScenario.asStateFlow()

    private val _scenarioDifficulty = MutableStateFlow("Intermediate")
    val scenarioDifficulty: StateFlow<String> = _scenarioDifficulty.asStateFlow()

    private val _isAttackActive = MutableStateFlow(false)
    val isAttackActive: StateFlow<Boolean> = _isAttackActive.asStateFlow()

    private val _attackStartTime = MutableStateFlow(0L)

    // Defense Evaluation
    private val _latestEvaluation = MutableStateFlow<DefenseEvaluation?>(null)
    val latestEvaluation: StateFlow<DefenseEvaluation?> = _latestEvaluation.asStateFlow()

    private val _activeMitigations = MutableStateFlow<List<String>>(emptyList())
    val activeMitigations: StateFlow<List<String>> = _activeMitigations.asStateFlow()

    // Live Demo State Machine (10 Phases)
    private val _liveDemoPhaseIndex = MutableStateFlow(0)
    val liveDemoPhaseIndex: StateFlow<Int> = _liveDemoPhaseIndex.asStateFlow()

    private val _isLiveDemoRunning = MutableStateFlow(false)
    val isLiveDemoRunning: StateFlow<Boolean> = _isLiveDemoRunning.asStateFlow()

    // Active Mission
    private val _selectedMission = MutableStateFlow<Mission?>(null)
    val selectedMission: StateFlow<Mission?> = _selectedMission.asStateFlow()

    private val _missionSecondsLeft = MutableStateFlow(60)
    val missionSecondsLeft: StateFlow<Int> = _missionSecondsLeft.asStateFlow()

    // Notifications
    private val _notifications = MutableStateFlow<List<String>>(
        listOf("SOC System Initialized. AI Forecasting Model Online.", "Baseline traffic profile loaded.")
    )
    val notifications: StateFlow<List<String>> = _notifications.asStateFlow()

    // Auth State
    private val _isLoggedIn = MutableStateFlow(true)
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private var telemetryJob: Job? = null
    private var liveDemoJob: Job? = null
    private var missionJob: Job? = null

    val liveDemoPhases = listOf(
        LiveDemoPhase(1, "PHASE 1: Baseline Normal Traffic", "Network running within nominal parameters", 140.0, 12.0, AttackType.NORMAL, 8.0, RiskLevel.LOW, "Normal operations across all server nodes"),
        LiveDemoPhase(2, "PHASE 2: Traffic Ingress Surge", "Packet rate begins ramping up at gateway", 850.0, 38.0, AttackType.NORMAL, 20.0, RiskLevel.MEDIUM, "Volume increase detected on Port 443"),
        LiveDemoPhase(3, "PHASE 3: Anomaly Detected", "Isolation Forest flags abnormal connection vectors", 1850.0, 68.0, AttackType.DDOS, 35.0, RiskLevel.HIGH, "SYN burst exceeds isolation forest baseline threshold"),
        LiveDemoPhase(4, "PHASE 4: AI Forecasts DDoS Threat", "Predictive ensemble models identify impending attack", 2400.0, 78.0, AttackType.DDOS, 51.0, RiskLevel.HIGH, "Forecast Window: Next 2–5 minutes | Confidence: High"),
        LiveDemoPhase(5, "PHASE 5: Attack Probability Spike", "Probability accelerates as connection drops mount", 3200.0, 88.0, AttackType.DDOS, 82.0, RiskLevel.CRITICAL, "Critical convergence: Multi-source SYN flood confirmed"),
        LiveDemoPhase(6, "PHASE 6: Critical SOC Alert Triggered", "SOC dispatch alert issued to Blue Team", 3450.0, 92.0, AttackType.DDOS, 88.0, RiskLevel.CRITICAL, "Automated threat notification pushed to defense console"),
        LiveDemoPhase(7, "PHASE 7: Cyber Gym Simulates Attack", "Virtual web server node shifts to Compromised status", 3600.0, 95.0, AttackType.DDOS, 92.0, RiskLevel.CRITICAL, "Web Server CPU: 96% | High inbound packet drop"),
        LiveDemoPhase(8, "PHASE 8: Blue Team Applies Defense", "Tactical Rate Limiting + Firewall ACL engaged", 1200.0, 48.0, AttackType.DDOS, 62.0, RiskLevel.HIGH, "Rate Limit 500 PPS applied to ingress edge router"),
        LiveDemoPhase(9, "PHASE 9: Threat Contained", "Volumetric flood filtered; telemetry normalizes", 220.0, 18.0, AttackType.NORMAL, 12.0, RiskLevel.LOW, "Attack neutralized. Node health restored to Normal"),
        LiveDemoPhase(10, "PHASE 10: AI Evaluation Complete", "Judge Scorecard & Performance Metrics calculated", 150.0, 10.0, AttackType.NORMAL, 5.0, RiskLevel.LOW, "Forecast Accuracy: 94% | Defense Score: 91% | Response: 2.4s")
    )

    init {
        startTelemetryEngine()
        startVpnPacketCollector()
    }

    private fun startVpnPacketCollector() {
        viewModelScope.launch {
            CyberVpnService.packetFlow.collect { packet ->
                repository.addCapturedPacket(packet)
                _totalPackets.value += 1

                val isAttacking = _isAttackActive.value
                val scenario = _activeScenario.value
                val packets = repository.capturedPackets.value

                // Feed real packet metrics into deterministic 8-stage AI Pipeline
                val pipelineResult = NetworkAiPipelineEngine.executePipeline(
                    observedPackets = packets,
                    currentPps = max(_packetRate.value, 1.0),
                    currentBps = max(_byteRate.value, (packet.length / 1024.0)),
                    failedConnections = _failedConnections.value,
                    activeScenario = if (isAttacking) scenario else "NORMAL",
                    isAttacking = isAttacking,
                    totalCumulativePackets = _totalPackets.value
                )

                _aiPipelineResult.value = pipelineResult
                _trafficFeature.value = pipelineResult.trafficFeature
                _anomalyResult.value = pipelineResult.anomalyResult

                val forecast = AttackForecastEngine.forecastAttack(
                    pipelineResult.trafficFeature,
                    pipelineResult.anomalyResult,
                    if (isAttacking) scenario else "NORMAL"
                )
                _attackForecast.value = forecast

                _probabilitiesBreakdown.value = AttackForecastEngine.computeProbabilitiesBreakdown(
                    pipelineResult.classifiedAttack,
                    pipelineResult.attackProbability
                )

                _securityRiskScore.value = pipelineResult.securityRiskScore

                pipelineResult.activeAlert?.let { alert ->
                    _activeSecurityAlert.value = alert
                    val currentAlerts = _securityAlertsHistory.value.toMutableList()
                    if (currentAlerts.none { it.id == alert.id }) {
                        currentAlerts.add(0, alert)
                        if (currentAlerts.size > 20) currentAlerts.removeAt(currentAlerts.lastIndex)
                        _securityAlertsHistory.value = currentAlerts
                    }
                }

                if (packet.riskLevel == RiskLevel.CRITICAL || packet.status == "ATTACK_BURST") {
                    pushNotification("⚠️ High-Risk packet captured: ${packet.sourceIp} -> ${packet.destIp}:${packet.destPort}")
                }
            }
        }
    }

    fun navigateTo(route: ScreenRoute) {
        _currentScreen.value = route
    }

    fun acknowledgeAlert(alertId: String) {
        _activeSecurityAlert.value = null
        _securityAlertsHistory.value = _securityAlertsHistory.value.map {
            if (it.id == alertId) it.copy(isAcknowledged = true) else it
        }
        pushNotification("Alert $alertId acknowledged by Blue Team operator.")
    }

    private fun startTelemetryEngine() {
        telemetryJob?.cancel()
        telemetryJob = viewModelScope.launch {
            var counter = 0
            while (isActive) {
                counter++
                val scenario = _activeScenario.value
                val isAttacking = _isAttackActive.value
                val isCapturing = _captureState.value == CaptureState.RUNNING

                val basePps = when {
                    scenario == "DDOS" && isAttacking -> Random.nextDouble(2800.0, 4200.0)
                    scenario == "PORT_SCAN" && isAttacking -> Random.nextDouble(600.0, 1100.0)
                    scenario == "BRUTE_FORCE" && isAttacking -> Random.nextDouble(450.0, 900.0)
                    scenario == "DATA_EXFILTRATION" && isAttacking -> Random.nextDouble(750.0, 1400.0)
                    scenario == "BOTNET" && isAttacking -> Random.nextDouble(550.0, 950.0)
                    else -> Random.nextDouble(110.0, 190.0)
                }

                val baseBps = when {
                    scenario == "DATA_EXFILTRATION" && isAttacking -> Random.nextDouble(2400.0, 4800.0)
                    scenario == "DDOS" && isAttacking -> Random.nextDouble(1800.0, 3200.0)
                    else -> Random.nextDouble(60.0, 140.0)
                }

                val failedConns = when {
                    scenario == "PORT_SCAN" && isAttacking -> Random.nextInt(35, 90)
                    scenario == "BRUTE_FORCE" && isAttacking -> Random.nextInt(20, 45)
                    scenario == "DDOS" && isAttacking -> Random.nextInt(40, 120)
                    else -> Random.nextInt(0, 3)
                }

                _packetRate.value = basePps
                _byteRate.value = baseBps
                _totalPackets.value += (basePps * 1.5).toLong()
                _failedConnections.value = failedConns
                _activeConnections.value = if (isAttacking) Random.nextInt(60, 240) else Random.nextInt(18, 42)

                // If capturing packets in simulation or attack scenario, generate synthetic packet
                if (isCapturing || isAttacking) {
                    val pktScenario = if (isAttacking) scenario else "NORMAL"
                    val packet = TrafficSimulatorEngine.generatePacket(pktScenario, counter)
                    repository.addCapturedPacket(packet)
                }

                // Execute End-to-End AI Network Monitoring Pipeline (8 Stages)
                val packets = repository.capturedPackets.value
                val pipelineResult = NetworkAiPipelineEngine.executePipeline(
                    observedPackets = packets,
                    currentPps = basePps,
                    currentBps = baseBps,
                    failedConnections = failedConns,
                    activeScenario = if (isAttacking) scenario else "NORMAL",
                    isAttacking = isAttacking,
                    totalCumulativePackets = _totalPackets.value
                )

                _aiPipelineResult.value = pipelineResult
                _trafficFeature.value = pipelineResult.trafficFeature
                _anomalyResult.value = pipelineResult.anomalyResult

                val forecast = AttackForecastEngine.forecastAttack(
                    pipelineResult.trafficFeature,
                    pipelineResult.anomalyResult,
                    if (isAttacking) scenario else "NORMAL"
                )
                _attackForecast.value = forecast

                _probabilitiesBreakdown.value = AttackForecastEngine.computeProbabilitiesBreakdown(
                    pipelineResult.classifiedAttack,
                    pipelineResult.attackProbability
                )

                _securityRiskScore.value = pipelineResult.securityRiskScore

                pipelineResult.activeAlert?.let { alert ->
                    _activeSecurityAlert.value = alert
                    val currentAlerts = _securityAlertsHistory.value.toMutableList()
                    if (currentAlerts.none { it.id == alert.id }) {
                        currentAlerts.add(0, alert)
                        if (currentAlerts.size > 20) currentAlerts.removeAt(currentAlerts.lastIndex)
                        _securityAlertsHistory.value = currentAlerts
                        if (alert.severity == Severity.CRITICAL || alert.severity == Severity.HIGH) {
                            pushNotification("🚨 [SOC ALERT] ${alert.title}")
                        }
                    }
                } ?: run {
                    if (!isAttacking && _activeSecurityAlert.value != null && pipelineResult.securityRiskScore.threatLevel == RiskLevel.LOW) {
                        _activeSecurityAlert.value = null
                    }
                }

                // Update time-series history (keep last 20 samples)
                val currentHistory = _timeSeriesHistory.value.toMutableList()
                val timeLabel = "${(counter * 2) % 60}s"
                currentHistory.add(TimeSeriesPoint(timeLabel, basePps, pipelineResult.anomalyResult.anomalyScore, forecast.probability))
                if (currentHistory.size > 20) {
                    currentHistory.removeAt(0)
                }
                _timeSeriesHistory.value = currentHistory

                // Auto-sync node states if attack active
                if (isAttacking) {
                    when (scenario) {
                        "DDOS" -> {
                            repository.updateNodeState("web_server", NodeState.COMPROMISED, Random.nextInt(85, 99))
                            repository.updateNodeState("firewall", NodeState.SUSPICIOUS, Random.nextInt(60, 80))
                        }
                        "PORT_SCAN" -> {
                            repository.updateNodeState("router", NodeState.SUSPICIOUS, Random.nextInt(45, 65))
                            repository.updateNodeState("dns_server", NodeState.SUSPICIOUS, Random.nextInt(40, 55))
                        }
                        "DATA_EXFILTRATION" -> {
                            repository.updateNodeState("db_server", NodeState.COMPROMISED, Random.nextInt(75, 92))
                        }
                        else -> {
                            repository.updateNodeState("web_server", NodeState.SUSPICIOUS, Random.nextInt(50, 70))
                        }
                    }
                }

                delay(1500)
            }
        }
    }

    // Network Monitoring Lifecycle
    fun onVpnPermissionRequired() {
        _captureState.value = CaptureState.PREPARING
        pushNotification("🔑 Requesting Android VPN system permission...")
    }

    fun onVpnPermissionDenied() {
        _captureState.value = CaptureState.STOPPED
        pushNotification("⚠️ VPN permission declined. Tap 'Start Simulation' for full attack telemetry.")
    }

    fun startVpnMonitoring(context: Context) {
        _monitoringMode.value = MonitoringMode.LIVE_VPN
        _captureState.value = CaptureState.RUNNING
        val intent = Intent(context, CyberVpnService::class.java).apply {
            action = CyberVpnService.ACTION_START
        }
        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
            pushNotification("🟢 Local VPN Monitoring Service Started. Privacy preserved.")
        } catch (e: Exception) {
            _monitoringMode.value = MonitoringMode.FLOW_ANALYSIS
            pushNotification("ℹ️ Running in Local Flow & Metadata Analysis Mode.")
        }
    }

    fun startSimulationMonitoring() {
        _monitoringMode.value = MonitoringMode.SIMULATION
        _captureState.value = CaptureState.RUNNING
        pushNotification("🟢 CyberGym Traffic Simulation Started.")
    }

    fun pauseMonitoring(context: Context? = null) {
        _captureState.value = CaptureState.PAUSED
        if (context != null) {
            val intent = Intent(context, CyberVpnService::class.java).apply {
                action = CyberVpnService.ACTION_PAUSE
            }
            try { context.startService(intent) } catch (_: Exception) {}
        }
        pushNotification("⏸️ Traffic capture paused.")
    }

    fun resumeMonitoring(context: Context? = null) {
        _captureState.value = CaptureState.RUNNING
        if (context != null) {
            val intent = Intent(context, CyberVpnService::class.java).apply {
                action = CyberVpnService.ACTION_RESUME
            }
            try { context.startService(intent) } catch (_: Exception) {}
        }
        pushNotification("▶️ Traffic capture resumed.")
    }

    fun stopMonitoring(context: Context? = null) {
        _captureState.value = CaptureState.STOPPED
        _monitoringMode.value = MonitoringMode.IDLE
        if (context != null) {
            val intent = Intent(context, CyberVpnService::class.java).apply {
                action = CyberVpnService.ACTION_STOP
            }
            try { context.startService(intent) } catch (_: Exception) {}
        }
        pushNotification("⏹️ Traffic monitoring stopped.")
    }

    fun clearPackets() {
        repository.clearPackets()
        pushNotification("Cleared packet capture table.")
    }

    fun setFilterQuery(query: String) {
        _filterCriteria.value = _filterCriteria.value.copy(query = query)
    }

    fun setProtocolFilter(protocol: String) {
        _filterCriteria.value = _filterCriteria.value.copy(protocol = protocol)
    }

    fun setSortBy(sortBy: String) {
        _filterCriteria.value = _filterCriteria.value.copy(sortBy = sortBy)
    }

    fun setGraphTimeWindow(window: String) {
        _graphTimeWindow.value = window
    }

    fun selectPacket(packet: CapturedPacket?) {
        _selectedPacket.value = packet
    }

    fun investigatePacket(packet: CapturedPacket) {
        _selectedPacket.value = null
        pushNotification("🔍 Investigating packet #${packet.id} (${packet.sourceIp} -> ${packet.destIp})")
        navigateTo(ScreenRoute.FORECAST)
    }

    fun markPacketSafe(packet: CapturedPacket) {
        _selectedPacket.value = null
        pushNotification("✓ Packet #${packet.id} marked as Safe by analyst.")
    }

    fun blockIpAddress(ip: String) {
        _selectedPacket.value = null
        pushNotification("🛡️ Firewall drop rule enforced: Source IP $ip blocked on all edge interfaces.")
    }

    fun openIncidentForPacket(packet: CapturedPacket) {
        _selectedPacket.value = null
        val incident = Incident(
            id = "INC-${Random.nextInt(9100, 9999)}",
            timestamp = "Just now",
            attackType = when (packet.status) {
                "ATTACK_BURST" -> AttackType.DDOS
                else -> AttackType.PORT_SCAN
            },
            severity = if (packet.riskLevel == RiskLevel.CRITICAL) Severity.CRITICAL else Severity.HIGH,
            sourceIp = packet.sourceIp,
            targetHost = "${packet.destIp}:${packet.destPort}",
            aiProbability = packet.anomalyScore,
            status = IncidentStatus.INVESTIGATING,
            mitigationAction = "Under Investigation"
        )
        repository.addIncident(incident)
        pushNotification("🚨 Incident created: ${incident.id} for ${packet.sourceIp}")
        navigateTo(ScreenRoute.INCIDENT_CENTER)
    }

    fun launchTrainingFromForecast() {
        val forecastedType = _attackForecast.value.attackType
        startRedTeamScenario(forecastedType.name, "Intermediate")
        navigateTo(ScreenRoute.BLUE_TEAM)
        pushNotification("🎯 Launched CyberGym Defense Training for ${forecastedType.displayName}!")
    }

    // Red Team Scenario Control
    fun startRedTeamScenario(scenario: String, difficulty: String = "Intermediate") {
        _activeScenario.value = scenario
        _scenarioDifficulty.value = difficulty
        _isAttackActive.value = true
        _attackStartTime.value = System.currentTimeMillis()
        _latestEvaluation.value = null
        _activeMitigations.value = emptyList()

        pushNotification("🔴 Red Team initiated simulated $scenario ($difficulty)")
    }

    fun stopRedTeamScenario() {
        _isAttackActive.value = false
        _activeScenario.value = "NORMAL"
        repository.resetAllNodes()
        pushNotification("Simulation stopped. Network returned to baseline.")
    }

    // Blue Team Defense Action
    fun executeDefenseAction(action: DefenseAction) {
        val elapsed = if (_attackStartTime.value > 0) {
            max(1.2, (System.currentTimeMillis() - _attackStartTime.value) / 1000.0)
        } else 2.4

        val activeType = _attackForecast.value.attackType
        val evaluation = DefenseEvaluator.evaluateDefense(activeType, action, elapsed)
        _latestEvaluation.value = evaluation

        _activeMitigations.value = _activeMitigations.value + listOf("${action.name} (Applied)")

        // Neutralize node damage
        repository.updateNodeState("web_server", NodeState.PROTECTED, 25)
        repository.updateNodeState("firewall", NodeState.PROTECTED, 28)
        repository.updateNodeState("db_server", NodeState.PROTECTED, 20)

        // Award XP and log incident
        repository.addXp(evaluation.finalScore * 2)

        val newInc = Incident(
            id = "INC-${Random.nextInt(9000, 9999)}",
            timestamp = "Just now",
            attackType = activeType,
            severity = if (evaluation.finalScore >= 85) Severity.HIGH else Severity.CRITICAL,
            sourceIp = "185.220.${Random.nextInt(10, 250)}.${Random.nextInt(1, 254)}",
            targetHost = "Primary Web Server (10.0.1.50)",
            aiProbability = _attackForecast.value.probability,
            status = IncidentStatus.CONTAINED,
            mitigationAction = action.name
        )
        repository.addIncident(newInc)

        pushNotification("🛡️ Blue Team deployed: ${action.name} (Score: ${evaluation.finalScore}/100)")
        _isAttackActive.value = false
    }

    // One-Click Live Judge Demo
    fun startLiveDemo() {
        _isLiveDemoRunning.value = true
        _liveDemoPhaseIndex.value = 0
        _activeScenario.value = "DDOS"
        _isAttackActive.value = true
        _attackStartTime.value = System.currentTimeMillis()
        _latestEvaluation.value = null

        liveDemoJob?.cancel()
        liveDemoJob = viewModelScope.launch {
            for (i in 0 until liveDemoPhases.size) {
                _liveDemoPhaseIndex.value = i
                applyDemoPhase(liveDemoPhases[i])
                delay(3000)
            }
            _isLiveDemoRunning.value = false
        }
    }

    fun stepLiveDemoNext() {
        val nextIdx = (_liveDemoPhaseIndex.value + 1) % liveDemoPhases.size
        _liveDemoPhaseIndex.value = nextIdx
        applyDemoPhase(liveDemoPhases[nextIdx])
    }

    fun stepLiveDemoPrev() {
        val prevIdx = max(0, _liveDemoPhaseIndex.value - 1)
        _liveDemoPhaseIndex.value = prevIdx
        applyDemoPhase(liveDemoPhases[prevIdx])
    }

    private fun applyDemoPhase(phase: LiveDemoPhase) {
        _packetRate.value = phase.pps
        _anomalyResult.value = AnomalyResult(
            phase.anomalyScore,
            if (phase.anomalyScore > 75) com.example.model.AnomalyClassification.CRITICAL
            else if (phase.anomalyScore > 45) com.example.model.AnomalyClassification.HIGHLY_SUSPICIOUS
            else com.example.model.AnomalyClassification.NORMAL,
            listOf("Packet rate: ${phase.pps.toInt()} PPS", "Isolation Tree Anomaly Score: ${phase.anomalyScore.toInt()}"),
            phase.anomalyScore > 40
        )

        _attackForecast.value = AttackForecast(
            attackType = phase.predictedAttack,
            probability = phase.probability,
            confidence = if (phase.probability > 70) "High (94.6%)" else "Medium",
            riskLevel = phase.threatLevel,
            forecastWindow = "Next 2–5 minutes",
            contributingFeatures = listOf(
                "Packet surge of ${(phase.pps / 150.0).format(1)}x baseline",
                "Abnormal SYN burst across gateway",
                "Source IP dispersion indicates distributed origin"
            ),
            recommendedActions = listOf("Rate Limit Connection", "Apply Firewall Rule", "Block Source IP"),
            explainableSummary = "AI forecast predicted ${phase.predictedAttack.displayName} with ${phase.probability.toInt()}% probability based on incoming flow vector anomaly."
        )

        _probabilitiesBreakdown.value = AttackForecastEngine.computeProbabilitiesBreakdown(
            phase.predictedAttack,
            phase.probability
        )

        if (phase.phaseNumber in 7..8) {
            repository.updateNodeState("web_server", NodeState.COMPROMISED, 96)
        } else if (phase.phaseNumber >= 9) {
            repository.updateNodeState("web_server", NodeState.PROTECTED, 22)
            _latestEvaluation.value = DefenseEvaluation(
                detectionAccuracy = 94.0,
                responseTimeSeconds = 2.4,
                defenseEffectiveness = 92.0,
                damagePrevented = 86.0,
                decisionQuality = 91.0,
                finalScore = 91,
                aiFeedback = "ATTACK FORECAST SUCCESSFUL. Threat predicted 2.8 minutes before peak saturation. Rate limit defense contained the attack with zero downtime.",
                badgeUnlocked = "Fast Responder"
            )
        } else {
            repository.updateNodeState("web_server", NodeState.NORMAL, 20)
        }
    }

    // Training Mission
    fun startMission(mission: Mission) {
        _selectedMission.value = mission
        _missionSecondsLeft.value = mission.timeLimitSeconds
        _latestEvaluation.value = null
        startRedTeamScenario(mission.threat.name, mission.difficulty)

        missionJob?.cancel()
        missionJob = viewModelScope.launch {
            while (_missionSecondsLeft.value > 0 && _isAttackActive.value) {
                delay(1000)
                _missionSecondsLeft.value -= 1
            }
        }
    }

    fun completeCurrentMission(score: Int) {
        _selectedMission.value?.let {
            repository.updateMissionCompleted(it.id, score)
        }
        _isAttackActive.value = false
        pushNotification("🎉 Mission Completed with Score $score/100!")
    }

    fun pushNotification(text: String) {
        _notifications.value = listOf(text) + _notifications.value.take(15)
    }

    fun login(role: String) {
        _isLoggedIn.value = true
        repository.updateUserRole(role)
        pushNotification("Logged in as $role")
        _currentScreen.value = ScreenRoute.DASHBOARD
    }

    fun logout() {
        _isLoggedIn.value = false
        _currentScreen.value = ScreenRoute.LANDING
    }

    private fun Double.format(digits: Int) = String.format("%.${digits}f", this)

    override fun onCleared() {
        super.onCleared()
        telemetryJob?.cancel()
        liveDemoJob?.cancel()
        missionJob?.cancel()
    }
}
