package com.example.data

import com.example.model.Achievement
import com.example.model.AttackType
import com.example.model.CapturedPacket
import com.example.model.DatasetRecord
import com.example.model.DefenseAction
import com.example.model.Incident
import com.example.model.IncidentStatus
import com.example.model.LeaderboardEntry
import com.example.model.Mission
import com.example.model.ModelMetrics
import com.example.model.NetworkEndpoint
import com.example.model.NetworkNode
import com.example.model.NodeState
import com.example.model.RiskLevel
import com.example.model.Severity
import com.example.model.ThreatIntel
import com.example.model.UserProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class CyberRepository {

    // Wireshark-inspired Packet Flow Storage
    private val _capturedPackets = MutableStateFlow<List<CapturedPacket>>(
        listOf(
            CapturedPacket(1001L, 1001L, "18:32:10", System.currentTimeMillis() - 9000, "TCP", "192.168.1.45", "104.244.42.1", 51420, 443, 1240, "NORMAL", RiskLevel.LOW, 12.0, "ACK, PSH", null, "OUTBOUND", "TCP TLSv1.3 Application Data stream", "Nominal encrypted HTTPS flow to verified CDN"),
            CapturedPacket(1002L, 1002L, "18:32:11", System.currentTimeMillis() - 8000, "DNS", "192.168.1.45", "8.8.8.8", 53122, 53, 180, "NORMAL", RiskLevel.LOW, 10.0, "", "api.cybergym.io", "OUTBOUND", "Standard query 0x14f2 A api.cybergym.io", "Standard DNS address resolution"),
            CapturedPacket(1003L, 1003L, "18:32:12", System.currentTimeMillis() - 7000, "TCP", "192.168.1.45", "185.220.101.5", 51424, 443, 840, "SUSPICIOUS", RiskLevel.MEDIUM, 64.0, "PSH, ACK", null, "OUTBOUND", "Encrypted stream to unclassified ASN", "Destination IP identified in external threat intelligence feeds"),
            CapturedPacket(1004L, 1004L, "18:32:13", System.currentTimeMillis() - 6000, "UDP", "192.168.1.45", "192.168.1.255", 56789, 1900, 256, "NORMAL", RiskLevel.LOW, 14.0, "", null, "OUTBOUND", "SSDP M-SEARCH * HTTP/1.1", "Standard local UPnP discovery broadcast"),
            CapturedPacket(1005L, 1005L, "18:32:14", System.currentTimeMillis() - 5000, "TCP", "45.154.255.88", "192.168.1.1", 44102, 22, 60, "SUSPICIOUS", RiskLevel.HIGH, 78.0, "SYN", null, "INBOUND", "TCP SYN probe -> Port 22 SSH", "Unsolicited connection attempt on management port without prior DNS"),
            CapturedPacket(1006L, 1006L, "18:32:15", System.currentTimeMillis() - 4000, "HTTP", "192.168.1.45", "93.184.216.34", 49812, 80, 512, "NORMAL", RiskLevel.LOW, 15.0, "ACK, PSH", null, "OUTBOUND", "GET /api/v1/status HTTP/1.1", "Standard cleartext HTTP service health check"),
            CapturedPacket(1007L, 1007L, "18:32:16", System.currentTimeMillis() - 3000, "ICMP", "192.168.1.45", "8.8.8.8", 0, 0, 84, "NORMAL", RiskLevel.LOW, 8.0, "", null, "OUTBOUND", "Echo (ping) request id=0x19f4 seq=1 ttl=64", "Nominal network latency probe"),
            CapturedPacket(1008L, 1008L, "18:32:17", System.currentTimeMillis() - 2000, "HTTPS", "192.168.1.45", "142.250.190.46", 52110, 443, 1380, "NORMAL", RiskLevel.LOW, 11.0, "ACK", null, "OUTBOUND", "TLS 1.3 Key Exchange & Handshake", "Trusted Google Cloud service ingress/egress"),
            CapturedPacket(1009L, 1009L, "18:32:18", System.currentTimeMillis() - 1000, "ICMP", "185.220.101.42", "192.168.1.45", 0, 0, 96, "SUSPICIOUS", RiskLevel.HIGH, 72.0, "", null, "INBOUND", "Echo (ping) flood probe id=0xdead seq=42", "High rate unsolicited ICMP ping sweep from suspect scanner"),
            CapturedPacket(1010L, 1010L, "18:32:19", System.currentTimeMillis(), "TCP", "185.220.101.42", "10.0.1.50", 49100, 80, 64, "ATTACK_BURST", RiskLevel.CRITICAL, 94.0, "SYN", null, "INBOUND", "High-velocity SYN flood burst", "Packet surge 4.5x baseline; candidate volumetric DDoS stream")
        )
    )
    val capturedPackets: StateFlow<List<CapturedPacket>> = _capturedPackets.asStateFlow()

    // Legitimate Network Endpoints
    private val _networkEndpoints = MutableStateFlow<List<NetworkEndpoint>>(
        listOf(
            NetworkEndpoint("192.168.1.45", "Android Device (Local)", "Local VpnService Endpoint", 4850000L, 8420L, 18, "HTTPS", RiskLevel.LOW, "ACTIVE", true),
            NetworkEndpoint("192.168.1.1", "Gateway Router", "Default Gateway", 12400000L, 24100L, 42, "TCP", RiskLevel.MEDIUM, "ACTIVE", false),
            NetworkEndpoint("8.8.8.8", "Google DNS Resolver", "Core DNS Resolver", 420000L, 3400L, 4, "DNS", RiskLevel.LOW, "ACTIVE", false),
            NetworkEndpoint("104.244.42.1", "Cloudflare Edge CDN", "Web Content Delivery", 8900000L, 11200L, 12, "HTTPS", RiskLevel.LOW, "ACTIVE", false),
            NetworkEndpoint("10.0.1.50", "Primary Web Server", "Internal HTTP/HTTPS Cluster", 18200000L, 34200L, 86, "TCP", RiskLevel.HIGH, "ACTIVE", false),
            NetworkEndpoint("10.0.1.60", "Core SQL Database", "Internal PostgreSQL Shard", 6400000L, 9800L, 24, "TCP", RiskLevel.LOW, "ACTIVE", false),
            NetworkEndpoint("45.154.255.88", "External Scanner Host", "Untrusted Public CIDR", 124000L, 480L, 8, "TCP", RiskLevel.CRITICAL, "SUSPICIOUS", false)
        )
    )
    val networkEndpoints: StateFlow<List<NetworkEndpoint>> = _networkEndpoints.asStateFlow()

    fun addCapturedPacket(packet: CapturedPacket) {
        val current = _capturedPackets.value
        // Maintain a rolling buffer of 300 packets
        val updated = if (current.size > 300) {
            listOf(packet) + current.take(299)
        } else {
            listOf(packet) + current
        }
        _capturedPackets.value = updated
    }

    fun clearPackets() {
        _capturedPackets.value = emptyList()
    }

    fun updateEndpointStatus(address: String, newStatus: String) {
        _networkEndpoints.value = _networkEndpoints.value.map {
            if (it.address == address) it.copy(status = newStatus) else it
        }
    }

    val defenseActions = listOf(
        DefenseAction("block_ip", "Block Source IP", "Perimeter", "Drop all inbound packets from suspect IP address across edge router ACL", 94, "Block"),
        DefenseAction("rate_limit", "Rate Limit Connection", "Traffic Shaping", "Throttle traffic bandwidth to 100 PPS on ingress gateway", 92, "Speed"),
        DefenseAction("isolate_host", "Isolate Target Host", "Containment", "Quarantine internal host into segregated sandbox VLAN", 96, "Lan"),
        DefenseAction("block_port", "Block Port Filter", "Access Control", "Close targeted listener port and restrict incoming syn sweeps", 88, "Lock"),
        DefenseAction("firewall_rule", "Enable Firewall Rule", "Inspection", "Inject dynamic stateful packet filter rule into iptables", 90, "Security"),
        DefenseAction("deep_packet", "Deep Packet Inspection", "Forensics", "Route packets through Snort/Suricata DPI engine for signature matching", 85, "Search"),
        DefenseAction("investigate_logs", "Investigate Incident Logs", "Analysis", "Correlate syslog, auth.log, and Zeek bro events across ELK cluster", 80, "Assessment"),
        DefenseAction("escalate", "Escalate to Tier 3 SOC", "Management", "Trigger incident commander protocol and alert on-call SecOps engineer", 82, "Warning")
    )

    private val _userProfile = MutableStateFlow(UserProfile())
    val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

    private val _networkNodes = MutableStateFlow(
        listOf(
            NetworkNode("clients", "Edge Clients", "External Traffic Pool", NodeState.NORMAL, "198.51.100.0/24", 12, 28, 1.4, 0.9, 32, 0.15f, 0.25f),
            NetworkNode("router", "Core Gateway Router", "Border Router (BGP)", NodeState.NORMAL, "192.168.1.1", 24, 38, 4.2, 3.8, 140, 0.50f, 0.25f),
            NetworkNode("firewall", "NGFW Firewall", "Stateful Inspection (Suricata)", NodeState.NORMAL, "192.168.1.254", 32, 45, 3.8, 3.2, 128, 0.50f, 0.50f),
            NetworkNode("web_server", "Primary Web Server", "Nginx App Cluster (Port 80/443)", NodeState.NORMAL, "10.0.1.50", 22, 42, 2.1, 1.8, 86, 0.20f, 0.78f),
            NetworkNode("db_server", "Core SQL Database", "PostgreSQL Shard (Port 5432)", NodeState.NORMAL, "10.0.1.60", 18, 56, 0.8, 1.1, 34, 0.50f, 0.82f),
            NetworkNode("dns_server", "Internal DNS Resolver", "Binds9 Core DNS (Port 53)", NodeState.NORMAL, "10.0.1.10", 14, 30, 0.4, 0.3, 18, 0.80f, 0.78f)
        )
    )
    val networkNodes: StateFlow<List<NetworkNode>> = _networkNodes.asStateFlow()

    private val _missions = MutableStateFlow(
        listOf(
            Mission("m1", "MISSION 01", "Detect the Spike", "Observe nominal baseline network traffic and flag the early anomaly packet surge before saturation occurs.", AttackType.DDOS, 45, listOf("Watch the PPS gauge for 3x baseline spikes", "Check the TCP flags for SYN flood accumulation"), "Beginner", 150, true, 94),
            Mission("m2", "MISSION 02", "Stop the DDoS", "An aggressive multi-vector volumetric DDoS is forecasted. Select and deploy the optimal traffic shaping defense.", AttackType.DDOS, 60, listOf("Rate Limiting and Firewall ACLs prevent packet overload", "Check host CPU utilization"), "Beginner", 200, true, 91),
            Mission("m3", "MISSION 03", "Identify the Port Scanner", "Detect stealth reconnaissance scan across critical internal ports before lateral movement begins.", AttackType.PORT_SCAN, 60, listOf("High failed connection rate indicates port sweep", "Look for abnormal SYN/FIN flag patterns"), "Intermediate", 250, true, 88),
            Mission("m4", "MISSION 04", "Protect the Web Server", "The primary Nginx application server is experiencing credential brute force attempts on admin portals.", AttackType.BRUTE_FORCE, 50, listOf("Examine failed auth responses (401/403)", "Apply IP jail / rate limiting on auth endpoints"), "Intermediate", 300, false, 0),
            Mission("m5", "MISSION 05", "Investigate Suspicious Traffic", "Anomalous beaconing traffic discovered communicating with an unknown external command and control server.", AttackType.BOTNET, 75, listOf("Inspect periodic timing intervals in connection flow", "Correlate destination ASN with Threat Intel"), "Advanced", 350, false, 0),
            Mission("m6", "MISSION 06", "Prevent Data Exfiltration", "High volume encrypted payload egress detected from internal database server during non-business hours.", AttackType.DATA_EXFILTRATION, 60, listOf("Immediate host isolation halts outbound byte transfer", "Inspect database audit logs"), "Advanced", 400, false, 0),
            Mission("m7", "MISSION 07", "Multi-Stage Attack", "Reconnaissance scan followed immediately by zero-day exploit payload and volumetric flood diversion.", AttackType.DDOS, 90, listOf("Correlate early scan events with secondary forecast vectors", "Deploy layered defense in depth"), "Expert", 500, false, 0)
        )
    )
    val missions: StateFlow<List<Mission>> = _missions.asStateFlow()

    private val _incidents = MutableStateFlow(
        listOf(
            Incident("INC-8921", "2 mins ago", AttackType.DDOS, Severity.CRITICAL, "185.220.101.42", "Primary Web Server (10.0.1.50)", 88.5, IncidentStatus.CONTAINED, "Rate Limiting + IP Drop ACL"),
            Incident("INC-8920", "14 mins ago", AttackType.PORT_SCAN, Severity.HIGH, "45.154.255.89", "Gateway Router (192.168.1.1)", 76.2, IncidentStatus.RESOLVED, "Offending CIDR Blocked"),
            Incident("INC-8919", "45 mins ago", AttackType.BRUTE_FORCE, Severity.MEDIUM, "103.208.220.12", "SSH Bastion (10.0.1.20)", 82.0, IncidentStatus.RESOLVED, "Fail2Ban Triggered"),
            Incident("INC-8918", "2 hours ago", AttackType.DATA_EXFILTRATION, Severity.CRITICAL, "194.26.29.114", "Core SQL Database (10.0.1.60)", 68.4, IncidentStatus.RESOLVED, "VLAN Isolation + Key Rotation")
        )
    )
    val incidents: StateFlow<List<Incident>> = _incidents.asStateFlow()

    private val _threatIntelList = MutableStateFlow(
        listOf(
            ThreatIntel("TI-01", "Mirai / Meris Botnet DDoS", "T1498.001", RiskLevel.CRITICAL, "High volumetric UDP/SYN flood originating from compromised IoT camera botnets.", listOf("SYN burst > 5000 PPS", "Random source port spread", "Uniform 64-byte payload"), listOf("Web Application Firewalls", "Load Balancers", "Edge Gateways"), "Implement upstream scrubbing center and enforce BGP Anycast rate limits."),
            ThreatIntel("TI-02", "Masscan / ZMap Stealth Recon", "T1046", RiskLevel.HIGH, "Asynchronous network port scanning targeting ports 22, 80, 443, 3389, and 5432.", listOf("Rapid TCP SYN packets without ACK completion", "Sub-second port traversal"), listOf("DMZ Edge Routers", "Public Services"), "Drop unsolicited TCP probes at border firewall and mask service banners."),
            ThreatIntel("TI-03", "Credential Stuffing & Auth Spraying", "T1110.003", RiskLevel.HIGH, "Distributed login attempts using leaked combo lists against OAuth and SSH services.", listOf("Burst of 401 Unauthorized status codes", "Multiple usernames from single IP pool"), listOf("Auth Servers", "API Gateways"), "Enforce rate limiting, adaptive CAPTCHA, and MFA challenges."),
            ThreatIntel("TI-04", "DNS Tunneling Data Exfiltration", "T1071.004", RiskLevel.CRITICAL, "Encoding stolen sensitive database records into TXT/A subdomains queries.", listOf("High volume of non-cached DNS queries", "High entropy in domain strings (>4.5)"), listOf("Internal DNS Servers", "Active Directory"), "Deploy DNS Response Policy Zones (RPZ) and analyze domain entropy.")
        )
    )
    val threatIntelList: StateFlow<List<ThreatIntel>> = _threatIntelList.asStateFlow()

    private val _leaderboard = MutableStateFlow(
        listOf(
            LeaderboardEntry(1, "cyber_valkyrie", "Elite Defender", 97.8, 98, 1.8, 7, 7200, "Grandmaster Shield"),
            LeaderboardEntry(2, "soc_sentinel (You)", "Security Engineer", 93.4, 91, 2.4, 5, 4850, "Gold Defender"),
            LeaderboardEntry(3, "packet_hunter", "Threat Hunter", 91.2, 89, 2.9, 5, 4400, "Silver Aegis"),
            LeaderboardEntry(4, "zero_day_warden", "SOC Analyst", 88.6, 86, 3.4, 4, 3800, "Bronze Badge"),
            LeaderboardEntry(5, "neuro_guard", "Cyber Recruit", 84.1, 82, 4.1, 3, 2900, "Recruit Star")
        )
    )
    val leaderboard: StateFlow<List<LeaderboardEntry>> = _leaderboard.asStateFlow()

    private val _achievements = MutableStateFlow(
        listOf(
            Achievement("ach_1", "First Defense", "Successfully mitigate your first simulated network attack in Cyber Gym", "Shield", true, 100, "2026-08-20"),
            Achievement("ach_2", "Threat Predictor", "Predict a DDoS attack with >80% probability before network saturation", "TrendingUp", true, 250, "2026-08-22"),
            Achievement("ach_3", "Fast Responder", "Execute containment defense within 3.0 seconds of critical forecast", "Zap", true, 300, "2026-08-24"),
            Achievement("ach_4", "DDoS Defender", "Successfully protect web server infrastructure from volumetric flood", "Security", true, 200, "2026-08-25"),
            Achievement("ach_5", "Perfect Defense", "Achieve a flawless 90+ score across all 5 evaluation metrics", "Star", true, 500, "2026-08-25"),
            Achievement("ach_6", "Threat Hunter", "Identify 3 stealth reconnaissance port scans before service compromise", "Search", false, 350, null),
            Achievement("ach_7", "Incident Commander", "Resolve 10 critical security incidents in the SOC Incident Center", "Award", false, 400, null)
        )
    )
    val achievements: StateFlow<List<Achievement>> = _achievements.asStateFlow()

    private val _datasets = MutableStateFlow(
        listOf(
            DatasetRecord("DS-01", 1420, "TCP", 18500, 14200000L, 49152, 443, 2850.0, 140, "DDOS_SYN_FLOOD"),
            DatasetRecord("DS-02", 340, "TCP", 2400, 153000L, 51200, 22, 420.0, 85, "PORT_SCAN_SYN"),
            DatasetRecord("DS-03", 890, "HTTP", 4500, 2890000L, 53200, 80, 520.0, 42, "BRUTE_FORCE_POST"),
            DatasetRecord("DS-04", 4500, "TCP", 9800, 68000000L, 54100, 443, 680.0, 1, "DATA_EXFILTRATION"),
            DatasetRecord("DS-05", 12000, "HTTPS", 8500, 4200000L, 49800, 443, 140.0, 12, "BENIGN_NORMAL")
        )
    )
    val datasets: StateFlow<List<DatasetRecord>> = _datasets.asStateFlow()

    private val _modelMetrics = MutableStateFlow(ModelMetrics())
    val modelMetrics: StateFlow<ModelMetrics> = _modelMetrics.asStateFlow()

    fun updateNodeState(nodeId: String, state: NodeState, cpu: Int? = null) {
        _networkNodes.value = _networkNodes.value.map { node ->
            if (node.id == nodeId) {
                node.copy(
                    state = state,
                    cpuUsage = cpu ?: node.cpuUsage
                )
            } else node
        }
    }

    fun resetAllNodes() {
        _networkNodes.value = _networkNodes.value.map { it.copy(state = NodeState.NORMAL, cpuUsage = 20) }
    }

    fun addIncident(incident: Incident) {
        _incidents.value = listOf(incident) + _incidents.value
    }

    fun updateIncidentStatus(incidentId: String, newStatus: IncidentStatus) {
        _incidents.value = _incidents.value.map {
            if (it.id == incidentId) it.copy(status = newStatus) else it
        }
    }

    fun addXp(amount: Int) {
        val current = _userProfile.value
        val newXp = current.xp + amount
        val newLevel = if (newXp >= current.nextLevelXp) current.level + 1 else current.level
        val nextXp = if (newXp >= current.nextLevelXp) current.nextLevelXp + 2000 else current.nextLevelXp
        _userProfile.value = current.copy(
            xp = newXp,
            level = newLevel,
            nextLevelXp = nextXp
        )
    }

    fun updateMissionCompleted(missionId: String, score: Int) {
        _missions.value = _missions.value.map {
            if (it.id == missionId) {
                it.copy(
                    completed = true,
                    highScore = maxOf(it.highScore, score)
                )
            } else it
        }
        addXp(250)
    }

    fun retrainModel() {
        val current = _modelMetrics.value
        _modelMetrics.value = current.copy(
            trainingAccuracy = 97.4,
            validationAccuracy = 95.1,
            f1Score = 0.962,
            lastTrained = "Just now (Retrained)",
            version = "v3.5.0-prod"
        )
    }

    fun updateUserRole(newRole: String) {
        _userProfile.value = _userProfile.value.copy(role = newRole)
    }
}
