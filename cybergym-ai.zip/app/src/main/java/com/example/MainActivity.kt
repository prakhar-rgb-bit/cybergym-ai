package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.ui.CyberGymApp
import com.example.ui.theme.CyberGymTheme
import com.example.viewmodel.CyberGymViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: CyberGymViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CyberGymTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    CyberGymApp(viewModel = viewModel)
                }
            }
        }
    }
}
