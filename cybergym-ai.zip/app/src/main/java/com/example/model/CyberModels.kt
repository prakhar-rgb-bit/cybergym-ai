package com.example.model

enum class AttackType(val displayName: String, val code: String) {
    NORMAL("Normal Traffic", "NORM"),
    DDOS("DDoS Attack", "DDOS"),
    PORT_SCAN("Port Scan", "SCAN"),
    BRUTE_FORCE("Brute Force", "BRUTE"),
    BOTNET("Botnet C2 Traffic", "BOTNET"),
    MALWARE("Malware Traffic", "MALWARE"),
    DATA_EXFILTRATION("Data Exfiltration", "EXFIL"),
    SUSPICIOUS_DNS("Suspicious DNS", "DNS_TUNNEL"),
    CREDENTIAL_ATTACK("Credential Attack", "AUTH_SPRAY")
}

enum class Severity(val label: String) {
    LOW("Low"),
    MEDIUM("Medium"),
    HIGH("High"),
    CRITICAL("Critical")
}

enum class RiskLevel(val label: String) {
    LOW("LOW"),
    MEDIUM("MEDIUM"),
    HIGH("HIGH"),
    CRITICAL("CRITICAL")
}

enum class AnomalyClassification(val label: String) {
    NORMAL("Normal"),
    SUSPICIOUS("Suspicious"),
    HIGHLY_SUSPICIOUS("Highly Suspicious"),
    CRITICAL("Critical")
}

enum class NodeState {
    NORMAL,
    SUSPICIOUS,
    COMPROMISED,
    PROTECTED
}

enum class IncidentStatus(val label: String) {
    DETECTED("Detected"),
    INVESTIGATING("Investigating"),
    CONTAINED("Contained"),
    RESOLVED("Resolved")
}

data class CapturedPacket(
    val id: Long,
    val packetNumber: Long,
    val timestamp: String,
    val timestampMillis: Long = System.currentTimeMillis(),
    val protocol: String, // "TCP", "UDP", "DNS", "HTTP", "HTTPS", "ICMP"
    val sourceIp: String,
    val destIp: String,
    val sourcePort: Int,
    val destPort: Int,
    val length: Int,
    val status: String, // "NORMAL", "SUSPICIOUS", "ANOMALOUS", "HIGH_RISK"
    val riskLevel: RiskLevel,
    val anomalyScore: Double,
    val tcpFlags: String = "",
    val dnsQuery: String? = null,
    val direction: String = "INBOUND", // "INBOUND", "OUTBOUND"
    val info: String = "",
    val aiAnalysisReason: String = ""
)

data class NetworkEndpoint(
    val address: String,
    val hostName: String,
    val role: String, // "Local Device", "Gateway Router", "DNS Resolver", "Remote Cloud Endpoint"
    val trafficBytes: Long,
    val packetCount: Long,
    val activeConnections: Int,
    val primaryProtocol: String,
    val riskLevel: RiskLevel,
    val status: String = "ACTIVE", // "ACTIVE", "SUSPICIOUS", "BLOCKED", "RATE_LIMITED"
    val isLocal: Boolean = false
)

enum class MonitoringMode(val label: String) {
    IDLE("Idle"),
    LIVE_VPN("Live VPN Monitor"),
    SIMULATION("CyberGym Simulation"),
    FLOW_ANALYSIS("Flow & Metadata Mode"),
    DEMO("One-Click Walkthrough")
}

enum class CaptureState {
    STOPPED,
    PREPARING,
    RUNNING,
    PAUSED
}

data class TrafficFilterCriteria(
    val query: String = "",
    val protocol: String = "ALL", // "ALL", "TCP", "UDP", "DNS", "HTTP", "HTTPS", "ICMP", "SUSPICIOUS", "HIGH_RISK"
    val sortBy: String = "TIME_DESC" // "TIME_DESC", "TIME_ASC", "RISK", "LENGTH"
)

data class RiskFactor(
    val label: String,
    val weight: Int,
    val description: String
)

data class SecurityRiskScore(
    val score: Int, // 0 - 100
    val threatLevel: RiskLevel,
    val factors: List<RiskFactor>
)

data class ForecastTimelineEvent(
    val time: String,
    val stateLabel: String,
    val attackType: AttackType,
    val probability: Double,
    val anomalyScore: Double,
    val riskLevel: RiskLevel,
    val isCurrent: Boolean = false
)

data class ContributingFeature(
    val featureName: String,
    val observedValue: String,
    val baselineValue: String,
    val deviationMultiplier: Double,
    val contributionPoints: Double,
    val severity: RiskLevel = RiskLevel.LOW,
    val explanation: String
)

data class BaselineProfile(
    val meanPacketRate: Double = 160.0,
    val stdPacketRate: Double = 40.0,
    val meanByteRate: Double = 110.0,
    val stdByteRate: Double = 35.0,
    val expectedMaxSynRatio: Double = 0.18,
    val expectedMaxFailedConns: Int = 3,
    val expectedDistinctPorts: Int = 3,
    val expectedEgressRatio: Double = 0.40
)

data class BaselineAnalysisResult(
    val packetRateDeviationRatio: Double = 1.0,
    val byteRateDeviationRatio: Double = 1.0,
    val synRatioDeviation: Double = 1.0,
    val failedConnsDeviation: Double = 1.0,
    val portDispersionDeviation: Double = 1.0,
    val isElevated: Boolean = false,
    val summary: String = "Traffic features within nominal baseline distribution bounds",
    val deviations: List<ContributingFeature> = emptyList()
)

data class SecurityAlert(
    val id: String,
    val timestamp: String,
    val title: String,
    val attackType: AttackType,
    val severity: Severity,
    val anomalyScore: Double,
    val attackProbability: Double,
    val riskScore: Int,
    val sourceEndpoint: String,
    val targetEndpoint: String,
    val contributingFeatures: List<ContributingFeature>,
    val recommendedAction: String,
    val isAcknowledged: Boolean = false
)

enum class PipelineStage(val stageNumber: Int, val title: String, val subtitle: String) {
    OBSERVED_TRAFFIC(1, "Observed Traffic", "Ingress & flow telemetry capture"),
    FEATURE_EXTRACTION(2, "Feature Extraction", "Vector statistical summarization"),
    BASELINE_ANALYSIS(3, "Baseline Analysis", "Statistical distance from profile"),
    ANOMALY_SCORE(4, "Anomaly Score", "Weighted isolation anomaly evaluation"),
    ATTACK_CLASSIFICATION(5, "Attack Classification", "Heuristic & signature mapping"),
    ATTACK_PROBABILITY(6, "Attack Probability", "Calibrated sigmoid confidence"),
    RISK_SCORE(7, "Risk Score", "Asset & vector threat calculation"),
    ALERT(8, "Alert", "SOC triage & defense notification")
}

data class AiPipelineResult(
    val currentStage: PipelineStage = PipelineStage.ALERT,
    val observedSummary: String = "Nominal background telemetry",
    val trafficFeature: TrafficFeature = TrafficFeature(),
    val baselineAnalysis: BaselineAnalysisResult = BaselineAnalysisResult(),
    val anomalyResult: AnomalyResult = AnomalyResult(12.0, AnomalyClassification.NORMAL, emptyList(), false),
    val classifiedAttack: AttackType = AttackType.NORMAL,
    val attackProbability: Double = 8.0,
    val securityRiskScore: SecurityRiskScore = SecurityRiskScore(15, RiskLevel.LOW, emptyList()),
    val activeAlert: SecurityAlert? = null,
    val contributingFeatures: List<ContributingFeature> = emptyList(),
    val timestamp: Long = System.currentTimeMillis()
)

data class TrafficFeature(
    val packetCount: Long = 1200L,
    val packetRate: Double = 120.0, // PPS
    val byteRate: Double = 85.4,   // KB/s
    val srcIpFrequency: Int = 14,
    val dstIpFrequency: Int = 3,
    val srcPort: Int = 49152,
    val dstPort: Int = 443,
    val protocol: String = "HTTPS/TCP",
    val connectionDuration: Long = 240L, // ms
    val failedConnections: Int = 1,
    val tcpFlags: String = "ACK, PSH",
    val flowDuration: Long = 4500L,
    val packetSize: Int = 780, // bytes
    val requestFrequency: Double = 8.5,
    val synRatio: Double = 0.05,
    val uniqueDstPorts: Int = 2,
    val uniqueSrcIps: Int = 3,
    val egressRatio: Double = 0.35,
    val dnsEntropy: Double = 0.15
)

data class AnomalyResult(
    val anomalyScore: Double, // 0 - 100
    val classification: AnomalyClassification,
    val contributingFeatures: List<String>,
    val isAnomaly: Boolean,
    val richContributingFeatures: List<ContributingFeature> = emptyList()
)

data class AttackForecast(
    val attackType: AttackType,
    val probability: Double, // 0 - 100
    val confidence: String, // Low / Medium / High
    val riskLevel: RiskLevel,
    val forecastWindow: String, // e.g. "Next 2–5 minutes"
    val contributingFeatures: List<String>,
    val recommendedActions: List<String>,
    val explainableSummary: String,
    val timestamp: Long = System.currentTimeMillis(),
    val richContributingFeatures: List<ContributingFeature> = emptyList()
)

data class ProbabilityBreakdown(
    val attackType: AttackType,
    val probability: Double,
    val trend: String // "Rising", "Stable", "Falling"
)

data class NetworkNode(
    val id: String,
    val name: String,
    val role: String,
    val state: NodeState = NodeState.NORMAL,
    val ip: String,
    val cpuUsage: Int = 18,
    val memoryUsage: Int = 32,
    val inboundMbps: Double = 1.2,
    val outboundMbps: Double = 0.8,
    val activeConns: Int = 24,
    val xRatio: Float = 0.5f,
    val yRatio: Float = 0.5f
)

data class DefenseAction(
    val id: String,
    val name: String,
    val category: String,
    val description: String,
    val effectivenessScore: Int = 90,
    val iconName: String = "Shield"
)

data class DefenseEvaluation(
    val detectionAccuracy: Double,
    val responseTimeSeconds: Double,
    val defenseEffectiveness: Double,
    val damagePrevented: Double,
    val decisionQuality: Double,
    val finalScore: Int,
    val aiFeedback: String,
    val badgeUnlocked: String? = null
)

data class Incident(
    val id: String,
    val timestamp: String,
    val attackType: AttackType,
    val severity: Severity,
    val sourceIp: String,
    val targetHost: String,
    val aiProbability: Double,
    var status: IncidentStatus,
    val mitigationAction: String = "None applied"
)

data class Mission(
    val id: String,
    val number: String,
    val title: String,
    val objective: String,
    val threat: AttackType,
    val timeLimitSeconds: Int,
    val hints: List<String>,
    val difficulty: String,
    val xpReward: Int,
    var completed: Boolean = false,
    var highScore: Int = 0
)

data class ThreatIntel(
    val id: String,
    val threatType: String,
    val mitreId: String,
    val risk: RiskLevel,
    val observedBehavior: String,
    val indicators: List<String>,
    val affectedSystems: List<String>,
    val recommendedDefense: String
)

data class UserProfile(
    val name: String = "Alex Mercer",
    val username: String = "soc_sentinel",
    val email: String = "alex.mercer@cybergym.io",
    val role: String = "Blue Team Defender",
    val rank: String = "Security Engineer",
    val level: Int = 7,
    val xp: Int = 4850,
    val nextLevelXp: Int = 6000,
    val completedMissionsCount: Int = 5,
    val averageDefenseScore: Int = 89,
    val forecastAccuracy: Double = 93.4
)

data class LeaderboardEntry(
    val rank: Int,
    val username: String,
    val userRole: String,
    val forecastAccuracy: Double,
    val defenseScore: Int,
    val avgResponseTime: Double,
    val missionsCompleted: Int,
    val totalXp: Int,
    val badge: String
)

data class Achievement(
    val id: String,
    val title: String,
    val description: String,
    val icon: String,
    val unlocked: Boolean,
    val xp: Int,
    val unlockedAt: String? = null
)

data class DatasetRecord(
    val id: String,
    val flowDuration: Int,
    val protocol: String,
    val packetCount: Int,
    val byteCount: Long,
    val srcPort: Int,
    val dstPort: Int,
    val packetRate: Double,
    val connectionCount: Int,
    val attackLabel: String
)

data class ModelMetrics(
    val modelName: String = "IsolationForest + XGBoost Ensemble",
    val version: String = "v3.4.2-prod",
    val trainingAccuracy: Double = 96.8,
    val validationAccuracy: Double = 94.2,
    val f1Score: Double = 0.954,
    val lastTrained: String = "2026-08-24 14:30 UTC",
    val featuresUsed: List<String> = listOf(
        "Packet Rate (PPS)",
        "Byte Rate (KB/s)",
        "SYN/ACK Ratio",
        "Source IP Entropy",
        "Failed Conn Burst",
        "Port Frequency",
        "Connection Duration",
        "DGA Domain Score"
    ),
    val isTrained: Boolean = true
)

data class LiveDemoPhase(
    val phaseNumber: Int,
    val title: String,
    val subtitle: String,
    val pps: Double,
    val anomalyScore: Double,
    val predictedAttack: AttackType,
    val probability: Double,
    val threatLevel: RiskLevel,
    val statusText: String,
    val targetNodeId: String = "web_server",
    val activeDefenseChosen: String? = null
)
