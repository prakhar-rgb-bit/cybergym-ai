package com.example.ui

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CrisisAlert
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Leaderboard
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SportsKabaddi
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.AdminScreen
import com.example.ui.screens.AnalyticsScreen
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.BlueTeamScreen
import com.example.ui.screens.CyberGymScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.ForecastScreen
import com.example.ui.screens.IncidentCenterScreen
import com.example.ui.screens.LandingScreen
import com.example.ui.screens.LeaderboardScreen
import com.example.ui.screens.LiveDemoScreen
import com.example.ui.screens.MissionsScreen
import com.example.ui.screens.NetworkMonitorScreen
import com.example.ui.screens.ProfileSettingsScreen
import com.example.ui.screens.RedTeamScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.ThreatIntelScreen
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberBgDark
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberBorderBright
import com.example.ui.theme.CyberCrimson
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberEmerald
import com.example.ui.theme.CyberSurfaceCard
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.CyberGymViewModel
import com.example.viewmodel.ScreenRoute
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CyberGymApp(
    viewModel: CyberGymViewModel,
    modifier: Modifier = Modifier
) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val isAttackActive by viewModel.isAttackActive.collectAsState()
    val incidents by viewModel.repository.incidents.collectAsState()
    val userProfile by viewModel.repository.userProfile.collectAsState()

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = CyberBgDark,
                modifier = Modifier
                    .width(300.dp)
                    .border(1.dp, CyberBorder, RoundedCornerShape(topEnd = 16.dp, bottomEnd = 16.dp))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    // Drawer Header
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(CyberCyan.copy(alpha = 0.2f))
                                .border(1.5.dp, CyberCyan, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(24.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "CYBERGYM AI",
                                color = TextPrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "Network Defense Platform",
                                color = CyberCyan,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(CyberBorder))
                    Spacer(modifier = Modifier.height(12.dp))

                    Text(text = "CORE OPERATIONS", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(6.dp))

                    DrawerItem("Home & Pitch", Icons.Default.Home, currentScreen == ScreenRoute.LANDING) {
                        viewModel.navigateTo(ScreenRoute.LANDING)
                        scope.launch { drawerState.close() }
                    }
                    DrawerItem("Main SOC Dashboard", Icons.Default.CrisisAlert, currentScreen == ScreenRoute.DASHBOARD) {
                        viewModel.navigateTo(ScreenRoute.DASHBOARD)
                        scope.launch { drawerState.close() }
                    }
                    DrawerItem("AI Attack Forecast", Icons.Default.Psychology, currentScreen == ScreenRoute.FORECAST) {
                        viewModel.navigateTo(ScreenRoute.FORECAST)
                        scope.launch { drawerState.close() }
                    }
                    DrawerItem("Network Traffic Monitor", Icons.Default.Speed, currentScreen == ScreenRoute.NETWORK_MONITOR) {
                        viewModel.navigateTo(ScreenRoute.NETWORK_MONITOR)
                        scope.launch { drawerState.close() }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(text = "CYBER GYM & SIMULATION", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(6.dp))

                    DrawerItem("One-Click Live Demo", Icons.Default.PlayArrow, currentScreen == ScreenRoute.LIVE_DEMO, badge = "10 Phases") {
                        viewModel.navigateTo(ScreenRoute.LIVE_DEMO)
                        scope.launch { drawerState.close() }
                    }
                    DrawerItem("Cyber Gym Range", Icons.Default.Hub, currentScreen == ScreenRoute.CYBER_GYM) {
                        viewModel.navigateTo(ScreenRoute.CYBER_GYM)
                        scope.launch { drawerState.close() }
                    }
                    DrawerItem("Red Team Offensive", Icons.Default.SportsKabaddi, currentScreen == ScreenRoute.RED_TEAM) {
                        viewModel.navigateTo(ScreenRoute.RED_TEAM)
                        scope.launch { drawerState.close() }
                    }
                    DrawerItem("Blue Team Defense", Icons.Default.Shield, currentScreen == ScreenRoute.BLUE_TEAM) {
                        viewModel.navigateTo(ScreenRoute.BLUE_TEAM)
                        scope.launch { drawerState.close() }
                    }
                    DrawerItem("Training Missions", Icons.Default.MilitaryTech, currentScreen == ScreenRoute.MISSIONS, badge = "7 Miss.") {
                        viewModel.navigateTo(ScreenRoute.MISSIONS)
                        scope.launch { drawerState.close() }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(text = "SOC INTELLIGENCE & AUDIT", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(6.dp))

                    DrawerItem("Incident Center", Icons.Default.Security, currentScreen == ScreenRoute.INCIDENT_CENTER, badge = "${incidents.size}") {
                        viewModel.navigateTo(ScreenRoute.INCIDENT_CENTER)
                        scope.launch { drawerState.close() }
                    }
                    DrawerItem("Threat Intelligence (MITRE)", Icons.Default.CrisisAlert, currentScreen == ScreenRoute.THREAT_INTEL) {
                        viewModel.navigateTo(ScreenRoute.THREAT_INTEL)
                        scope.launch { drawerState.close() }
                    }
                    DrawerItem("Security Analytics", Icons.Default.Assessment, currentScreen == ScreenRoute.ANALYTICS) {
                        viewModel.navigateTo(ScreenRoute.ANALYTICS)
                        scope.launch { drawerState.close() }
                    }
                    DrawerItem("Executive Reports", Icons.Default.Assessment, currentScreen == ScreenRoute.REPORTS) {
                        viewModel.navigateTo(ScreenRoute.REPORTS)
                        scope.launch { drawerState.close() }
                    }
                    DrawerItem("Leaderboard & Badges", Icons.Default.Leaderboard, currentScreen == ScreenRoute.LEADERBOARD) {
                        viewModel.navigateTo(ScreenRoute.LEADERBOARD)
                        scope.launch { drawerState.close() }
                    }
                    DrawerItem("Admin & ML Retraining", Icons.Default.AdminPanelSettings, currentScreen == ScreenRoute.ADMIN) {
                        viewModel.navigateTo(ScreenRoute.ADMIN)
                        scope.launch { drawerState.close() }
                    }
                    DrawerItem("Settings & Profile", Icons.Default.Settings, currentScreen == ScreenRoute.SETTINGS) {
                        viewModel.navigateTo(ScreenRoute.SETTINGS)
                        scope.launch { drawerState.close() }
                    }

                    Spacer(modifier = Modifier.height(20.dp))
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = "SOC SENTINEL v4.2",
                                color = CyberCyan,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.6.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "CYBER",
                                    color = TextPrimary,
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Light
                                )
                                Text(
                                    text = "GYM ",
                                    color = TextPrimary,
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Black
                                )
                                Text(
                                    text = "AI",
                                    color = CyberCyan,
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = { scope.launch { drawerState.open() } },
                            modifier = Modifier.testTag("drawer_toggle_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Menu,
                                contentDescription = "Open Navigation Menu",
                                tint = CyberCyan
                            )
                        }
                    },
                    actions = {
                        // Live Status Indicator
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(CyberEmerald)
                        )
                        Spacer(modifier = Modifier.width(10.dp))

                        // User initials avatar badge
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(CyberSurfaceVariant)
                                .border(1.dp, CyberBorderBright, CircleShape)
                                .clickable { viewModel.navigateTo(ScreenRoute.SETTINGS) }
                                .testTag("topbar_avatar_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "JD",
                                color = CyberCyan,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))

                        // Incidents Alert Badge
                        IconButton(
                            onClick = { viewModel.navigateTo(ScreenRoute.INCIDENT_CENTER) },
                            modifier = Modifier.testTag("topbar_incidents_button")
                        ) {
                            Box {
                                Icon(
                                    imageVector = Icons.Default.Notifications,
                                    contentDescription = "Notifications",
                                    tint = if (isAttackActive) CyberCrimson else TextSecondary
                                )
                                if (isAttackActive || incidents.isNotEmpty()) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(CyberCrimson)
                                            .align(Alignment.TopEnd)
                                    )
                                }
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = CyberBgDark
                    )
                )
            },
            bottomBar = {
                NavigationBar(
                    containerColor = com.example.ui.theme.CyberBgNav,
                    contentColor = CyberCyan,
                    modifier = Modifier.border(1.dp, CyberBorder)
                ) {
                    NavigationBarItem(
                        selected = currentScreen == ScreenRoute.LANDING,
                        onClick = { viewModel.navigateTo(ScreenRoute.LANDING) },
                        icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                        label = { Text("Home", fontSize = 10.sp) },
                        colors = navItemColors(),
                        modifier = Modifier.testTag("nav_home")
                    )
                    NavigationBarItem(
                        selected = currentScreen == ScreenRoute.DASHBOARD,
                        onClick = { viewModel.navigateTo(ScreenRoute.DASHBOARD) },
                        icon = { Icon(Icons.Default.CrisisAlert, contentDescription = "Dashboard") },
                        label = { Text("SOC", fontSize = 10.sp) },
                        colors = navItemColors(),
                        modifier = Modifier.testTag("nav_dashboard")
                    )
                    NavigationBarItem(
                        selected = currentScreen == ScreenRoute.FORECAST,
                        onClick = { viewModel.navigateTo(ScreenRoute.FORECAST) },
                        icon = { Icon(Icons.Default.Psychology, contentDescription = "AI Forecast") },
                        label = { Text("Forecast", fontSize = 10.sp) },
                        colors = navItemColors(),
                        modifier = Modifier.testTag("nav_forecast")
                    )
                    NavigationBarItem(
                        selected = currentScreen == ScreenRoute.CYBER_GYM,
                        onClick = { viewModel.navigateTo(ScreenRoute.CYBER_GYM) },
                        icon = { Icon(Icons.Default.Hub, contentDescription = "Cyber Gym") },
                        label = { Text("Gym", fontSize = 10.sp) },
                        colors = navItemColors(),
                        modifier = Modifier.testTag("nav_gym")
                    )
                    NavigationBarItem(
                        selected = currentScreen == ScreenRoute.MISSIONS,
                        onClick = { viewModel.navigateTo(ScreenRoute.MISSIONS) },
                        icon = { Icon(Icons.Default.MilitaryTech, contentDescription = "Missions") },
                        label = { Text("Missions", fontSize = 10.sp) },
                        colors = navItemColors(),
                        modifier = Modifier.testTag("nav_missions")
                    )
                }
            }
        ) { innerPadding ->
            Crossfade(
                targetState = currentScreen,
                label = "screen_transition",
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(CyberBgDark)
            ) { screen ->
                when (screen) {
                    ScreenRoute.LANDING -> LandingScreen(viewModel = viewModel)
                    ScreenRoute.DASHBOARD -> DashboardScreen(viewModel = viewModel)
                    ScreenRoute.FORECAST -> ForecastScreen(viewModel = viewModel)
                    ScreenRoute.NETWORK_MONITOR -> NetworkMonitorScreen(viewModel = viewModel)
                    ScreenRoute.CYBER_GYM -> CyberGymScreen(viewModel = viewModel)
                    ScreenRoute.LIVE_DEMO -> LiveDemoScreen(viewModel = viewModel)
                    ScreenRoute.RED_TEAM -> RedTeamScreen(viewModel = viewModel)
                    ScreenRoute.BLUE_TEAM -> BlueTeamScreen(viewModel = viewModel)
                    ScreenRoute.MISSIONS -> MissionsScreen(viewModel = viewModel)
                    ScreenRoute.INCIDENT_CENTER -> IncidentCenterScreen(viewModel = viewModel)
                    ScreenRoute.THREAT_INTEL -> ThreatIntelScreen(viewModel = viewModel)
                    ScreenRoute.ANALYTICS -> AnalyticsScreen(viewModel = viewModel)
                    ScreenRoute.REPORTS -> ReportsScreen(viewModel = viewModel)
                    ScreenRoute.LEADERBOARD -> LeaderboardScreen(viewModel = viewModel)
                    ScreenRoute.ADMIN -> AdminScreen(viewModel = viewModel)
                    ScreenRoute.AUTH -> AuthScreen(viewModel = viewModel)
                    ScreenRoute.SETTINGS -> ProfileSettingsScreen(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
private fun DrawerItem(
    title: String,
    icon: ImageVector,
    isSelected: Boolean,
    badge: String? = null,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) CyberCyan.copy(alpha = 0.15f) else Color.Transparent)
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isSelected) CyberCyan else TextSecondary,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = title,
                color = if (isSelected) CyberCyan else TextPrimary,
                fontSize = 13.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
            )
        }

        if (badge != null) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(CyberSurfaceVariant)
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = badge,
                    color = CyberCyan,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
private fun navItemColors() = NavigationBarItemDefaults.colors(
    selectedIconColor = CyberCyan,
    selectedTextColor = CyberCyan,
    indicatorColor = CyberCyan.copy(alpha = 0.15f),
    unselectedIconColor = TextSecondary,
    unselectedTextColor = TextMuted
)
