package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Mission
import com.example.ui.components.CyberCard
import com.example.ui.components.CyberPrimaryButton
import com.example.ui.components.CyberSecondaryButton
import com.example.ui.components.LivePulseDot
import com.example.ui.components.SectionHeader
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberCrimson
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberEmerald
import com.example.ui.theme.CyberSurfaceCard
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.CyberGymViewModel
import com.example.viewmodel.ScreenRoute

@Composable
fun MissionsScreen(
    viewModel: CyberGymViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val missions by viewModel.repository.missions.collectAsState()
    val selectedMission by viewModel.selectedMission.collectAsState()
    val secondsLeft by viewModel.missionSecondsLeft.collectAsState()
    val isAttacking by viewModel.isAttackActive.collectAsState()

    var activeMissionModal by remember { mutableStateOf<Mission?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "CYBER DEFENSE ACADEMY",
                    color = CyberCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Training Missions (1–7)",
                    color = TextPrimary,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black
                )
            }
            LivePulseDot(label = "7 MISSIONS")
        }

        // Active Mission HUD Banner
        if (isAttacking && selectedMission != null) {
            val m = selectedMission!!
            Spacer(modifier = Modifier.height(14.dp))
            CyberCard(
                borderColor = CyberAmber,
                backgroundColor = Color(0xFF1E1704)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "ACTIVE MISSION: ${m.number}", color = CyberAmber, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        Text(text = m.title, color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Black)
                    }
                    Text(
                        text = "${secondsLeft}s",
                        color = if (secondsLeft < 15) CyberCrimson else CyberAmber,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CyberPrimaryButton(
                        text = "Go to Blue Defense 🛡️",
                        onClick = { viewModel.navigateTo(ScreenRoute.BLUE_TEAM) },
                        modifier = Modifier.weight(1f)
                    )
                    CyberSecondaryButton(
                        text = "Complete",
                        onClick = { viewModel.completeCurrentMission(92) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Missions List
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            missions.forEach { mission ->
                val diffColor = when (mission.difficulty) {
                    "Beginner" -> CyberEmerald
                    "Intermediate" -> CyberCyan
                    "Advanced" -> CyberAmber
                    else -> CyberCrimson
                }

                CyberCard(
                    modifier = Modifier.clickable { activeMissionModal = mission },
                    borderColor = if (mission.completed) CyberEmerald.copy(alpha = 0.5f) else CyberBorder,
                    backgroundColor = CyberSurfaceCard
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(if (mission.completed) CyberEmerald.copy(alpha = 0.2f) else CyberSurfaceVariant),
                                contentAlignment = Alignment.Center
                            ) {
                                if (mission.completed) {
                                    Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = CyberEmerald, modifier = Modifier.size(20.dp))
                                } else {
                                    Text(text = mission.number.takeLast(2), color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                }
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(text = mission.number, color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                Text(text = mission.title, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(diffColor.copy(alpha = 0.2f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(text = mission.difficulty, color = diffColor, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = mission.objective, color = TextSecondary, fontSize = 12.sp, maxLines = 2)

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "Reward: +${mission.xpReward} XP", color = CyberCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        if (mission.completed) {
                            Text(text = "High Score: ${mission.highScore}%", color = CyberEmerald, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        } else {
                            Text(text = "Tap to Launch →", color = CyberAmber, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }

        // Mission Detail Bottom Sheet / Modal
        activeMissionModal?.let { m ->
            Spacer(modifier = Modifier.height(16.dp))
            CyberCard(
                borderColor = CyberCyan,
                backgroundColor = Color(0xFF0F172A)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "${m.number}: ${m.title}", color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text(text = "${m.timeLimitSeconds}s Limit", color = CyberAmber, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(text = m.objective, color = TextSecondary, fontSize = 13.sp)

                Spacer(modifier = Modifier.height(10.dp))
                Text(text = "TACTICAL HINTS:", color = CyberCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                m.hints.forEach { h ->
                    Row(modifier = Modifier.padding(vertical = 2.dp), verticalAlignment = Alignment.Top) {
                        Text(text = "• ", color = CyberCyan, fontSize = 12.sp)
                        Text(text = h, color = TextSecondary, fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CyberSecondaryButton(
                        text = "Dismiss",
                        onClick = { activeMissionModal = null },
                        modifier = Modifier.weight(1f)
                    )
                    CyberPrimaryButton(
                        text = "Start Mission",
                        icon = Icons.Default.PlayArrow,
                        onClick = {
                            viewModel.startMission(m)
                            activeMissionModal = null
                        },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}
