package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CrisisAlert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SportsKabaddi
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CyberCard
import com.example.ui.components.CyberPrimaryButton
import com.example.ui.components.CyberSecondaryButton
import com.example.ui.components.LivePulseDot
import com.example.ui.components.MetricPill
import com.example.ui.components.SectionHeader
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberCrimson
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberEmerald
import com.example.ui.theme.CyberPurple
import com.example.ui.theme.CyberSurfaceCard
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.CyberGymViewModel
import com.example.viewmodel.ScreenRoute

@Composable
fun RedTeamScreen(
    viewModel: CyberGymViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    val isAttacking by viewModel.isAttackActive.collectAsState()
    val activeScenario by viewModel.activeScenario.collectAsState()
    val pps by viewModel.packetRate.collectAsState()
    val anomaly by viewModel.anomalyResult.collectAsState()

    var selectedAttack by remember { mutableStateOf("DDOS") }
    var selectedDifficulty by remember { mutableStateOf("Intermediate") }
    var selectedTarget by remember { mutableStateOf("Web Server (10.0.1.50)") }

    val attackScenarios = listOf(
        Pair("DDOS", "Volumetric SYN Flood"),
        Pair("PORT_SCAN", "Reconnaissance Port Sweep"),
        Pair("BRUTE_FORCE", "SSH / HTTP Credential Spray"),
        Pair("DATA_EXFILTRATION", "Encrypted Database Egress"),
        Pair("BOTNET", "C2 Beaconing Traffic")
    )

    val difficulties = listOf("Beginner", "Intermediate", "Advanced", "Expert")

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "RED TEAM ATTACK SIMULATOR",
                    color = CyberCrimson,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Adversary Simulation",
                    color = TextPrimary,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black
                )
            }
            LivePulseDot(
                color = if (isAttacking) CyberCrimson else CyberCyan,
                label = if (isAttacking) "ATTACK INJECTED" else "OFFENSIVE STANDBY"
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Scenario Selector
        SectionHeader(
            title = "Select Offensive Vector",
            subtitle = "Targeted cyber threat signature"
        )

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            attackScenarios.forEach { (type, name) ->
                val isSelected = selectedAttack == type
                CyberCard(
                    modifier = Modifier.clickable { selectedAttack = type },
                    borderColor = if (isSelected) CyberCrimson else CyberBorder,
                    backgroundColor = if (isSelected) CyberCrimson.copy(alpha = 0.1f) else CyberSurfaceCard
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = name,
                                color = if (isSelected) CyberCrimson else TextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Class: $type",
                                color = TextMuted,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Default.CrisisAlert,
                                contentDescription = null,
                                tint = CyberCrimson,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Difficulty Selector
        SectionHeader(
            title = "Adversary Skill / Difficulty",
            subtitle = "Controls evasion stealth and burst frequency"
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            difficulties.forEach { diff ->
                val isSel = selectedDifficulty == diff
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isSel) CyberCrimson else CyberSurfaceVariant)
                        .border(1.dp, if (isSel) CyberCrimson else CyberBorder, RoundedCornerShape(6.dp))
                        .clickable { selectedDifficulty = diff }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = diff,
                        color = if (isSel) Color.White else TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Trigger / Stop Simulation Button
        if (!isAttacking) {
            Button(
                onClick = { viewModel.startRedTeamScenario(selectedAttack, selectedDifficulty) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CyberCrimson),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Launch Simulated $selectedAttack Attack",
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp
                )
            }
        } else {
            Button(
                onClick = { viewModel.stopRedTeamScenario() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(imageVector = Icons.Default.Stop, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Stop Active Simulation ($activeScenario)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Switch to Blue Team Quick CTA
        CyberSecondaryButton(
            text = "Switch to Blue Team Defense Console →",
            icon = Icons.Default.Security,
            onClick = { viewModel.navigateTo(ScreenRoute.BLUE_TEAM) },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(24.dp))
    }
}
