package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CrisisAlert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.RiskLevel
import com.example.ui.components.CyberCard
import com.example.ui.components.CyberPrimaryButton
import com.example.ui.components.CyberSecondaryButton
import com.example.ui.components.LivePulseDot
import com.example.ui.components.MetricPill
import com.example.ui.components.SectionHeader
import com.example.ui.components.ThreatBadge
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberCrimson
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberEmerald
import com.example.ui.theme.CyberPurple
import com.example.ui.theme.CyberSurfaceCard
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.CyberGymViewModel

@Composable
fun LiveDemoScreen(
    viewModel: CyberGymViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    val phaseIdx by viewModel.liveDemoPhaseIndex.collectAsState()
    val isRunning by viewModel.isLiveDemoRunning.collectAsState()
    val evaluation by viewModel.latestEvaluation.collectAsState()

    val currentPhase = viewModel.liveDemoPhases.getOrNull(phaseIdx) ?: viewModel.liveDemoPhases.first()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "AI DEFENSE EVALUATION MODE",
                    color = CyberCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "One-Click Live Demo",
                    color = TextPrimary,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black
                )
            }
            LivePulseDot(label = "DEMO ENGINE")
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Progress Bar for 10 Phases
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "PHASE ${phaseIdx + 1} OF 10",
                color = CyberCyan,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = "${((phaseIdx + 1) * 10)}% COMPLETED",
                color = TextSecondary,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        LinearProgressIndicator(
            progress = { (phaseIdx + 1) / 10f },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = CyberCyan,
            trackColor = CyberSurfaceVariant
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Current Phase Showcase Card
        CyberCard(
            borderColor = if (currentPhase.threatLevel == RiskLevel.CRITICAL) CyberCrimson else CyberCyan,
            backgroundColor = CyberSurfaceCard
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = currentPhase.title,
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace
                )
                ThreatBadge(risk = currentPhase.threatLevel)
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = currentPhase.subtitle,
                color = TextSecondary,
                fontSize = 13.sp
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Real-time parameters during this phase
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricPill("Rate (PPS)", "${currentPhase.pps.toInt()} PPS", accentColor = CyberCyan, modifier = Modifier.weight(1f))
                MetricPill("Anomaly Score", "${currentPhase.anomalyScore.toInt()}/100", accentColor = if (currentPhase.anomalyScore > 60) CyberCrimson else CyberEmerald, modifier = Modifier.weight(1f))
                MetricPill("Probability", "${currentPhase.probability.toInt()}%", accentColor = if (currentPhase.probability > 70) CyberCrimson else CyberCyan, modifier = Modifier.weight(1f))
            }

            Spacer(modifier = Modifier.height(12.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(CyberSurfaceVariant)
                    .padding(10.dp)
            ) {
                Text(
                    text = "Status: ${currentPhase.statusText}",
                    color = TextPrimary,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Demo Controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            CyberSecondaryButton(
                text = "Previous",
                icon = Icons.Default.ArrowBack,
                onClick = { viewModel.stepLiveDemoPrev() },
                modifier = Modifier.weight(1f)
            )

            CyberPrimaryButton(
                text = if (isRunning) "Running Demo..." else "Auto Play 10 Phases",
                icon = Icons.Default.PlayArrow,
                onClick = { viewModel.startLiveDemo() },
                modifier = Modifier.weight(1.5f)
            )

            CyberSecondaryButton(
                text = "Next",
                icon = Icons.Default.ArrowForward,
                onClick = { viewModel.stepLiveDemoNext() },
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Judge Scorecard Banner (Phases 9 & 10)
        if (phaseIdx >= 8 || evaluation != null) {
            CyberCard(
                borderColor = CyberEmerald,
                backgroundColor = Color(0xFF071B17)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = CyberEmerald,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "ATTACK FORECAST SUCCESSFUL",
                        color = CyberEmerald,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Threat vector predicted 2.8 minutes before peak network saturation. Proactive Rate Limiting and ACL containment mitigated all downstream degradation.",
                    color = TextPrimary,
                    fontSize = 12.sp,
                    lineHeight = 17.sp
                )

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    ScorecardPill("Forecast Accuracy", "94%", CyberCyan)
                    ScorecardPill("Defense Score", "91/100", CyberEmerald)
                    ScorecardPill("Response Time", "2.4 sec", CyberPurple)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Phase Walkthrough Timeline
        SectionHeader(
            title = "10-Phase Demonstration Sequence",
            subtitle = "Step-by-step evaluation timeline"
        )

        viewModel.liveDemoPhases.forEachIndexed { idx, p ->
            val isCurrent = idx == phaseIdx
            val isPast = idx < phaseIdx

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(
                            if (isCurrent) CyberCyan
                            else if (isPast) CyberEmerald
                            else CyberSurfaceVariant
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${idx + 1}",
                        color = if (isCurrent || isPast) Color(0xFF031B20) else TextMuted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = p.title,
                        color = if (isCurrent) CyberCyan else if (isPast) TextPrimary else TextMuted,
                        fontSize = 12.sp,
                        fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium
                    )
                    Text(
                        text = p.subtitle,
                        color = TextSecondary,
                        fontSize = 10.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun ScorecardPill(label: String, value: String, color: Color) {
    Column {
        Text(text = label, color = TextMuted, fontSize = 10.sp)
        Text(text = value, color = color, fontSize = 16.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
    }
}
