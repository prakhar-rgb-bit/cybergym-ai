package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sophisticated Dark SOC Theme Palette
val CyberBgDark = Color(0xFF050505)           // #050505 ultra-deep black canvas
val CyberBgNav = Color(0xFF0A0A0C)            // #0A0A0C refined bottom/top bar
val CyberSurfaceDark = Color(0xFF0B111E)      // elevated dark slate surface
val CyberSurfaceVariant = Color(0xFF141E33)   // slate-900 variant
val CyberSurfaceCard = Color(0xFF0D1527)      // slate-900/50 card background
val CyberBorder = Color(0xFF1E293B)           // slate-800 border
val CyberBorderGlow = Color(0xFF1E3A8A)       // subtle blue glow
val CyberBorderBright = Color(0xFF334155)     // slate-700 border accent

// Accents
val CyberCyan = Color(0xFF22D3EE)             // cyan-400 vibrant tech highlight
val CyberCyanMuted = Color(0xFF0891B2)        // cyan-600 muted tech accent
val CyberCyanLight = Color(0xFF67E8F9)        // cyan-300 bright text/glow
val CyberBlue = Color(0xFF3B82F6)             // blue-500
val CyberPurple = Color(0xFFA855F7)           // purple-500
val CyberEmerald = Color(0xFF22C55E)          // green-500 live status
val CyberAmber = Color(0xFFF59E0B)            // amber-500 warning
val CyberCrimson = Color(0xFFEF4444)          // red-500 critical attack alert
val CyberCrimsonDark = Color(0xFF7F1D1D)      // red-900 alert gradient end

// Text Colors
val TextPrimary = Color(0xFFFFFFFF)           // pure crisp white
val TextSecondary = Color(0xFF94A3B8)         // slate-400 readable subtitle
val TextMuted = Color(0xFF64748B)             // slate-500 subtle meta text
val TextCyan = Color(0xFF22D3EE)              // cyan-400 accent text

// Status Colors
val StatusSafe = Color(0xFF22C55E)
val StatusWarning = Color(0xFFF59E0B)
val StatusDanger = Color(0xFFEF4444)
val StatusInfo = Color(0xFF22D3EE)
val StatusProtected = Color(0xFF818CF8)


