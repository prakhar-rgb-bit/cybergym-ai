package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SportsKabaddi
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CyberCard
import com.example.ui.components.CyberPrimaryButton
import com.example.ui.components.CyberSecondaryButton
import com.example.ui.components.LivePulseDot
import com.example.ui.components.SectionHeader
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberCrimson
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberEmerald
import com.example.ui.theme.CyberPurple
import com.example.ui.theme.CyberSurfaceCard
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.CyberGymViewModel
import com.example.viewmodel.ScreenRoute

@Composable
fun AuthScreen(
    viewModel: CyberGymViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    var isRegister by remember { mutableStateOf(false) }
    var email by remember { mutableStateOf("soc_sentinel@cybergym.ai") }
    var password by remember { mutableStateOf("••••••••") }
    var selectedRole by remember { mutableStateOf("Blue Team Defender") }

    val roles = listOf("Blue Team Defender", "Red Team Analyst", "SOC Admin", "Academic / Student")

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(20.dp))

        Box(
            modifier = Modifier
                .size(60.dp)
                .clip(CircleShape)
                .background(CyberCyan.copy(alpha = 0.15f))
                .border(2.dp, CyberCyan, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(32.dp))
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "CYBERGYM AI AUTHENTICATION",
            color = TextPrimary,
            fontSize = 18.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace
        )
        Text(
            text = if (isRegister) "Register Operator Profile" else "SOC Access Gateway",
            color = TextSecondary,
            fontSize = 13.sp
        )

        Spacer(modifier = Modifier.height(24.dp))

        CyberCard(
            borderColor = CyberCyan.copy(alpha = 0.5f),
            backgroundColor = CyberSurfaceCard
        ) {
            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Operator Email / Call-Sign") },
                leadingIcon = { Icon(imageVector = Icons.Default.Email, contentDescription = null, tint = CyberCyan) },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyberCyan,
                    unfocusedBorderColor = CyberBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Access Key / Token") },
                leadingIcon = { Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = CyberCyan) },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyberCyan,
                    unfocusedBorderColor = CyberBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "OPERATIONAL ROLE ASSIGNMENT:",
                color = TextMuted,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(6.dp))

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                roles.forEach { role ->
                    val isSel = selectedRole == role
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSel) CyberCyan.copy(alpha = 0.2f) else CyberSurfaceVariant)
                            .border(1.dp, if (isSel) CyberCyan else CyberBorder, RoundedCornerShape(6.dp))
                            .clickable { selectedRole = role }
                            .padding(10.dp)
                    ) {
                        Text(
                            text = role,
                            color = if (isSel) CyberCyan else TextPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            CyberPrimaryButton(
                text = if (isRegister) "Create Profile & Enter" else "Authenticate & Access SOC",
                icon = Icons.Default.Login,
                onClick = { viewModel.login(selectedRole) },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = if (isRegister) "Already registered? Login" else "Need new account? Register",
                    color = CyberCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clickable { isRegister = !isRegister }
                )
            }
        }
    }
}

@Composable
fun ProfileSettingsScreen(
    viewModel: CyberGymViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val userProfile by viewModel.repository.userProfile.collectAsState()
    var alertsEnabled by remember { mutableStateOf(true) }
    var autoMitigate by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "OPERATOR CONFIGURATION",
                    color = CyberCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Profile & Settings",
                    color = TextPrimary,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black
                )
            }
            LivePulseDot(label = "ONLINE")
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Profile Summary Card
        CyberCard(borderColor = CyberCyan.copy(alpha = 0.5f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(CyberCyan.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(28.dp))
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(text = userProfile.username, color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text(text = "Role: ${userProfile.role}", color = CyberAmber, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Text(text = "${userProfile.rank} | Level ${userProfile.level}", color = TextMuted, fontSize = 11.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Switch Roles Quick Selector
        SectionHeader(
            title = "Switch Operational Role",
            subtitle = "Updates interface permissions and training perspective"
        )
        val roles = listOf("Blue Team Defender", "Red Team Analyst", "SOC Admin", "User")
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            roles.forEach { r ->
                val isCurrent = userProfile.role == r
                CyberCard(
                    modifier = Modifier.clickable {
                        viewModel.repository.updateUserRole(r)
                        viewModel.pushNotification("Switched active operational role to $r.")
                    },
                    borderColor = if (isCurrent) CyberCyan else CyberBorder,
                    backgroundColor = if (isCurrent) CyberCyan.copy(alpha = 0.15f) else CyberSurfaceCard
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = r, color = if (isCurrent) CyberCyan else TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        if (isCurrent) {
                            Text(text = "ACTIVE", color = CyberCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Preferences & Toggle Controls
        SectionHeader(
            title = "SOC Automation & Alert Preferences"
        )

        CyberCard {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "Real-Time Push Alerts", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text(text = "Trigger vibration on Critical attack forecasts", color = TextMuted, fontSize = 11.sp)
                }
                Switch(
                    checked = alertsEnabled,
                    onCheckedChange = { alertsEnabled = it },
                    colors = SwitchDefaults.colors(checkedThumbColor = CyberCyan, checkedTrackColor = CyberCyan.copy(alpha = 0.3f))
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "Autonomous Defense Mode (SOAR)", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text(text = "Auto-execute rate limiting on >80% DDoS forecast", color = TextMuted, fontSize = 11.sp)
                }
                Switch(
                    checked = autoMitigate,
                    onCheckedChange = { autoMitigate = it },
                    colors = SwitchDefaults.colors(checkedThumbColor = CyberCyan, checkedTrackColor = CyberCyan.copy(alpha = 0.3f))
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        CyberSecondaryButton(
            text = "Logout of SOC Session",
            icon = Icons.Default.Lock,
            onClick = { viewModel.logout() },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(24.dp))
    }
}
