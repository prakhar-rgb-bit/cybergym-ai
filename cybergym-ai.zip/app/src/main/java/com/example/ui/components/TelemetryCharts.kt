package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ProbabilityBreakdown
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberCrimson
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberEmerald
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.TimeSeriesPoint
import kotlin.math.max

@Composable
fun TelemetryLineChart(
    points: List<TimeSeriesPoint>,
    valueSelector: (TimeSeriesPoint) -> Double,
    lineColor: Color = CyberCyan,
    unit: String = "PPS",
    modifier: Modifier = Modifier
) {
    val data = if (points.isEmpty()) listOf(0.0, 0.0) else points.map { valueSelector(it) }
    val maxVal = max(100.0, data.maxOrNull() ?: 100.0)

    Column(modifier = modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF060A12))
                .border(1.dp, CyberBorder.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                .padding(8.dp)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height

                // Draw Grid Lines
                val gridLines = 4
                for (i in 0..gridLines) {
                    val y = h * (i.toFloat() / gridLines)
                    drawLine(
                        color = Color(0xFF1E293B),
                        start = Offset(0f, y),
                        end = Offset(w, y),
                        strokeWidth = 1f
                    )
                }

                if (data.size > 1) {
                    val stepX = w / (data.size - 1)
                    val path = Path()
                    val fillPath = Path()

                    data.forEachIndexed { index, value ->
                        val x = index * stepX
                        val normalizedY = (1.0 - (value / maxVal)).toFloat() * (h * 0.85f) + (h * 0.05f)

                        if (index == 0) {
                            path.moveTo(x, normalizedY)
                            fillPath.moveTo(x, h)
                            fillPath.lineTo(x, normalizedY)
                        } else {
                            val prevX = (index - 1) * stepX
                            val prevVal = data[index - 1]
                            val prevNormalizedY = (1.0 - (prevVal / maxVal)).toFloat() * (h * 0.85f) + (h * 0.05f)

                            val cx = (prevX + x) / 2f
                            path.cubicTo(cx, prevNormalizedY, cx, normalizedY, x, normalizedY)
                            fillPath.cubicTo(cx, prevNormalizedY, cx, normalizedY, x, normalizedY)
                        }
                    }

                    fillPath.lineTo((data.size - 1) * stepX, h)
                    fillPath.close()

                    // Gradient fill under line
                    drawPath(
                        path = fillPath,
                        brush = Brush.verticalGradient(
                            colors = listOf(lineColor.copy(alpha = 0.25f), Color.Transparent),
                            startY = 0f,
                            endY = h
                        )
                    )

                    // Stroke line
                    drawPath(
                        path = path,
                        color = lineColor,
                        style = Stroke(width = 4f, cap = StrokeCap.Round)
                    )

                    // Draw dot at latest point
                    val lastX = (data.size - 1) * stepX
                    val lastY = (1.0 - (data.last() / maxVal)).toFloat() * (h * 0.85f) + (h * 0.05f)
                    drawCircle(Color.White, radius = 5f, center = Offset(lastX, lastY))
                    drawCircle(lineColor, radius = 3f, center = Offset(lastX, lastY))
                }
            }

            // Peak indicator badge
            Text(
                text = "PEAK: ${maxVal.toInt()} $unit",
                color = lineColor,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.align(Alignment.TopEnd)
            )
        }
    }
}

@Composable
fun AttackProbabilityBarChart(
    breakdowns: List<ProbabilityBreakdown>,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        breakdowns.forEach { item ->
            val animatedProb by animateFloatAsState(
                targetValue = (item.probability / 100.0).toFloat(),
                animationSpec = tween(500),
                label = "prob_bar"
            )

            val barColor = when {
                item.probability >= 70.0 -> CyberCrimson
                item.probability >= 40.0 -> CyberAmber
                item.probability >= 20.0 -> CyberCyan
                else -> CyberEmerald
            }

            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(barColor)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = item.attackType.displayName,
                            color = TextPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "${item.probability.toInt()}%",
                            color = barColor,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.Monospace
                        )
                        if (item.trend == "Rising") {
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "▲",
                                color = CyberCrimson,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Bar Track
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(7.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(CyberSurfaceVariant)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(animatedProb)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(4.dp))
                            .background(
                                Brush.horizontalGradient(
                                    listOf(barColor.copy(alpha = 0.7f), barColor)
                                )
                            )
                    )
                }
            }
        }
    }
}
