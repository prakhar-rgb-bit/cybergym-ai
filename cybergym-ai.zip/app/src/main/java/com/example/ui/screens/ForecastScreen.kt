package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CrisisAlert
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.RiskLevel
import com.example.ui.components.ActiveAlertBanner
import com.example.ui.components.AiPipelineFlowDiagram
import com.example.ui.components.AttackProbabilityBarChart
import com.example.ui.components.ContributingFeaturesSection
import com.example.ui.components.CyberCard
import com.example.ui.components.CyberPrimaryButton
import com.example.ui.components.LivePulseDot
import com.example.ui.components.SectionHeader
import com.example.ui.components.TelemetryLineChart
import com.example.ui.components.ThreatBadge
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberCrimson
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberEmerald
import com.example.ui.theme.CyberPurple
import com.example.ui.theme.CyberSurfaceCard
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.CyberGymViewModel
import com.example.viewmodel.ScreenRoute

@Composable
fun ForecastScreen(
    viewModel: CyberGymViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    val forecast by viewModel.attackForecast.collectAsState()
    val breakdowns by viewModel.probabilitiesBreakdown.collectAsState()
    val timeSeries by viewModel.timeSeriesHistory.collectAsState()
    val anomaly by viewModel.anomalyResult.collectAsState()
    val pipelineResult by viewModel.aiPipelineResult.collectAsState()
    val activeAlert by viewModel.activeSecurityAlert.collectAsState()

    var showXaiModal by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Screen Title Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "AI ATTACK FORECAST ENGINE",
                    color = CyberCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Predictive Intelligence",
                    color = TextPrimary,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black
                )
            }
            LivePulseDot(label = "INFERENCE ACTIVE")
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Active Alert Banner if triggered
        activeAlert?.let { alert ->
            ActiveAlertBanner(
                alert = alert,
                onAcknowledge = { viewModel.acknowledgeAlert(alert.id) },
                onInvestigate = { /* already on forecast */ }
            )
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Hero Attack Forecast Card
        CyberCard(
            borderColor = if (forecast.riskLevel == RiskLevel.CRITICAL) CyberCrimson else CyberCyan,
            backgroundColor = CyberSurfaceCard,
            testTag = "forecast_hero_card"
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Psychology,
                        contentDescription = null,
                        tint = CyberCyan,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "PRIMARY FORECASTED THREAT",
                        color = TextMuted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace
                    )
                }
                ThreatBadge(risk = forecast.riskLevel)
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = forecast.attackType.displayName,
                color = TextPrimary,
                fontSize = 28.sp,
                fontWeight = FontWeight.Black
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ForecastMetricItem("Probability", "${forecast.probability.toInt()}%", if (forecast.probability > 70) CyberCrimson else CyberCyan, Modifier.weight(1f))
                ForecastMetricItem("Confidence", forecast.confidence.split(" ").firstOrNull() ?: "High", CyberCyan, Modifier.weight(1f))
                ForecastMetricItem("Forecast Window", forecast.forecastWindow, CyberAmber, Modifier.weight(1.3f))
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Natural Language Summary Box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(CyberSurfaceVariant.copy(alpha = 0.6f))
                    .border(1.dp, CyberBorder, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = CyberPurple,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "AI FORECAST SUMMARY",
                            color = CyberPurple,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = forecast.explainableSummary,
                        color = TextPrimary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            CyberPrimaryButton(
                text = "Why did AI predict this? (XAI Breakdown)",
                icon = Icons.Default.Info,
                onClick = { showXaiModal = !showXaiModal },
                modifier = Modifier.fillMaxWidth(),
                testTag = "why_prediction_button"
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 8-Stage Deterministic AI Network Pipeline Diagram
        AiPipelineFlowDiagram(pipelineResult = pipelineResult)

        // XAI Explainable Reasons Section & Contributing Features
        if (showXaiModal) {
            Spacer(modifier = Modifier.height(14.dp))

            if (pipelineResult.contributingFeatures.isNotEmpty()) {
                ContributingFeaturesSection(contributingFeatures = pipelineResult.contributingFeatures)
                Spacer(modifier = Modifier.height(14.dp))
            }

            CyberCard(
                borderColor = CyberPurple,
                backgroundColor = Color(0xFF101524)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Psychology,
                        contentDescription = null,
                        tint = CyberPurple,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "EXPLAINABLE AI (XAI) FEATURE IMPORTANCE",
                        color = TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                forecast.contributingFeatures.forEachIndexed { index, reason ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Box(
                            modifier = Modifier
                                .size(20.dp)
                                .clip(CircleShape)
                                .background(CyberPurple.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${index + 1}",
                                color = CyberPurple,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = reason,
                            color = TextSecondary,
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Attack Probabilities Distribution (All 8 Classes)
        SectionHeader(
            title = "Attack Class Probabilities",
            subtitle = "Multi-class ensemble distribution"
        )
        CyberCard {
            AttackProbabilityBarChart(breakdowns = breakdowns)
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Time-Series Probability Progression Chart
        SectionHeader(
            title = "Attack Probability Trendline",
            subtitle = "Temporal Markov transition risk over time"
        )
        TelemetryLineChart(
            points = timeSeries,
            valueSelector = { it.attackProbability },
            lineColor = if (forecast.probability > 70) CyberCrimson else CyberCyan,
            unit = "%"
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Recommended Defensive Playbook
        SectionHeader(
            title = "Recommended Countermeasures",
            subtitle = "Automated tactical response actions"
        )
        CyberCard(borderColor = CyberEmerald.copy(alpha = 0.5f)) {
            forecast.recommendedActions.forEach { action ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = CyberEmerald,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = action,
                        color = TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            CyberPrimaryButton(
                text = "Deploy Countermeasures in Blue Team →",
                icon = Icons.Default.Shield,
                onClick = { viewModel.navigateTo(ScreenRoute.BLUE_TEAM) },
                modifier = Modifier.fillMaxWidth()
            )
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun ForecastMetricItem(
    label: String,
    value: String,
    valueColor: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(CyberSurfaceVariant)
            .padding(8.dp)
    ) {
        Column {
            Text(text = label.uppercase(), color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = value, color = valueColor, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, fontFamily = FontFamily.Monospace, maxLines = 1)
        }
    }
}
