package com.example.ui.screens

import android.app.Activity
import android.net.VpnService
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CrisisAlert
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CaptureState
import com.example.model.MonitoringMode
import com.example.model.RiskLevel
import com.example.ui.components.CyberCard
import com.example.ui.components.CyberPrimaryButton
import com.example.ui.components.CyberSecondaryButton
import com.example.ui.components.LivePulseDot
import com.example.ui.components.MetricPill
import com.example.ui.components.SectionHeader
import com.example.ui.components.SophisticatedGradientCard
import com.example.ui.components.StatScoreCard
import com.example.ui.components.TelemetryLineChart
import com.example.ui.components.ThreatBadge
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberBorderBright
import com.example.ui.theme.CyberCrimson
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberEmerald
import com.example.ui.theme.CyberPurple
import com.example.ui.theme.CyberSurfaceCard
import com.example.ui.theme.CyberSurfaceDark
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.CyberGymViewModel
import com.example.viewmodel.ScreenRoute

@Composable
fun DashboardScreen(
    viewModel: CyberGymViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    val captureState by viewModel.captureState.collectAsState()
    val monitoringMode by viewModel.monitoringMode.collectAsState()
    val totalPackets by viewModel.totalPackets.collectAsState()

    val pps by viewModel.packetRate.collectAsState()
    val byteRate by viewModel.byteRate.collectAsState()
    val activeConns by viewModel.activeConnections.collectAsState()
    val failedConns by viewModel.failedConnections.collectAsState()
    val anomaly by viewModel.anomalyResult.collectAsState()
    val forecast by viewModel.attackForecast.collectAsState()
    val timeSeries by viewModel.timeSeriesHistory.collectAsState()
    val incidents by viewModel.repository.incidents.collectAsState()

    val vpnLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            viewModel.startVpnMonitoring(context)
        } else {
            viewModel.onVpnPermissionDenied()
        }
    }

    fun handleStartVpn() {
        val prepareIntent = VpnService.prepare(context)
        if (prepareIntent != null) {
            viewModel.onVpnPermissionRequired()
            vpnLauncher.launch(prepareIntent)
        } else {
            viewModel.startVpnMonitoring(context)
        }
    }

    val networkHealth = (100.0 - (anomaly.anomalyScore * 0.4)).toInt().coerceIn(40, 99)
    val securityScore = (95.0 - (if (forecast.riskLevel == RiskLevel.CRITICAL) 25.0 else if (forecast.riskLevel == RiskLevel.HIGH) 15.0 else 4.0)).toInt()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        // Live Network Monitor Status Banner & Controls
        CyberCard(
            borderColor = when (captureState) {
                CaptureState.RUNNING -> CyberCyan
                CaptureState.PAUSED -> CyberAmber
                else -> CyberBorder
            },
            backgroundColor = CyberSurfaceDark
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.VpnKey,
                        contentDescription = "VPN Monitor",
                        tint = if (captureState == CaptureState.RUNNING) CyberCyan else TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                    Column {
                        Text(
                            text = "NETWORK TELEMETRY STATUS",
                            color = TextMuted,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = when (captureState) {
                                CaptureState.RUNNING -> if (monitoringMode == MonitoringMode.LIVE_VPN) "Live Android VPN Active" else "Simulation Active"
                                CaptureState.PAUSED -> "Capture Paused"
                                CaptureState.PREPARING -> "Awaiting Permission"
                                CaptureState.STOPPED -> "Monitor Idle"
                            },
                            color = TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    when (captureState) {
                        CaptureState.RUNNING -> {
                            Button(
                                onClick = { viewModel.pauseMonitoring(context) },
                                colors = ButtonDefaults.buttonColors(containerColor = CyberAmber),
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier.height(30.dp)
                            ) {
                                Text("Pause", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                            Button(
                                onClick = { viewModel.stopMonitoring(context) },
                                colors = ButtonDefaults.buttonColors(containerColor = CyberCrimson),
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier.height(30.dp)
                            ) {
                                Text("Stop", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        CaptureState.PAUSED -> {
                            Button(
                                onClick = { viewModel.resumeMonitoring(context) },
                                colors = ButtonDefaults.buttonColors(containerColor = CyberEmerald),
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier.height(30.dp)
                            ) {
                                Text("Resume", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                            Button(
                                onClick = { viewModel.stopMonitoring(context) },
                                colors = ButtonDefaults.buttonColors(containerColor = CyberCrimson),
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier.height(30.dp)
                            ) {
                                Text("Stop", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        else -> {
                            Button(
                                onClick = { handleStartVpn() },
                                colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier.height(30.dp)
                            ) {
                                Text("Start VPN", color = Color(0xFF031B20), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    IconButton(
                        onClick = { viewModel.navigateTo(ScreenRoute.NETWORK_MONITOR) },
                        modifier = Modifier.size(30.dp)
                    ) {
                        Icon(Icons.Default.Speed, contentDescription = "Inspect Traffic", tint = CyberCyan, modifier = Modifier.size(18.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${pps.toInt()} PPS • ${byteRate.toInt()} KB/s • $totalPackets total packets",
                    color = TextSecondary,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Tap ⇱ to open Wireshark inspect",
                    color = CyberCyan,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.clickable { viewModel.navigateTo(ScreenRoute.NETWORK_MONITOR) }
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))
        // Top 2-Column Stat Cards (Sophisticated Dark Grid)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            StatScoreCard(
                title = "Security Score",
                score = "$securityScore",
                suffix = "/100",
                accentColor = TextPrimary,
                modifier = Modifier.weight(1f)
            )
            StatScoreCard(
                title = "Network Health",
                score = "$networkHealth",
                suffix = "%",
                accentColor = CyberCyan,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Hero Attack Forecast Card (Sophisticated Dark Crimson Gradient)
        SophisticatedGradientCard(
            testTag = "hero_forecast_card",
            modifier = Modifier.fillMaxWidth()
        ) {
            // Header Row: High Priority Tag & Subtitle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(CyberCrimson)
                            .padding(horizontal = 7.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = if (forecast.riskLevel == RiskLevel.CRITICAL) "HIGH PRIORITY" else "ACTIVE THREAT",
                            color = Color.White,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.5.sp
                        )
                    }
                    Text(
                        text = "Attack Forecast",
                        color = Color(0xFFFECACA),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                LivePulseDot(color = CyberCrimson, label = "AI ACTIVE")
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "${forecast.attackType.displayName} Prediction",
                color = TextPrimary,
                fontSize = 22.sp,
                fontWeight = FontWeight.Black
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Probability Value
            Row(
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "${forecast.probability.toInt()}%",
                    color = CyberCrimson,
                    fontSize = 38.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "PROBABILITY",
                    color = Color(0xFFFCA5A5).copy(alpha = 0.8f),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(bottom = 6.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Forecast Window & Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Forecast Window",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = forecast.forecastWindow,
                    color = TextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Forecast progress bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(CyberBorder)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth((forecast.probability / 100.0).toFloat().coerceIn(0.1f, 1f))
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(CyberCrimson)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Explainable AI Quote
            Text(
                text = "“${forecast.explainableSummary.take(130)}”",
                color = TextSecondary,
                fontSize = 11.sp,
                lineHeight = 16.sp
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Action Buttons Row (Deploy Defense + Tool Button)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CyberPrimaryButton(
                text = "DEPLOY DEFENSE",
                onClick = { viewModel.navigateTo(ScreenRoute.BLUE_TEAM) },
                icon = Icons.Default.Shield,
                modifier = Modifier.weight(1f),
                testTag = "deploy_defense_button"
            )

            Box(
                modifier = Modifier
                    .size(50.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(CyberBorder)
                    .border(1.dp, CyberBorderBright, RoundedCornerShape(16.dp))
                    .clickable { viewModel.navigateTo(ScreenRoute.FORECAST) }
                    .testTag("forecast_quick_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Psychology,
                    contentDescription = "Forecast XAI Details",
                    tint = CyberCyan,
                    modifier = Modifier.size(22.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Live Telemetry Card
        CyberCard(
            shape = RoundedCornerShape(22.dp),
            backgroundColor = CyberSurfaceDark.copy(alpha = 0.5f)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "LIVE TELEMETRY",
                    color = TextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "${pps.toInt()} req/s",
                    color = CyberCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            TelemetryLineChart(
                points = timeSeries,
                valueSelector = { it.pps },
                lineColor = if (pps > 1500) CyberCrimson else CyberCyan,
                unit = "PPS"
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Traffic Statistics Grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricPill("Packets/Sec", "${pps.toInt()} PPS", accentColor = CyberCyan, modifier = Modifier.weight(1f))
            MetricPill("Byte Rate", "${byteRate.toInt()} KB/s", accentColor = CyberPurple, modifier = Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricPill("Active Conns", "$activeConns", accentColor = CyberEmerald, modifier = Modifier.weight(1f))
            MetricPill("Failed Conns", "$failedConns /sec", accentColor = if (failedConns > 10) CyberCrimson else TextPrimary, modifier = Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Quick Access Launchpad
        SectionHeader(title = "CyberGym Operations", subtitle = "Interactive modules and incident center")
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            CyberCard(
                modifier = Modifier
                    .weight(1f)
                    .clickable { viewModel.navigateTo(ScreenRoute.CYBER_GYM) },
                backgroundColor = CyberSurfaceDark.copy(alpha = 0.6f),
                shape = RoundedCornerShape(18.dp)
            ) {
                Icon(imageVector = Icons.Default.Hub, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.height(6.dp))
                Text(text = "Cyber Gym", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(text = "Virtual Range", color = TextSecondary, fontSize = 11.sp)
            }

            CyberCard(
                modifier = Modifier
                    .weight(1f)
                    .clickable { viewModel.navigateTo(ScreenRoute.LIVE_DEMO) },
                backgroundColor = CyberSurfaceDark.copy(alpha = 0.6f),
                shape = RoundedCornerShape(18.dp)
            ) {
                Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, tint = CyberEmerald, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.height(6.dp))
                Text(text = "Live Demo", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(text = "10-Phase Walk", color = TextSecondary, fontSize = 11.sp)
            }

            CyberCard(
                modifier = Modifier
                    .weight(1f)
                    .clickable { viewModel.navigateTo(ScreenRoute.INCIDENT_CENTER) },
                backgroundColor = CyberSurfaceDark.copy(alpha = 0.6f),
                shape = RoundedCornerShape(18.dp)
            ) {
                Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = CyberAmber, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.height(6.dp))
                Text(text = "Incidents", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(text = "${incidents.size} Active", color = TextSecondary, fontSize = 11.sp)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))
    }
}

