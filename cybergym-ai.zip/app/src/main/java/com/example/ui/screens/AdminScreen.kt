package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Dataset
import androidx.compose.material.icons.filled.ModelTraining
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CyberCard
import com.example.ui.components.CyberPrimaryButton
import com.example.ui.components.LivePulseDot
import com.example.ui.components.MetricPill
import com.example.ui.components.SectionHeader
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberCrimson
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberEmerald
import com.example.ui.theme.CyberPurple
import com.example.ui.theme.CyberSurfaceCard
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.CyberGymViewModel

@Composable
fun AdminScreen(
    viewModel: CyberGymViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val modelMetrics by viewModel.repository.modelMetrics.collectAsState()
    val datasets by viewModel.repository.datasets.collectAsState()
    val notifications by viewModel.notifications.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "SOC SYSTEM ADMINISTRATION",
                    color = CyberCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "ML Models & Data Management",
                    color = TextPrimary,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black
                )
            }
            LivePulseDot(label = "ADMIN ACCESS")
        }

        Spacer(modifier = Modifier.height(16.dp))

        // ML Model Governance Card
        CyberCard(
            borderColor = CyberCyan.copy(alpha = 0.5f),
            backgroundColor = CyberSurfaceCard
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.ModelTraining, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "ENSEMBLE MODEL METRICS",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Text(
                    text = modelMetrics.version,
                    color = CyberCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricPill("Train Acc.", "${modelMetrics.trainingAccuracy}%", accentColor = CyberCyan, modifier = Modifier.weight(1f))
                MetricPill("Val Acc.", "${modelMetrics.validationAccuracy}%", accentColor = CyberEmerald, modifier = Modifier.weight(1f))
                MetricPill("F1-Score", "${modelMetrics.f1Score}", accentColor = CyberPurple, modifier = Modifier.weight(1f))
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "Base Architecture: Isolation Forest + LightGBM + Markov Chain", color = TextMuted, fontSize = 10.sp)
                Text(text = "Status: ${modelMetrics.lastTrained}", color = CyberEmerald, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(14.dp))

            CyberPrimaryButton(
                text = "Retrain AI Forecasting Model",
                icon = Icons.Default.Refresh,
                onClick = {
                    viewModel.repository.retrainModel()
                    viewModel.pushNotification("Triggered online retraining for Ensemble Threat Predictor.")
                },
                modifier = Modifier.fillMaxWidth()
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Dataset Management
        SectionHeader(
            title = "Training Datasets (PCAP / Flow CSV)",
            subtitle = "Pre-processed statistical flow features repository"
        )

        CyberCard {
            datasets.forEach { row ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "${row.id} - ${row.attackLabel}", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        Text(text = "Port ${row.dstPort} (${row.protocol}) | ${row.packetCount} pkts | ${row.packetRate.toInt()} PPS", color = TextMuted, fontSize = 10.sp)
                    }
                    Text(text = "${row.flowDuration}ms", color = CyberCyan, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
                Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(CyberBorder.copy(alpha = 0.3f)))
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // System Logs Stream
        SectionHeader(
            title = "SOC System Audit Logs",
            subtitle = "Security kernel event telemetry"
        )

        CyberCard(backgroundColor = Color(0xFF060A12)) {
            notifications.take(8).forEach { log ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Text(text = "> ", color = CyberCyan, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    Text(text = log, color = TextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}
