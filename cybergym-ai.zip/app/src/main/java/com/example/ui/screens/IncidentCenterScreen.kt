package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CrisisAlert
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Incident
import com.example.model.IncidentStatus
import com.example.model.Severity
import com.example.ui.components.CyberCard
import com.example.ui.components.CyberSecondaryButton
import com.example.ui.components.LivePulseDot
import com.example.ui.components.SeverityBadge
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberCrimson
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberEmerald
import com.example.ui.theme.CyberSurfaceCard
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.CyberGymViewModel

@Composable
fun IncidentCenterScreen(
    viewModel: CyberGymViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val incidents by viewModel.repository.incidents.collectAsState()

    var selectedFilter by remember { mutableStateOf("ALL") }
    val filters = listOf("ALL", "CRITICAL", "HIGH", "MEDIUM")

    val filteredIncidents = incidents.filter { inc ->
        when (selectedFilter) {
            "CRITICAL" -> inc.severity == Severity.CRITICAL
            "HIGH" -> inc.severity == Severity.HIGH
            "MEDIUM" -> inc.severity == Severity.MEDIUM
            else -> true
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "SOC INCIDENT CENTER",
                    color = CyberCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Active Incident Queue",
                    color = TextPrimary,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black
                )
            }
            LivePulseDot(label = "${incidents.size} INCIDENTS")
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Severity Filters
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            filters.forEach { f ->
                val isSel = selectedFilter == f
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isSel) CyberCyan else CyberSurfaceVariant)
                        .border(1.dp, if (isSel) CyberCyan else CyberBorder, RoundedCornerShape(6.dp))
                        .clickable { selectedFilter = f }
                        .padding(vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = f,
                        color = if (isSel) Color(0xFF031B20) else TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Incident Cards
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            filteredIncidents.forEach { inc ->
                CyberCard(
                    borderColor = if (inc.severity == Severity.CRITICAL) CyberCrimson.copy(alpha = 0.6f) else CyberBorder,
                    backgroundColor = CyberSurfaceCard
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = inc.id,
                                color = CyberCyan,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            SeverityBadge(severity = inc.severity)
                        }

                        IncidentStatusBadge(status = inc.status)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "${inc.attackType.displayName} Detected",
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "Target: ${inc.targetHost} | Source: ${inc.sourceIp}",
                        color = TextMuted,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(CyberSurfaceVariant)
                            .padding(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Mitigation: ${inc.mitigationAction}", color = TextSecondary, fontSize = 11.sp)
                            Text(text = "AI Prob: ${inc.aiProbability.toInt()}%", color = CyberCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Status Workflow buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        if (inc.status != IncidentStatus.RESOLVED) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(CyberEmerald.copy(alpha = 0.2f))
                                    .clickable { viewModel.repository.updateIncidentStatus(inc.id, IncidentStatus.RESOLVED) }
                                    .padding(vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(text = "Mark Resolved", color = CyberEmerald, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        if (inc.status != IncidentStatus.CONTAINED && inc.status != IncidentStatus.RESOLVED) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(CyberCyan.copy(alpha = 0.2f))
                                    .clickable { viewModel.repository.updateIncidentStatus(inc.id, IncidentStatus.CONTAINED) }
                                    .padding(vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(text = "Mark Contained", color = CyberCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        CyberSecondaryButton(
            text = "Export Incident Logs (CSV / JSON)",
            icon = Icons.Default.Download,
            onClick = { viewModel.pushNotification("Exported incident history to local storage.") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun IncidentStatusBadge(status: IncidentStatus) {
    val (bgColor, textColor) = when (status) {
        IncidentStatus.DETECTED -> Pair(CyberCrimson.copy(alpha = 0.2f), CyberCrimson)
        IncidentStatus.INVESTIGATING -> Pair(CyberAmber.copy(alpha = 0.2f), CyberAmber)
        IncidentStatus.CONTAINED -> Pair(CyberCyan.copy(alpha = 0.2f), CyberCyan)
        IncidentStatus.RESOLVED -> Pair(CyberEmerald.copy(alpha = 0.2f), CyberEmerald)
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(bgColor)
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = status.label.uppercase(),
            color = textColor,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}
