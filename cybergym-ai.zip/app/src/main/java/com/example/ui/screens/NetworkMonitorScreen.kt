package com.example.ui.screens

import android.app.Activity
import android.net.VpnService
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CrisisAlert
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.ViewAgenda
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.CaptureState
import com.example.model.CapturedPacket
import com.example.model.MonitoringMode
import com.example.model.NetworkEndpoint
import com.example.model.RiskLevel
import com.example.ui.components.ActiveAlertBanner
import com.example.ui.components.AiPipelineFlowDiagram
import com.example.ui.components.ContributingFeaturesSection
import com.example.ui.components.CyberCard
import com.example.ui.components.CyberPrimaryButton
import com.example.ui.components.CyberSecondaryButton
import com.example.ui.components.LivePulseDot
import com.example.ui.components.LiveTrafficTable
import com.example.ui.components.MetricPill
import com.example.ui.components.SectionHeader
import com.example.ui.components.TelemetryLineChart
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberBgDark
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberBorderBright
import com.example.ui.theme.CyberCrimson
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberEmerald
import com.example.ui.theme.CyberPurple
import com.example.ui.theme.CyberSurfaceCard
import com.example.ui.theme.CyberSurfaceDark
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.CyberGymViewModel
import com.example.viewmodel.ScreenRoute

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun NetworkMonitorScreen(
    viewModel: CyberGymViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    // VPN and Capture state from ViewModel
    val monitoringMode by viewModel.monitoringMode.collectAsState()
    val captureState by viewModel.captureState.collectAsState()
    val filterCriteria by viewModel.filterCriteria.collectAsState()
    val filteredPackets by viewModel.filteredPackets.collectAsState()
    val selectedPacket by viewModel.selectedPacket.collectAsState()
    val endpoints by viewModel.repository.networkEndpoints.collectAsState()

    val pps by viewModel.packetRate.collectAsState()
    val byteRate by viewModel.byteRate.collectAsState()
    val feature by viewModel.trafficFeature.collectAsState()
    val timeSeries by viewModel.timeSeriesHistory.collectAsState()
    val totalPackets by viewModel.totalPackets.collectAsState()
    val securityScore by viewModel.securityRiskScore.collectAsState()
    val pipelineResult by viewModel.aiPipelineResult.collectAsState()
    val activeAlert by viewModel.activeSecurityAlert.collectAsState()

    var showPermissionDialog by remember { mutableStateOf(false) }
    var isTableMode by remember { mutableStateOf(true) }

    // Activity Result Launcher for Android VpnService permission flow
    val vpnLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            viewModel.startVpnMonitoring(context)
        } else {
            viewModel.onVpnPermissionDenied()
        }
    }

    // Handles VPN preparation check
    fun launchVpnMonitoring() {
        val prepareIntent = VpnService.prepare(context)
        if (prepareIntent != null) {
            showPermissionDialog = true
        } else {
            // Already granted by user
            viewModel.startVpnMonitoring(context)
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Top Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "LIVE PACKET FLOW ANALYZER",
                        color = CyberCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Live Ingress & Flow Telemetry",
                        color = TextPrimary,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                // Live status pill
                when (captureState) {
                    CaptureState.RUNNING -> LivePulseDot(label = if (monitoringMode == MonitoringMode.LIVE_VPN) "VPN ACTIVE" else "SIM ACTIVE")
                    CaptureState.PAUSED -> Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(CyberAmber.copy(alpha = 0.2f))
                            .border(1.dp, CyberAmber, RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("PAUSED", color = CyberAmber, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                    CaptureState.PREPARING -> Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(CyberCyan.copy(alpha = 0.2f))
                            .border(1.dp, CyberCyan, RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("PREPARING", color = CyberCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                    CaptureState.STOPPED -> Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(CyberSurfaceVariant)
                            .border(1.dp, CyberBorder, RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("STOPPED", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        // 1. Interactive VPN & Capture Controller Card
        item {
            CyberCard(
                borderColor = when (captureState) {
                    CaptureState.RUNNING -> CyberCyan
                    CaptureState.PAUSED -> CyberAmber
                    else -> CyberBorderBright
                }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.VpnKey,
                            contentDescription = "VPN Status",
                            tint = if (captureState == CaptureState.RUNNING) CyberCyan else TextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                        Column {
                            Text(
                                text = "ON-DEVICE PACKET INSPECTOR",
                                color = TextMuted,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = when (captureState) {
                                    CaptureState.RUNNING -> if (monitoringMode == MonitoringMode.LIVE_VPN) "Live Android VpnService Running" else "CyberGym Traffic Simulator Running"
                                    CaptureState.PAUSED -> "Traffic Inspection Paused"
                                    CaptureState.PREPARING -> "Awaiting Android VPN Permission"
                                    CaptureState.STOPPED -> "Inspector Idle (Ready to Capture)"
                                },
                                color = TextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(
                                when (captureState) {
                                    CaptureState.RUNNING -> CyberEmerald.copy(alpha = 0.2f)
                                    CaptureState.PAUSED -> CyberAmber.copy(alpha = 0.2f)
                                    else -> CyberSurfaceVariant
                                }
                            )
                            .padding(horizontal = 6.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = monitoringMode.label.uppercase(),
                            color = when (captureState) {
                                CaptureState.RUNNING -> CyberEmerald
                                CaptureState.PAUSED -> CyberAmber
                                else -> TextMuted
                            },
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Action Controls Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    when (captureState) {
                        CaptureState.STOPPED -> {
                            // Primary Start Live VPN button
                            Button(
                                onClick = { launchVpnMonitoring() },
                                colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(42.dp)
                                    .testTag("start_vpn_button")
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color(0xFF031B20), modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Start Live VPN", color = Color(0xFF031B20), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }

                            // Simulation mode button
                            Button(
                                onClick = { viewModel.startSimulationMonitoring() },
                                colors = ButtonDefaults.buttonColors(containerColor = CyberSurfaceVariant),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(42.dp)
                                    .border(1.dp, CyberBorder, RoundedCornerShape(6.dp))
                                    .testTag("start_simulation_button")
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Simulate Traffic", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        CaptureState.RUNNING -> {
                            // Pause button
                            Button(
                                onClick = { viewModel.pauseMonitoring(context) },
                                colors = ButtonDefaults.buttonColors(containerColor = CyberAmber),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(42.dp)
                                    .testTag("pause_vpn_button")
                            ) {
                                Icon(Icons.Default.Pause, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Pause", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }

                            // Stop button
                            Button(
                                onClick = { viewModel.stopMonitoring(context) },
                                colors = ButtonDefaults.buttonColors(containerColor = CyberCrimson),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(42.dp)
                                    .testTag("stop_vpn_button")
                            ) {
                                Icon(Icons.Default.Stop, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Stop", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        CaptureState.PAUSED -> {
                            // Resume button
                            Button(
                                onClick = { viewModel.resumeMonitoring(context) },
                                colors = ButtonDefaults.buttonColors(containerColor = CyberEmerald),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(42.dp)
                                    .testTag("resume_vpn_button")
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Resume", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }

                            // Stop button
                            Button(
                                onClick = { viewModel.stopMonitoring(context) },
                                colors = ButtonDefaults.buttonColors(containerColor = CyberCrimson),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(42.dp)
                                    .testTag("stop_vpn_button")
                            ) {
                                Icon(Icons.Default.Stop, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Stop", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        CaptureState.PREPARING -> {
                            Button(
                                onClick = { launchVpnMonitoring() },
                                colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(42.dp)
                            ) {
                                Text("Grant Permission in Dialog", color = Color(0xFF031B20), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Privacy Disclosure Callout
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(CyberSurfaceDark)
                        .border(1.dp, CyberBorder.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                        .padding(8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(16.dp))
                        Text(
                            text = "Zero-Decryption Policy: Inspects permitted L3/L4 headers (IP, Port, Protocol, TCP Flags, DNS queries). Plaintext payload is never decrypted or exfiltrated.",
                            color = TextSecondary,
                            fontSize = 10.sp,
                            lineHeight = 14.sp
                        )
                    }
                }
            }
        }

        // 2. Real-Time Telemetry Metrics Grid
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricPill(
                    label = "INGRESS RATE",
                    value = "${pps.toInt()} PPS",
                    accentColor = if (pps > 1500) CyberCrimson else CyberCyan,
                    modifier = Modifier.weight(1f)
                )
                MetricPill(
                    label = "BANDWIDTH",
                    value = "${byteRate.toInt()} KB/s",
                    accentColor = CyberPurple,
                    modifier = Modifier.weight(1f)
                )
                MetricPill(
                    label = "TOTAL PACKETS",
                    value = "$totalPackets",
                    accentColor = CyberEmerald,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // 3. Real-Time Packet Ingress (PPS) Chart
        item {
            SectionHeader(
                title = "Live Packet Velocity (PPS)",
                subtitle = "Sliding ring buffer fed into AI Anomaly Engine"
            )
            TelemetryLineChart(
                points = timeSeries,
                valueSelector = { it.pps },
                lineColor = if (pps > 1500) CyberCrimson else CyberCyan,
                unit = "PPS"
            )
        }

        // 3a. Active SOC Incident Alert (if dispatched by AI Engine)
        activeAlert?.let { alert ->
            item {
                ActiveAlertBanner(
                    alert = alert,
                    onAcknowledge = { viewModel.acknowledgeAlert(alert.id) },
                    onInvestigate = { viewModel.navigateTo(ScreenRoute.FORECAST) }
                )
            }
        }

        // 3b. AI Network Monitoring Pipeline Flow (Observed Traffic -> Feature Extraction -> Baseline -> Anomaly -> Classify -> Probability -> Risk -> Alert)
        item {
            AiPipelineFlowDiagram(pipelineResult = pipelineResult)
        }

        // 3c. Contributing Features Behind Predictions
        if (pipelineResult.contributingFeatures.isNotEmpty()) {
            item {
                ContributingFeaturesSection(contributingFeatures = pipelineResult.contributingFeatures)
            }
        }

        // 4. Live Traffic Table Header, Search, Protocol Filters, & Capture Controls
        item {
            SectionHeader(
                title = "Extracted Packet & Flow Telemetry",
                subtitle = "${filteredPackets.size} matching packets | Multi-column live inspection"
            )

            CyberCard(backgroundColor = CyberSurfaceCard) {
                // Search Input Field
                OutlinedTextField(
                    value = filterCriteria.query,
                    onValueChange = { viewModel.setFilterQuery(it) },
                    placeholder = { Text("Search by IP, Port, Protocol, or Query...", fontSize = 11.sp, color = TextMuted) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = CyberCyan, modifier = Modifier.size(16.dp)) },
                    trailingIcon = {
                        if (filterCriteria.query.isNotEmpty()) {
                            IconButton(onClick = { viewModel.setFilterQuery("") }) {
                                Icon(Icons.Default.Close, contentDescription = "Clear", tint = TextMuted, modifier = Modifier.size(16.dp))
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("packet_search_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyberCyan,
                        unfocusedBorderColor = CyberBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        cursorColor = CyberCyan
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Protocol & Threat Filter Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "PROTOCOL & THREAT FILTER",
                        color = TextMuted,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "${filteredPackets.size} / ${totalPackets} flows",
                        color = CyberCyan,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))

                // All requested protocol filters: TCP, UDP, DNS, HTTP, HTTPS, ICMP, Suspicious, High Risk (+ ALL)
                val protocolFilters = listOf("ALL", "TCP", "UDP", "DNS", "HTTP", "HTTPS", "ICMP", "Suspicious", "High Risk")
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    protocolFilters.forEach { proto ->
                        val isSelected = filterCriteria.protocol.equals(proto, ignoreCase = true)
                        val filterColor = when (proto.uppercase()) {
                            "TCP" -> CyberCyan
                            "UDP" -> Color(0xFF38BDF8)
                            "DNS" -> CyberAmber
                            "HTTP" -> CyberPurple
                            "HTTPS" -> CyberEmerald
                            "ICMP" -> Color(0xFFFB7185)
                            "SUSPICIOUS" -> CyberAmber
                            "HIGH RISK" -> CyberCrimson
                            else -> CyberCyan
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isSelected) filterColor else CyberSurfaceVariant)
                                .border(1.dp, if (isSelected) filterColor else CyberBorder, RoundedCornerShape(4.dp))
                                .clickable { viewModel.setProtocolFilter(proto) }
                                .padding(horizontal = 8.dp, vertical = 5.dp)
                                .testTag("filter_chip_$proto")
                        ) {
                            Text(
                                text = proto,
                                color = if (isSelected) Color(0xFF031B20) else TextSecondary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Sort Controls Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Sort:", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        val sortOptions = listOf(
                            "TIME_DESC" to "Time ↓",
                            "TIME_ASC" to "Time ↑",
                            "RISK" to "Risk",
                            "ANOMALY" to "Anomaly",
                            "LENGTH" to "Length"
                        )
                        sortOptions.forEach { (key, label) ->
                            val isSelected = filterCriteria.sortBy == key
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(if (isSelected) CyberPurple.copy(alpha = 0.3f) else Color.Transparent)
                                    .border(1.dp, if (isSelected) CyberPurple else CyberBorder, RoundedCornerShape(3.dp))
                                    .clickable { viewModel.setSortBy(key) }
                                    .padding(horizontal = 6.dp, vertical = 3.dp)
                                    .testTag("sort_chip_$key")
                            ) {
                                Text(
                                    text = label,
                                    color = if (isSelected) CyberPurple else TextMuted,
                                    fontSize = 9.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }

                    // View Mode Switcher: Matrix Table vs Cards
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        IconButton(
                            onClick = { isTableMode = true },
                            modifier = Modifier.size(28.dp).testTag("switch_table_mode")
                        ) {
                            Icon(
                                imageVector = Icons.Default.TableChart,
                                contentDescription = "Matrix Table View",
                                tint = if (isTableMode) CyberCyan else TextMuted,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        IconButton(
                            onClick = { isTableMode = false },
                            modifier = Modifier.size(28.dp).testTag("switch_cards_mode")
                        ) {
                            Icon(
                                imageVector = Icons.Default.ViewAgenda,
                                contentDescription = "Mobile Cards View",
                                tint = if (!isTableMode) CyberCyan else TextMuted,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Fast Capture Action Controls: Pause, Resume, Clear
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (captureState == CaptureState.RUNNING) {
                        Button(
                            onClick = { viewModel.pauseMonitoring(context) },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberAmber),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(34.dp)
                                .testTag("table_pause_button")
                        ) {
                            Icon(Icons.Default.Pause, contentDescription = null, tint = Color.Black, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Pause", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    } else if (captureState == CaptureState.PAUSED) {
                        Button(
                            onClick = { viewModel.resumeMonitoring(context) },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberEmerald),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(34.dp)
                                .testTag("table_resume_button")
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Resume", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    } else {
                        Button(
                            onClick = { launchVpnMonitoring() },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(34.dp)
                                .testTag("table_start_button")
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color(0xFF031B20), modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Start Capture", color = Color(0xFF031B20), fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }

                    Button(
                        onClick = { viewModel.clearPackets() },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberSurfaceVariant),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(34.dp)
                            .border(1.dp, CyberBorder, RoundedCornerShape(4.dp))
                            .testTag("table_clear_button")
                    ) {
                        Icon(Icons.Default.DeleteSweep, contentDescription = null, tint = TextMuted, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Clear Buffer", color = TextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        // 5. Live Traffic Table (Wireshark-inspired multi-column table or mobile cards)
        item {
            LiveTrafficTable(
                packets = filteredPackets,
                isTableMode = isTableMode,
                onPacketClick = { viewModel.selectPacket(it) }
            )
        }

        // 6. Network Endpoints Overview Card
        item {
            Spacer(modifier = Modifier.height(10.dp))
            SectionHeader(
                title = "Monitored Network Endpoints",
                subtitle = "Active hosts observed during VPN inspection"
            )

            CyberCard {
                endpoints.forEachIndexed { index, ep ->
                    EndpointItemRow(ep)
                    if (index < endpoints.size - 1) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(1.dp)
                                .background(CyberBorder.copy(alpha = 0.3f))
                        )
                    }
                }
            }
        }

        // 7. Extracted Flow Features
        item {
            Spacer(modifier = Modifier.height(10.dp))
            SectionHeader(
                title = "Extracted Traffic Features (14 Dimensions)",
                subtitle = "Statistical metrics fed into AI Anomaly & Forecasting models"
            )

            CyberCard(borderColor = CyberCyan.copy(alpha = 0.4f)) {
                FeatureRow("Packet Count", "$totalPackets total packets")
                FeatureRow("Packet Rate (PPS)", "${feature.packetRate.toInt()} pkts/sec")
                FeatureRow("Byte Rate (KB/s)", "${feature.byteRate.toInt()} KB/sec")
                FeatureRow("Source IP Dispersion", "${feature.srcIpFrequency} unique CIDRs")
                FeatureRow("Destination IP Frequency", "${feature.dstIpFrequency} target interfaces")
                FeatureRow("Target Port", "${feature.dstPort} (${if (feature.dstPort == 443) "HTTPS" else if (feature.dstPort == 22) "SSH" else if (feature.dstPort == 53) "DNS" else "HTTP"})")
                FeatureRow("Protocol Signature", feature.protocol)
                FeatureRow("Connection Duration", "${feature.connectionDuration} ms")
                FeatureRow("Failed Connections", "${feature.failedConnections} drops/sec")
                FeatureRow("TCP Flag Fingerprint", feature.tcpFlags.ifEmpty { "NOMINAL" })
                FeatureRow("Flow Duration", "${feature.flowDuration} ms")
                FeatureRow("Average Packet Size", "${feature.packetSize} bytes")
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // VPN Permission Explanation Dialog
    if (showPermissionDialog) {
        AlertDialog(
            onDismissRequest = { showPermissionDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Shield, contentDescription = null, tint = CyberCyan)
                    Text("Android VPN Permission", color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "CyberGym uses Android's standard VpnService to monitor incoming and outgoing packet headers locally on your device.",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                    Text(
                        text = "🔒 Privacy Guarantee: Only IP addresses, ports, protocol types, TCP flags, and DNS queries are inspected. Encrypted TLS application payload is never read.",
                        color = CyberCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        lineHeight = 15.sp
                    )
                    Text(
                        text = "Tap 'Proceed' to view the Android system confirmation prompt.",
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showPermissionDialog = false
                        val intent = VpnService.prepare(context)
                        if (intent != null) {
                            viewModel.onVpnPermissionRequired()
                            vpnLauncher.launch(intent)
                        } else {
                            viewModel.startVpnMonitoring(context)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberCyan)
                ) {
                    Text("Proceed", color = Color(0xFF031B20), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showPermissionDialog = false }) {
                    Text("Cancel", color = TextMuted)
                }
            },
            containerColor = CyberSurfaceCard,
            tonalElevation = 8.dp
        )
    }

    // Detailed Traffic Analysis Screen (Deep packet analysis inspired by Wireshark)
    selectedPacket?.let { packet ->
        TrafficAnalysisDetailDialog(
            packet = packet,
            onDismiss = { viewModel.selectPacket(null) },
            onInvestigate = { viewModel.investigatePacket(packet) },
            onMarkSafe = { viewModel.markPacketSafe(packet) },
            onOpenIncident = { viewModel.openIncidentForPacket(packet) },
            onBlockIp = { ip -> viewModel.blockIpAddress(ip) }
        )
    }
}

@Composable
private fun EndpointItemRow(endpoint: NetworkEndpoint) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(endpoint.hostName, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                if (endpoint.isLocal) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(3.dp))
                            .background(CyberCyan.copy(alpha = 0.2f))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text("LOCAL", color = CyberCyan, fontSize = 8.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                }
            }
            Text("${endpoint.address} • ${endpoint.role}", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        }

        Column(horizontalAlignment = Alignment.End) {
            Text("${(endpoint.trafficBytes / 1024 / 1024)} MB (${endpoint.packetCount} pkts)", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            Text(
                text = endpoint.status,
                color = if (endpoint.status == "ACTIVE") CyberEmerald else CyberCrimson,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
private fun FeatureRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Medium)
        Text(text = value, color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(CyberBorder.copy(alpha = 0.3f))
    )
}
