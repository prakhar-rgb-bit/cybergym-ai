package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CompareArrows
import androidx.compose.material.icons.filled.CrisisAlert
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AiPipelineResult
import com.example.model.ContributingFeature
import com.example.model.PipelineStage
import com.example.model.RiskLevel
import com.example.model.SecurityAlert
import com.example.model.Severity
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberCrimson
import com.example.ui.theme.CyberCrimsonDark
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberEmerald
import com.example.ui.theme.CyberPurple
import com.example.ui.theme.CyberSurfaceCard
import com.example.ui.theme.CyberSurfaceDark
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale
import kotlin.math.roundToInt

/**
 * End-to-End AI Network Monitoring Pipeline Visualizer.
 *
 * Explicitly visualizes the exact requested flow:
 * Observed Traffic
 * ↓
 * Feature Extraction
 * ↓
 * Baseline Analysis
 * ↓
 * Anomaly Score
 * ↓
 * Attack Classification
 * ↓
 * Attack Probability
 * ↓
 * Risk Score
 * ↓
 * Alert
 */
@Composable
fun AiPipelineFlowDiagram(
    pipelineResult: AiPipelineResult,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }

    CyberCard(
        modifier = modifier
            .fillMaxWidth()
            .testTag("ai_pipeline_flow_diagram"),
        borderColor = if (pipelineResult.activeAlert != null) CyberCrimson.copy(alpha = 0.6f) else CyberBorder
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(CyberCyan.copy(alpha = 0.15f))
                            .border(1.dp, CyberCyan.copy(alpha = 0.4f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = CyberCyan,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "AI NETWORK MONITORING PIPELINE",
                            color = CyberCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "8-Stage Deterministic Inference Engine",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }

                OutlinedButton(
                    onClick = { expanded = !expanded },
                    modifier = Modifier
                        .height(32.dp)
                        .testTag("toggle_pipeline_details_button"),
                    shape = RoundedCornerShape(6.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = CyberCyan),
                    border = ButtonDefaults.outlinedButtonBorder.copy(brush = Brush.horizontalGradient(listOf(CyberCyan, CyberPurple)))
                ) {
                    Text(
                        text = if (expanded) "Hide Flow" else "View Flow",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // High-Level Summary Pipeline Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                PipelineSummaryChip(
                    label = "ANOMALY",
                    value = "${pipelineResult.anomalyResult.anomalyScore.roundToInt()}%",
                    color = if (pipelineResult.anomalyResult.anomalyScore > 50) CyberCrimson else CyberEmerald,
                    modifier = Modifier.weight(1f)
                )
                PipelineSummaryChip(
                    label = "CLASSIFIED",
                    value = pipelineResult.classifiedAttack.code,
                    color = if (pipelineResult.classifiedAttack.code == "NORM") CyberCyan else CyberAmber,
                    modifier = Modifier.weight(1f)
                )
                PipelineSummaryChip(
                    label = "PROBABILITY",
                    value = "${pipelineResult.attackProbability.roundToInt()}%",
                    color = if (pipelineResult.attackProbability > 60) CyberCrimson else CyberCyan,
                    modifier = Modifier.weight(1f)
                )
                PipelineSummaryChip(
                    label = "RISK SCORE",
                    value = "${pipelineResult.securityRiskScore.score}/100",
                    color = when (pipelineResult.securityRiskScore.threatLevel) {
                        RiskLevel.CRITICAL -> CyberCrimson
                        RiskLevel.HIGH -> CyberAmber
                        RiskLevel.MEDIUM -> CyberPurple
                        RiskLevel.LOW -> CyberEmerald
                    },
                    modifier = Modifier.weight(1f)
                )
            }

            // Expandable full 8-stage sequence
            AnimatedVisibility(visible = expanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 14.dp)
                        .animateContentSize()
                ) {
                    Text(
                        text = "EXACT EXECUTION PIPELINE ARCHITECTURE",
                        color = TextMuted,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(bottom = 10.dp)
                    )

                    // 1. Observed Traffic
                    PipelineStageRow(
                        stageNum = 1,
                        title = "Observed Traffic",
                        subtitle = "Continuous sliding window flow & packet header telemetry",
                        value = "${pipelineResult.trafficFeature.packetRate.roundToInt()} PPS | ${pipelineResult.trafficFeature.byteRate.roundToInt()} KB/s",
                        statusText = "INGESTED",
                        statusColor = CyberCyan,
                        icon = Icons.Default.GraphicEq
                    )
                    PipelineConnectorArrow()

                    // 2. Feature Extraction
                    PipelineStageRow(
                        stageNum = 2,
                        title = "Feature Extraction",
                        subtitle = "TCP SYN ratio, port dispersion, failed handshakes & entropy vectors",
                        value = "SYN: ${(pipelineResult.trafficFeature.synRatio * 100).roundToInt()}% | Ports: ${pipelineResult.trafficFeature.uniqueDstPorts} | Drops: ${pipelineResult.trafficFeature.failedConnections}",
                        statusText = "COMPUTED",
                        statusColor = CyberCyan,
                        icon = Icons.Default.Analytics
                    )
                    PipelineConnectorArrow()

                    // 3. Baseline Analysis
                    PipelineStageRow(
                        stageNum = 3,
                        title = "Baseline Analysis",
                        subtitle = "Compare against rolling distribution profile (mean 160 PPS, <18% SYN)",
                        value = pipelineResult.baselineAnalysis.summary,
                        statusText = if (pipelineResult.baselineAnalysis.isElevated) "ELEVATED" else "NOMINAL",
                        statusColor = if (pipelineResult.baselineAnalysis.isElevated) CyberAmber else CyberEmerald,
                        icon = Icons.Default.CompareArrows
                    )
                    PipelineConnectorArrow()

                    // 4. Anomaly Score
                    PipelineStageRow(
                        stageNum = 4,
                        title = "Anomaly Score",
                        subtitle = "Multi-feature isolation score derived from baseline deviation weights",
                        value = "${pipelineResult.anomalyResult.anomalyScore.format(1)}% (${pipelineResult.anomalyResult.classification.label})",
                        statusText = if (pipelineResult.anomalyResult.isAnomaly) "ANOMALOUS" else "BASELINE",
                        statusColor = if (pipelineResult.anomalyResult.isAnomaly) CyberCrimson else CyberEmerald,
                        icon = Icons.Default.Warning
                    )
                    PipelineConnectorArrow()

                    // 5. Attack Classification
                    PipelineStageRow(
                        stageNum = 5,
                        title = "Attack Classification",
                        subtitle = "Heuristic mapping to threat taxonomy (DDoS, Scan, Brute Force, Exfil)",
                        value = pipelineResult.classifiedAttack.displayName,
                        statusText = pipelineResult.classifiedAttack.code,
                        statusColor = if (pipelineResult.classifiedAttack.code == "NORM") CyberCyan else CyberAmber,
                        icon = Icons.Default.Security
                    )
                    PipelineConnectorArrow()

                    // 6. Attack Probability
                    PipelineStageRow(
                        stageNum = 6,
                        title = "Attack Probability",
                        subtitle = "Calibrated sigmoid confidence function responsive to anomaly severity",
                        value = "${pipelineResult.attackProbability.format(1)}% Confidence",
                        statusText = if (pipelineResult.attackProbability > 60) "HIGH PROB" else "LOW PROB",
                        statusColor = if (pipelineResult.attackProbability > 60) CyberCrimson else CyberCyan,
                        icon = Icons.Default.Psychology
                    )
                    PipelineConnectorArrow()

                    // 7. Risk Score
                    PipelineStageRow(
                        stageNum = 7,
                        title = "Risk Score",
                        subtitle = "Combined index of anomaly, probability, asset impact & connection failures",
                        value = "${pipelineResult.securityRiskScore.score} / 100 Threat Index (${pipelineResult.securityRiskScore.threatLevel.label})",
                        statusText = pipelineResult.securityRiskScore.threatLevel.label,
                        statusColor = when (pipelineResult.securityRiskScore.threatLevel) {
                            RiskLevel.CRITICAL -> CyberCrimson
                            RiskLevel.HIGH -> CyberAmber
                            RiskLevel.MEDIUM -> CyberPurple
                            RiskLevel.LOW -> CyberEmerald
                        },
                        icon = Icons.Default.Policy
                    )
                    PipelineConnectorArrow()

                    // 8. Alert
                    PipelineStageRow(
                        stageNum = 8,
                        title = "Alert",
                        subtitle = "Automated SOC incident dispatch and blue team mitigation recommendations",
                        value = pipelineResult.activeAlert?.title ?: "All telemetry within safe parameters. No dispatch needed.",
                        statusText = if (pipelineResult.activeAlert != null) "DISPATCHED" else "CLEAR",
                        statusColor = if (pipelineResult.activeAlert != null) CyberCrimson else CyberEmerald,
                        icon = Icons.Default.CrisisAlert,
                        isLast = true
                    )
                }
            }
        }
    }
}

@Composable
fun ContributingFeaturesSection(
    contributingFeatures: List<ContributingFeature>,
    modifier: Modifier = Modifier
) {
    CyberCard(
        modifier = modifier
            .fillMaxWidth()
            .testTag("contributing_features_card")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.Analytics,
                        contentDescription = null,
                        tint = CyberPurple,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "CONTRIBUTING AI FEATURES",
                        color = CyberPurple,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )
                }

                Text(
                    text = "${contributingFeatures.size} Vectors Evaluated",
                    color = TextMuted,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Exact statistical drivers explaining current anomaly & threat predictions",
                color = TextSecondary,
                fontSize = 11.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                contributingFeatures.forEach { feature ->
                    ContributingFeatureItem(feature = feature)
                }
            }
        }
    }
}

@Composable
private fun ContributingFeatureItem(
    feature: ContributingFeature
) {
    val accentColor = when (feature.severity) {
        RiskLevel.CRITICAL -> CyberCrimson
        RiskLevel.HIGH -> CyberAmber
        RiskLevel.MEDIUM -> CyberPurple
        RiskLevel.LOW -> CyberEmerald
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(CyberSurfaceDark)
            .border(1.dp, accentColor.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
            .padding(10.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(accentColor)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = feature.featureName,
                        color = TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Deviation badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(accentColor.copy(alpha = 0.15f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = if (feature.deviationMultiplier > 1.0) "+${feature.deviationMultiplier.format(1)}x" else "1.0x baseline",
                        color = accentColor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Observed vs Baseline comparison
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Observed: ${feature.observedValue}",
                    color = TextPrimary,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Baseline: ${feature.baselineValue}",
                    color = TextMuted,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
                if (feature.contributionPoints > 0) {
                    Text(
                        text = "+${feature.contributionPoints.format(1)} pts",
                        color = accentColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Explanation string
            Text(
                text = feature.explanation,
                color = TextSecondary,
                fontSize = 10.sp,
                lineHeight = 14.sp
            )
        }
    }
}

@Composable
fun ActiveAlertBanner(
    alert: SecurityAlert,
    onAcknowledge: () -> Unit,
    onInvestigate: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "alert_pulse")
    val alphaAnim by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(800),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alert_pulse_alpha"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(
                Brush.horizontalGradient(
                    listOf(
                        CyberCrimsonDark.copy(alpha = 0.6f),
                        CyberSurfaceDark
                    )
                )
            )
            .border(1.5.dp, CyberCrimson.copy(alpha = alphaAnim), RoundedCornerShape(10.dp))
            .padding(12.dp)
            .testTag("active_security_alert_banner")
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(CyberCrimson)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "AI DISPATCHED SOC INCIDENT",
                        color = CyberCrimson,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Text(
                    text = alert.timestamp,
                    color = TextMuted,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = alert.title,
                color = TextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Target: ${alert.targetEndpoint} | Source: ${alert.sourceEndpoint} | Attack: ${alert.attackType.displayName} (${alert.attackProbability.roundToInt()}% prob)",
                color = TextSecondary,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )

            Spacer(modifier = Modifier.height(6.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(CyberSurfaceCard)
                    .padding(8.dp)
            ) {
                Text(
                    text = "Recommended: ${alert.recommendedAction}",
                    color = CyberCyan,
                    fontSize = 10.sp,
                    lineHeight = 14.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onAcknowledge,
                    colors = ButtonDefaults.buttonColors(containerColor = CyberBorder),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(36.dp)
                        .testTag("acknowledge_alert_button")
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Acknowledge", color = TextPrimary, fontSize = 11.sp)
                }

                Button(
                    onClick = onInvestigate,
                    colors = ButtonDefaults.buttonColors(containerColor = CyberCrimson),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(36.dp)
                        .testTag("investigate_alert_button")
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Investigate", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun PipelineSummaryChip(
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(CyberSurfaceDark)
            .border(1.dp, color.copy(alpha = 0.35f), RoundedCornerShape(6.dp))
            .padding(vertical = 6.dp, horizontal = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = label,
                color = TextMuted,
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                color = color,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
private fun PipelineStageRow(
    stageNum: Int,
    title: String,
    subtitle: String,
    value: String,
    statusText: String,
    statusColor: Color,
    icon: ImageVector,
    isLast: Boolean = false
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(statusColor.copy(alpha = 0.15f))
                .border(1.dp, statusColor.copy(alpha = 0.5f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "$stageNum",
                color = statusColor,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }

        Spacer(modifier = Modifier.width(10.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    color = TextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(statusColor.copy(alpha = 0.15f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = statusText,
                        color = statusColor,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Text(
                text = subtitle,
                color = TextMuted,
                fontSize = 9.sp
            )

            Text(
                text = value,
                color = CyberCyan,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
private fun PipelineConnectorArrow() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.Start
    ) {
        Spacer(modifier = Modifier.width(10.dp))
        Box(
            modifier = Modifier
                .width(2.dp)
                .height(14.dp)
                .background(CyberBorder)
        )
    }
}

private fun Double.format(digits: Int) = String.format(Locale.US, "%.${digits}f", this)
