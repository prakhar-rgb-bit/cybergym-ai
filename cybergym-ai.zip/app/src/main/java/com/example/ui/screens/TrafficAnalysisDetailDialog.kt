package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CrisisAlert
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Report
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.CapturedPacket
import com.example.model.RiskLevel
import com.example.ui.components.CyberCard
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberBgDark
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberBorderBright
import com.example.ui.theme.CyberCrimson
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberEmerald
import com.example.ui.theme.CyberPurple
import com.example.ui.theme.CyberSurfaceCard
import com.example.ui.theme.CyberSurfaceDark
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.random.Random

/**
 * Professional Packet & Traffic Analysis Dialog.
 * Inspired by desktop packet-inspection tools, providing deep header breakdown,
 * frame metrics, Layer 3/4 dissection, simulated hex dump, and SOC triage actions.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TrafficAnalysisDetailDialog(
    packet: CapturedPacket,
    onDismiss: () -> Unit,
    onInvestigate: () -> Unit,
    onMarkSafe: () -> Unit,
    onOpenIncident: () -> Unit,
    onBlockIp: (String) -> Unit = {}
) {
    val scrollState = rememberScrollState()

    var showLayer3 by remember { mutableStateOf(true) }
    var showLayer4 by remember { mutableStateOf(true) }
    var showHexDump by remember { mutableStateOf(false) }
    var showAiReasoning by remember { mutableStateOf(true) }

    val statusColor = when {
        packet.riskLevel == RiskLevel.CRITICAL || packet.status == "ATTACK_BURST" || packet.status == "HIGH_RISK" -> CyberCrimson
        packet.riskLevel == RiskLevel.HIGH || packet.status == "SUSPICIOUS" -> CyberAmber
        packet.riskLevel == RiskLevel.MEDIUM -> CyberPurple
        else -> CyberEmerald
    }

    val protoColor = when (packet.protocol.uppercase()) {
        "TCP" -> CyberCyan
        "UDP" -> Color(0xFF38BDF8)
        "DNS" -> CyberAmber
        "HTTP" -> CyberPurple
        "HTTPS" -> CyberEmerald
        "ICMP" -> Color(0xFFFB7185)
        else -> TextPrimary
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = true
        )
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .fillMaxHeight(0.92f)
                .clip(RoundedCornerShape(16.dp))
                .border(1.dp, CyberCyan.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                .testTag("traffic_analysis_dialog"),
            color = CyberSurfaceDark,
            shadowElevation = 24.dp
        ) {
            Column(
                modifier = Modifier.fillMaxSize()
            ) {
                // Top Header Bar
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CyberSurfaceCard)
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(protoColor.copy(alpha = 0.18f))
                                    .border(1.dp, protoColor.copy(alpha = 0.6f), RoundedCornerShape(8.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Visibility,
                                    contentDescription = null,
                                    tint = protoColor,
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            Column {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = "FRAME #${packet.packetNumber}",
                                        color = CyberCyan,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(3.dp))
                                            .background(protoColor.copy(alpha = 0.2f))
                                            .border(1.dp, protoColor.copy(alpha = 0.5f), RoundedCornerShape(3.dp))
                                            .padding(horizontal = 5.dp, vertical = 1.dp)
                                    ) {
                                        Text(
                                            text = packet.protocol,
                                            color = protoColor,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(3.dp))
                                            .background(CyberSurfaceVariant)
                                            .padding(horizontal = 5.dp, vertical = 1.dp)
                                    ) {
                                        Text(
                                            text = packet.direction,
                                            color = TextSecondary,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                                Text(
                                    text = "Traffic Dissection @ ${packet.timestamp}",
                                    color = TextPrimary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.testTag("close_analysis_dialog_button")
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = TextMuted)
                        }
                    }
                }

                // Scrollable Dissection Body
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(scrollState)
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // 1. KPI Summary Cards Grid
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        maxItemsInEachRow = 2
                    ) {
                        // Risk & Anomaly
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(CyberSurfaceCard)
                                .border(1.dp, statusColor.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                                .padding(10.dp)
                        ) {
                            Column {
                                Text("RISK & ANOMALY", color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = "${packet.riskLevel.name} (${packet.anomalyScore.toInt()}%)",
                                        color = statusColor,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                LinearProgressIndicator(
                                    progress = { (packet.anomalyScore / 100.0).toFloat().coerceIn(0f, 1f) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(4.dp)
                                        .clip(RoundedCornerShape(2.dp)),
                                    color = statusColor,
                                    trackColor = CyberBorder
                                )
                            }
                        }

                        // Length & Wire Info
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(CyberSurfaceCard)
                                .border(1.dp, CyberBorder, RoundedCornerShape(8.dp))
                                .padding(10.dp)
                        ) {
                            Column {
                                Text("FLOW LENGTH", color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "${packet.length} Bytes",
                                    color = TextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "${(packet.length * 8)} bits on wire",
                                    color = TextMuted,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }

                    // 2. Endpoints Bar
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(CyberSurfaceCard)
                            .border(1.dp, CyberBorder, RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("FLOW ENDPOINTS", color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                Text(
                                    text = if (packet.direction == "INBOUND") "INBOUND (WAN ➔ HOST)" else "OUTBOUND (HOST ➔ WAN)",
                                    color = CyberCyan,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("SOURCE", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                    Text(
                                        text = packet.sourceIp,
                                        color = TextPrimary,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        text = "Port: ${if (packet.sourcePort > 0) packet.sourcePort else "N/A"}",
                                        color = CyberCyan,
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }

                                Text(" ➔ ", color = protoColor, fontSize = 16.sp, fontWeight = FontWeight.Bold)

                                Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                                    Text("DESTINATION", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                    Text(
                                        text = packet.destIp,
                                        color = TextPrimary,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        text = "Port: ${if (packet.destPort > 0) packet.destPort else "N/A"}",
                                        color = protoColor,
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }

                    // 3. Layer 3: Internet Protocol v4 (IPv4)
                    DissectionSection(
                        title = "Internet Protocol Version 4 (IPv4)",
                        subtitle = "Src: ${packet.sourceIp}, Dst: ${packet.destIp}",
                        isExpanded = showLayer3,
                        onToggle = { showLayer3 = !showLayer3 }
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            DissectionRow("0100 .... = Version", "4 (IPv4)")
                            DissectionRow(".... 0101 = Header Length", "20 bytes (5)")
                            DissectionRow("Differentiated Services Field", "0x00 (Default)")
                            DissectionRow("Total Length", "${packet.length} bytes")
                            DissectionRow("Identification", "0x${Random.nextInt(0x1000, 0xFFFF).toString(16)} (${Random.nextInt(4000, 65000)})")
                            DissectionRow("Flags", "0x4000 (Don't Fragment)")
                            DissectionRow("Time to Live (TTL)", if (packet.direction == "INBOUND") "54 (Intermediate transit)" else "64 (Local host)")
                            DissectionRow("Protocol", "${packet.protocol} (${when(packet.protocol.uppercase()) { "TCP" -> 6; "UDP" -> 17; "ICMP" -> 1; else -> 6 }})")
                            DissectionRow("Header Checksum", "0x${Random.nextInt(0x1000, 0xFFFF).toString(16)} [Verified correct]")
                            DissectionRow("Source Address", packet.sourceIp)
                            DissectionRow("Destination Address", packet.destIp)
                        }
                    }

                    // 4. Layer 4: Transport Layer (TCP / UDP / ICMP)
                    val layer4Title = when (packet.protocol.uppercase()) {
                        "TCP", "HTTP", "HTTPS" -> "Transmission Control Protocol (TCP)"
                        "UDP", "DNS" -> "User Datagram Protocol (UDP)"
                        "ICMP" -> "Internet Control Message Protocol (ICMP)"
                        else -> "${packet.protocol} Transport Layer"
                    }
                    val layer4Subtitle = when (packet.protocol.uppercase()) {
                        "TCP", "HTTP", "HTTPS" -> "Src Port: ${packet.sourcePort}, Dst Port: ${packet.destPort}"
                        "UDP", "DNS" -> "Src Port: ${packet.sourcePort}, Dst Port: ${packet.destPort}"
                        "ICMP" -> "Type 8 Echo Request / Type 0 Echo Reply"
                        else -> "Layer 4 Payload"
                    }

                    DissectionSection(
                        title = layer4Title,
                        subtitle = layer4Subtitle,
                        isExpanded = showLayer4,
                        onToggle = { showLayer4 = !showLayer4 }
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            if (packet.protocol.uppercase() in listOf("TCP", "HTTP", "HTTPS")) {
                                DissectionRow("Source Port", "${packet.sourcePort}")
                                DissectionRow("Destination Port", "${packet.destPort}")
                                DissectionRow("Sequence Number", "${Random.nextInt(100000, 999999)}")
                                DissectionRow("Acknowledgment Number", "${Random.nextInt(100000, 999999)}")
                                DissectionRow("Header Length", "32 bytes (8)")
                                DissectionRow("Window Size Value", "65535")
                                DissectionRow("Checksum", "0x${Random.nextInt(0x1000, 0xFFFF).toString(16)} [Unverified by NIC offload]")

                                // Bit-Level TCP Flags
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("TCP CONTROL BITS (FLAGS)", color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                Spacer(modifier = Modifier.height(2.dp))

                                val flagsList = listOf(
                                    "SYN" to (packet.tcpFlags.contains("SYN")),
                                    "ACK" to (packet.tcpFlags.contains("ACK")),
                                    "PSH" to (packet.tcpFlags.contains("PSH")),
                                    "FIN" to (packet.tcpFlags.contains("FIN")),
                                    "RST" to (packet.tcpFlags.contains("RST")),
                                    "URG" to (packet.tcpFlags.contains("URG"))
                                )

                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    flagsList.forEach { (flag, active) ->
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(3.dp))
                                                .background(if (active) (if (flag == "SYN" || flag == "RST") CyberCrimson else CyberCyan).copy(alpha = 0.2f) else CyberSurfaceVariant)
                                                .border(1.dp, if (active) (if (flag == "SYN" || flag == "RST") CyberCrimson else CyberCyan) else CyberBorder, RoundedCornerShape(3.dp))
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = "$flag: ${if (active) "1" else "0"}",
                                                color = if (active) (if (flag == "SYN" || flag == "RST") CyberCrimson else CyberCyan) else TextMuted,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }
                                    }
                                }
                            } else if (packet.protocol.uppercase() in listOf("UDP", "DNS")) {
                                DissectionRow("Source Port", "${packet.sourcePort}")
                                DissectionRow("Destination Port", "${packet.destPort}")
                                DissectionRow("Length", "${packet.length - 20} bytes")
                                DissectionRow("Checksum", "0x${Random.nextInt(0x1000, 0xFFFF).toString(16)}")

                                if (packet.dnsQuery != null) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("DOMAIN NAME SYSTEM (DNS)", color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                    DissectionRow("Transaction ID", "0x${Random.nextInt(0x1000, 0xFFFF).toString(16)}")
                                    DissectionRow("Queries", "1")
                                    DissectionRow("Query Domain (QNAME)", packet.dnsQuery)
                                    DissectionRow("Record Type", "A (Host IPv4)")
                                    DissectionRow("Class", "IN (0x0001)")
                                }
                            } else if (packet.protocol.uppercase() == "ICMP") {
                                DissectionRow("Type", "8 (Echo / Ping Request)")
                                DissectionRow("Code", "0")
                                DissectionRow("Checksum", "0x${Random.nextInt(0x1000, 0xFFFF).toString(16)}")
                                DissectionRow("Identifier (BE)", "0x${Random.nextInt(0x1000, 0xFFFF).toString(16)}")
                                DissectionRow("Sequence Number", "${(packet.id % 256)}")
                                DissectionRow("Data Payload", "32 bytes of standard ping ICMP padding")
                            }
                        }
                    }

                    // 5. Application Layer & Privacy Verification
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(CyberSurfaceCard)
                            .border(1.dp, CyberCyan.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(Icons.Default.Lock, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(16.dp))
                                Text("APPLICATION FLOW & PRIVACY SAFEGUARD", color = CyberCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }
                            Text(
                                text = packet.info,
                                color = TextPrimary,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.SemiBold
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(CyberSurfaceVariant)
                                    .padding(8.dp)
                            ) {
                                Text(
                                    text = "🔒 Privacy Guarantee: Encrypted TLS/HTTPS payload was NOT decrypted. Local VpnService extracts only permitted headers & flow metadata. Content privacy is strictly maintained.",
                                    color = TextMuted,
                                    fontSize = 10.sp,
                                    lineHeight = 14.sp
                                )
                            }
                        }
                    }

                    // 6. AI SOC Threat & Anomaly Assessment
                    DissectionSection(
                        title = "AI SOC Threat & Anomaly Assessment",
                        subtitle = "Risk: ${packet.riskLevel.name} • Score: ${packet.anomalyScore.toInt()}/100",
                        isExpanded = showAiReasoning,
                        onToggle = { showAiReasoning = !showAiReasoning }
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(statusColor.copy(alpha = 0.1f))
                                    .border(1.dp, statusColor.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                                    .padding(10.dp)
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("AI Model Confidence", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                        Text("96.4% Certainty", color = CyberCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                    }
                                    Text(
                                        text = packet.aiAnalysisReason,
                                        color = TextPrimary,
                                        fontSize = 11.sp,
                                        lineHeight = 15.sp
                                    )
                                }
                            }
                        }
                    }

                    // 7. Authentic Raw Hex & ASCII Dissection View
                    DissectionSection(
                        title = "Packet Hex Dump & ASCII Dissection",
                        subtitle = "Byte Offset | Hexadecimal | ASCII Representation",
                        isExpanded = showHexDump,
                        onToggle = { showHexDump = !showHexDump }
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF030712))
                                .border(1.dp, CyberBorder, RoundedCornerShape(6.dp))
                                .horizontalScroll(rememberScrollState())
                                .padding(10.dp)
                        ) {
                            Text(
                                text = generateSimulatedHexDump(packet),
                                color = CyberCyan,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                lineHeight = 14.sp
                            )
                        }
                    }
                }

                // Bottom Action Buttons
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CyberSurfaceCard)
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onInvestigate,
                            colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_forecast_from_packet")
                        ) {
                            Icon(Icons.Default.Timeline, contentDescription = null, tint = Color(0xFF031B20), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Forecast", color = Color(0xFF031B20), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = onOpenIncident,
                            colors = ButtonDefaults.buttonColors(containerColor = CyberCrimson),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_incident_from_packet")
                        ) {
                            Icon(Icons.Default.Report, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Incident", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { onBlockIp(packet.sourceIp) },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberAmber),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_block_ip_from_packet")
                        ) {
                            Icon(Icons.Default.Block, contentDescription = null, tint = Color(0xFF1B1100), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Block IP", color = Color(0xFF1B1100), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = onMarkSafe,
                            colors = ButtonDefaults.buttonColors(containerColor = CyberSurfaceVariant),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_mark_safe_from_packet")
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = CyberEmerald, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Safe", color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DissectionSection(
    title: String,
    subtitle: String,
    isExpanded: Boolean,
    onToggle: () -> Unit,
    content: @Composable () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(CyberSurfaceCard)
            .border(1.dp, CyberBorder, RoundedCornerShape(8.dp))
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggle() }
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(title, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Text(subtitle, color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }
                Icon(
                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = null,
                    tint = TextMuted
                )
            }

            AnimatedVisibility(visible = isExpanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(CyberBorder.copy(alpha = 0.4f))
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    content()
                }
            }
        }
    }
}

@Composable
private fun DissectionRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        Text(text = value, color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}

/**
 * Generates an authentic simulated hex + ASCII byte dump for the captured packet.
 */
private fun generateSimulatedHexDump(packet: CapturedPacket): String {
    val sb = StringBuilder()
    val pseudoBytes = mutableListOf<Int>()

    // IPv4 Header bytes (20 bytes)
    pseudoBytes.addAll(listOf(0x45, 0x00, (packet.length shr 8) and 0xFF, packet.length and 0xFF))
    pseudoBytes.addAll(listOf(0x7a, 0x1b, 0x40, 0x00, 0x40)) // TTL 64, Don't fragment
    val protoNum = when (packet.protocol.uppercase()) { "TCP" -> 6; "UDP" -> 17; "ICMP" -> 1; else -> 6 }
    pseudoBytes.add(protoNum)
    pseudoBytes.addAll(listOf(0xb2, 0xf1)) // Checksum

    // Src IP bytes
    val srcParts = packet.sourceIp.split(".").map { it.toIntOrNull() ?: 0 }
    pseudoBytes.addAll(srcParts.take(4))

    // Dst IP bytes
    val dstParts = packet.destIp.split(".").map { it.toIntOrNull() ?: 0 }
    pseudoBytes.addAll(dstParts.take(4))

    // Layer 4 Ports
    pseudoBytes.add((packet.sourcePort shr 8) and 0xFF)
    pseudoBytes.add(packet.sourcePort and 0xFF)
    pseudoBytes.add((packet.destPort shr 8) and 0xFF)
    pseudoBytes.add(packet.destPort and 0xFF)

    // Remainder payload bytes
    val totalDumpBytes = minOf(64, packet.length)
    val seed = packet.id
    val rand = Random(seed)
    while (pseudoBytes.size < totalDumpBytes) {
        pseudoBytes.add(rand.nextInt(0, 256))
    }

    // Format in 16-byte rows
    for (i in pseudoBytes.indices step 16) {
        val offsetStr = String.format("%04x", i)
        val chunk = pseudoBytes.subList(i, minOf(i + 16, pseudoBytes.size))

        val hexPart = chunk.map { String.format("%02x", it) }.joinToString(" ")
        val paddedHex = hexPart.padEnd(48, ' ')

        val asciiPart = chunk.map { b ->
            if (b in 32..126) b.toChar() else '.'
        }.joinToString("")

        sb.append("$offsetStr  $paddedHex  $asciiPart\n")
    }

    return sb.toString().trimEnd()
}
