package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.NetworkNode
import com.example.model.NodeState
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberCrimson
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberEmerald
import com.example.ui.theme.CyberSurfaceCard
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.StatusProtected
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun NetworkTopologyGraph(
    nodes: List<NetworkNode>,
    onNodeSelected: (NetworkNode) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedNode by remember { mutableStateOf<NetworkNode?>(nodes.firstOrNull { it.id == "web_server" }) }

    val infiniteTransition = rememberInfiniteTransition(label = "packet_flow")
    val flowProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "packet_flow_progress"
    )

    Column(modifier = modifier.fillMaxWidth()) {
        // Topology Canvas Box
        CyberCard(
            backgroundColor = CyberSurfaceCard,
            borderColor = CyberBorder
        ) {
            Text(
                text = "VIRTUAL NETWORK TOPOLOGY (CYBER GYM RANGE)",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = CyberCyan,
                letterSpacing = 1.sp,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(8.dp))

            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(280.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF060A12))
                    .border(1.dp, CyberBorder.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
            ) {
                val w = constraints.maxWidth.toFloat()
                val h = constraints.maxHeight.toFloat()

                val clientsPos = Offset(w * 0.18f, h * 0.25f)
                val routerPos = Offset(w * 0.50f, h * 0.25f)
                val firewallPos = Offset(w * 0.50f, h * 0.55f)
                val webPos = Offset(w * 0.20f, h * 0.85f)
                val dbPos = Offset(w * 0.50f, h * 0.85f)
                val dnsPos = Offset(w * 0.80f, h * 0.85f)

                // Background Links Canvas
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val lineColor = Color(0xFF1E293B)
                    val dashedEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)

                    // Draw connections
                    drawLine(lineColor, clientsPos, routerPos, strokeWidth = 3f, pathEffect = dashedEffect)
                    drawLine(lineColor, routerPos, firewallPos, strokeWidth = 3f)
                    drawLine(lineColor, firewallPos, webPos, strokeWidth = 3f)
                    drawLine(lineColor, firewallPos, dbPos, strokeWidth = 3f)
                    drawLine(lineColor, firewallPos, dnsPos, strokeWidth = 3f)

                    // Animated Packet Dots
                    fun drawPacket(start: Offset, end: Offset, color: Color) {
                        val packetX = start.x + (end.x - start.x) * flowProgress
                        val packetY = start.y + (end.y - start.y) * flowProgress
                        drawCircle(color, radius = 5f, center = Offset(packetX, packetY))
                    }

                    val webNode = nodes.find { it.id == "web_server" }
                    val packetColor = if (webNode?.state == NodeState.COMPROMISED) CyberCrimson else CyberCyan

                    drawPacket(clientsPos, routerPos, packetColor)
                    drawPacket(routerPos, firewallPos, packetColor)
                    drawPacket(firewallPos, webPos, packetColor)
                }

                val densityValue = LocalDensity.current.density

                // Interactive Nodes
                nodes.forEach { node ->
                    val pos = when (node.id) {
                        "clients" -> clientsPos
                        "router" -> routerPos
                        "firewall" -> firewallPos
                        "web_server" -> webPos
                        "db_server" -> dbPos
                        "dns_server" -> dnsPos
                        else -> routerPos
                    }

                    NodeItem(
                        node = node,
                        isSelected = selectedNode?.id == node.id,
                        modifier = Modifier
                            .offset(
                                x = (pos.x / densityValue).dp - 32.dp,
                                y = (pos.y / densityValue).dp - 32.dp
                            ),
                        onClick = {
                            selectedNode = node
                            onNodeSelected(node)
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // State Legend
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                LegendItem("Normal", CyberEmerald)
                LegendItem("Suspicious", CyberAmber)
                LegendItem("Compromised", CyberCrimson)
                LegendItem("Protected", StatusProtected)
            }
        }

        // Host Telemetry Inspector Card
        selectedNode?.let { node ->
            Spacer(modifier = Modifier.height(12.dp))
            HostTelemetryCard(node = node)
        }
    }
}

@Composable
private fun NodeItem(
    node: NetworkNode,
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val stateColor = when (node.state) {
        NodeState.NORMAL -> CyberEmerald
        NodeState.SUSPICIOUS -> CyberAmber
        NodeState.COMPROMISED -> CyberCrimson
        NodeState.PROTECTED -> StatusProtected
    }

    val icon = when (node.id) {
        "clients" -> Icons.Default.Computer
        "router" -> Icons.Default.Router
        "firewall" -> Icons.Default.Security
        "web_server" -> Icons.Default.Dns
        "db_server" -> Icons.Default.Storage
        "dns_server" -> Icons.Default.VpnKey
        else -> Icons.Default.Dns
    }

    Column(
        modifier = modifier
            .width(64.dp)
            .clickable { onClick() },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(CyberSurfaceVariant)
                .border(
                    width = if (isSelected) 2.5.dp else 1.5.dp,
                    color = if (isSelected) CyberCyan else stateColor,
                    shape = CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = node.name,
                tint = stateColor,
                modifier = Modifier.size(22.dp)
            )
        }
        Spacer(modifier = Modifier.height(3.dp))
        Text(
            text = node.name.split(" ").firstOrNull() ?: node.name,
            color = if (isSelected) CyberCyan else TextPrimary,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1
        )
    }
}

@Composable
private fun LegendItem(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = label,
            color = TextSecondary,
            fontSize = 10.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
private fun HostTelemetryCard(node: NetworkNode) {
    val stateColor = when (node.state) {
        NodeState.NORMAL -> CyberEmerald
        NodeState.SUSPICIOUS -> CyberAmber
        NodeState.COMPROMISED -> CyberCrimson
        NodeState.PROTECTED -> StatusProtected
    }

    CyberCard(
        borderColor = stateColor.copy(alpha = 0.6f),
        backgroundColor = CyberSurfaceVariant.copy(alpha = 0.5f)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = node.name.uppercase(),
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "IP: ${node.ip} | ${node.role}",
                    color = TextMuted,
                    fontSize = 11.sp
                )
            }
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(stateColor.copy(alpha = 0.2f))
                    .border(1.dp, stateColor, RoundedCornerShape(6.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = node.state.name,
                    color = stateColor,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            HostMetric("CPU Usage", "${node.cpuUsage}%", if (node.cpuUsage > 80) CyberCrimson else CyberCyan)
            HostMetric("Memory", "${node.memoryUsage}%", CyberCyan)
            HostMetric("Inbound", "${node.inboundMbps} Mb/s", if (node.inboundMbps > 3.0) CyberAmber else TextPrimary)
            HostMetric("Active Conns", "${node.activeConns}", TextPrimary)
        }
    }
}

@Composable
private fun HostMetric(label: String, value: String, color: Color) {
    Column {
        Text(text = label, color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Text(text = value, color = color, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, fontFamily = FontFamily.Monospace)
    }
}
