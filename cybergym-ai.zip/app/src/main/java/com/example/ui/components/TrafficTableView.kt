package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CrisisAlert
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CapturedPacket
import com.example.model.RiskLevel
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberCrimson
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberEmerald
import com.example.ui.theme.CyberPurple
import com.example.ui.theme.CyberSurfaceCard
import com.example.ui.theme.CyberSurfaceDark
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

/**
 * Mobile-friendly Live Traffic Table inspired by professional packet analysis software.
 * Displays all 9 requested attributes:
 * - Protocol column
 * - Timestamp
 * - Source
 * - Destination
 * - Source port
 * - Destination port
 * - Packet/flow length
 * - Risk
 * - Anomaly indicator
 *
 * Supports horizontal scrolling table mode with fixed column widths and zebra striping,
 * as well as a compact mobile card stream mode.
 */
@Composable
fun LiveTrafficTable(
    packets: List<CapturedPacket>,
    isTableMode: Boolean,
    onPacketClick: (CapturedPacket) -> Unit,
    modifier: Modifier = Modifier
) {
    if (packets.isEmpty()) {
        EmptyTrafficPlaceholder(modifier)
        return
    }

    if (isTableMode) {
        MatrixTrafficTableView(
            packets = packets,
            onPacketClick = onPacketClick,
            modifier = modifier
        )
    } else {
        MobileCardStreamView(
            packets = packets,
            onPacketClick = onPacketClick,
            modifier = modifier
        )
    }
}

/**
 * Professional Matrix Table View with synchronized horizontal scrolling.
 */
@Composable
private fun MatrixTrafficTableView(
    packets: List<CapturedPacket>,
    onPacketClick: (CapturedPacket) -> Unit,
    modifier: Modifier = Modifier
) {
    val horizontalScrollState = rememberScrollState()

    // Table Column Widths (dp)
    val colNoWidth = 48.dp
    val colTimeWidth = 72.dp
    val colProtoWidth = 70.dp
    val colSrcWidth = 104.dp
    val colSrcPortWidth = 58.dp
    val colDstWidth = 104.dp
    val colDstPortWidth = 58.dp
    val colLenWidth = 64.dp
    val colRiskWidth = 66.dp
    val colAnomalyWidth = 84.dp
    val colInfoWidth = 180.dp

    val totalTableWidth = colNoWidth + colTimeWidth + colProtoWidth + colSrcWidth +
            colSrcPortWidth + colDstWidth + colDstPortWidth + colLenWidth +
            colRiskWidth + colAnomalyWidth + colInfoWidth

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(CyberSurfaceDark)
            .border(1.dp, CyberBorder, RoundedCornerShape(8.dp))
    ) {
        Column {
            // Horizontal scroll hint banner
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CyberSurfaceVariant.copy(alpha = 0.5f))
                    .padding(horizontal = 10.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "⟵ Swipe horizontally for full packet headers (9 columns) ⟶",
                    color = CyberCyan,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = "${packets.size} packets",
                    color = TextMuted,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            // Horizontally Scrollable Container
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(horizontalScrollState)
            ) {
                Column(modifier = Modifier.width(totalTableWidth)) {
                    // Sticky Table Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF0F172A))
                            .border(1.dp, CyberBorder)
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TableHeaderCell("No.", colNoWidth)
                        TableHeaderCell("Time", colTimeWidth)
                        TableHeaderCell("Protocol", colProtoWidth)
                        TableHeaderCell("Source", colSrcWidth)
                        TableHeaderCell("SPort", colSrcPortWidth)
                        TableHeaderCell("Destination", colDstWidth)
                        TableHeaderCell("DPort", colDstPortWidth)
                        TableHeaderCell("Length", colLenWidth)
                        TableHeaderCell("Risk", colRiskWidth)
                        TableHeaderCell("Anomaly", colAnomalyWidth)
                        TableHeaderCell("Info / Details", colInfoWidth)
                    }

                    // Table Rows
                    packets.forEachIndexed { index, packet ->
                        val isEven = index % 2 == 0
                        val isAlert = packet.riskLevel == RiskLevel.CRITICAL || packet.status == "ATTACK_BURST"
                        val rowBg = when {
                            isAlert -> CyberCrimson.copy(alpha = 0.12f)
                            isEven -> Color(0xFF0A0F1D)
                            else -> Color(0xFF0E1528)
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(rowBg)
                                .border(0.5.dp, if (isAlert) CyberCrimson.copy(alpha = 0.3f) else CyberBorder.copy(alpha = 0.3f))
                                .clickable { onPacketClick(packet) }
                                .padding(vertical = 7.dp)
                                .testTag("packet_table_row_${packet.id}"),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // 1. Packet No
                            TableCell(text = "#${packet.packetNumber}", width = colNoWidth, color = TextMuted)

                            // 2. Timestamp
                            TableCell(text = packet.timestamp, width = colTimeWidth, color = TextSecondary)

                            // 3. Protocol Column
                            Box(
                                modifier = Modifier
                                    .width(colProtoWidth)
                                    .padding(horizontal = 4.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                ProtocolBadge(protocol = packet.protocol)
                            }

                            // 4. Source IP
                            TableCell(text = packet.sourceIp, width = colSrcWidth, color = TextPrimary, isBold = true)

                            // 5. Source Port
                            TableCell(text = if (packet.sourcePort > 0) "${packet.sourcePort}" else "—", width = colSrcPortWidth, color = CyberCyan)

                            // 6. Destination IP
                            TableCell(text = packet.destIp, width = colDstWidth, color = TextPrimary, isBold = true)

                            // 7. Destination Port
                            TableCell(text = if (packet.destPort > 0) "${packet.destPort}" else "—", width = colDstPortWidth, color = CyberCyan)

                            // 8. Packet/Flow Length
                            TableCell(text = "${packet.length} B", width = colLenWidth, color = TextSecondary)

                            // 9. Risk Column
                            Box(
                                modifier = Modifier
                                    .width(colRiskWidth)
                                    .padding(horizontal = 3.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                RiskBadge(riskLevel = packet.riskLevel)
                            }

                            // 10. Anomaly Indicator Column
                            Box(
                                modifier = Modifier
                                    .width(colAnomalyWidth)
                                    .padding(horizontal = 4.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                AnomalyGauge(score = packet.anomalyScore)
                            }

                            // 11. Info / Summary
                            Box(
                                modifier = Modifier
                                    .width(colInfoWidth)
                                    .padding(horizontal = 6.dp)
                            ) {
                                Text(
                                    text = packet.info,
                                    color = TextMuted,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Mobile-friendly Dense Card Stream View.
 * Displays all 9 attributes in a high-density vertical layout.
 */
@Composable
private fun MobileCardStreamView(
    packets: List<CapturedPacket>,
    onPacketClick: (CapturedPacket) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        packets.forEach { packet ->
            MobilePacketCard(
                packet = packet,
                onClick = { onPacketClick(packet) }
            )
        }
    }
}

@Composable
private fun MobilePacketCard(
    packet: CapturedPacket,
    onClick: () -> Unit
) {
    val isAlert = packet.riskLevel == RiskLevel.CRITICAL || packet.status == "ATTACK_BURST"
    val borderColor = if (isAlert) CyberCrimson.copy(alpha = 0.7f) else CyberBorder

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(CyberSurfaceCard)
            .border(1.dp, borderColor, RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(10.dp)
            .testTag("packet_card_${packet.id}")
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            // Row 1: Header metadata (No, Timestamp, Protocol, Risk, Anomaly)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "#${packet.packetNumber}",
                        color = TextMuted,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = packet.timestamp,
                        color = TextSecondary,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    ProtocolBadge(protocol = packet.protocol)
                    if (packet.tcpFlags.isNotEmpty()) {
                        Text(
                            text = "[${packet.tcpFlags}]",
                            color = TextMuted,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    RiskBadge(riskLevel = packet.riskLevel)
                    AnomalyGauge(score = packet.anomalyScore)
                }
            }

            // Row 2: Source:Port -> Destination:Port + Length
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = packet.sourceIp,
                        color = TextPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = ":${if (packet.sourcePort > 0) packet.sourcePort else "—"}",
                        color = CyberCyan,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = " ➔ ",
                        color = CyberCyan,
                        fontSize = 10.sp
                    )
                    Text(
                        text = packet.destIp,
                        color = TextPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = ":${if (packet.destPort > 0) packet.destPort else "—"}",
                        color = CyberCyan,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Text(
                    text = "${packet.length} B",
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }

            // Row 3: Packet Info Summary
            Text(
                text = packet.info,
                color = TextMuted,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun TableHeaderCell(text: String, width: androidx.compose.ui.unit.Dp) {
    Box(
        modifier = Modifier
            .width(width)
            .padding(horizontal = 4.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Text(
            text = text,
            color = CyberCyan,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
private fun TableCell(
    text: String,
    width: androidx.compose.ui.unit.Dp,
    color: Color = TextPrimary,
    isBold: Boolean = false
) {
    Box(
        modifier = Modifier
            .width(width)
            .padding(horizontal = 4.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Text(
            text = text,
            color = color,
            fontSize = 10.sp,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal,
            fontFamily = FontFamily.Monospace,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun ProtocolBadge(protocol: String) {
    val (color, bg) = when (protocol.uppercase()) {
        "TCP" -> CyberCyan to CyberCyan.copy(alpha = 0.15f)
        "UDP" -> Color(0xFF38BDF8) to Color(0xFF38BDF8).copy(alpha = 0.15f)
        "DNS" -> CyberAmber to CyberAmber.copy(alpha = 0.15f)
        "HTTP" -> CyberPurple to CyberPurple.copy(alpha = 0.15f)
        "HTTPS" -> CyberEmerald to CyberEmerald.copy(alpha = 0.15f)
        "ICMP" -> Color(0xFFFB7185) to Color(0xFFFB7185).copy(alpha = 0.15f)
        else -> TextPrimary to CyberSurfaceVariant
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(3.dp))
            .background(bg)
            .border(1.dp, color.copy(alpha = 0.4f), RoundedCornerShape(3.dp))
            .padding(horizontal = 4.dp, vertical = 1.dp)
    ) {
        Text(
            text = protocol,
            color = color,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun RiskBadge(riskLevel: RiskLevel) {
    val (color, label) = when (riskLevel) {
        RiskLevel.CRITICAL -> CyberCrimson to "CRIT"
        RiskLevel.HIGH -> Color(0xFFFF5252) to "HIGH"
        RiskLevel.MEDIUM -> CyberAmber to "MED"
        RiskLevel.LOW -> CyberEmerald to "LOW"
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(3.dp))
            .background(color.copy(alpha = 0.15f))
            .border(0.8.dp, color.copy(alpha = 0.6f), RoundedCornerShape(3.dp))
            .padding(horizontal = 4.dp, vertical = 1.dp)
    ) {
        Text(
            text = label,
            color = color,
            fontSize = 8.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun AnomalyGauge(score: Double) {
    val scoreInt = score.toInt().coerceIn(0, 100)
    val color = when {
        scoreInt >= 75 -> CyberCrimson
        scoreInt >= 40 -> CyberAmber
        else -> CyberEmerald
    }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        // Mini Progress bar
        LinearProgressIndicator(
            progress = { (scoreInt / 100f).coerceIn(0f, 1f) },
            modifier = Modifier
                .width(28.dp)
                .height(4.dp)
                .clip(RoundedCornerShape(2.dp)),
            color = color,
            trackColor = CyberBorder
        )
        Text(
            text = if (scoreInt >= 75) "$scoreInt% ⚡" else "$scoreInt%",
            color = color,
            fontSize = 8.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
private fun EmptyTrafficPlaceholder(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(CyberSurfaceCard)
            .border(1.dp, CyberBorder, RoundedCornerShape(8.dp))
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.FilterAlt, contentDescription = null, tint = TextMuted, modifier = Modifier.size(28.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text("No packets matching current filter", color = TextSecondary, fontSize = 12.sp)
            Text("Tap 'Start Live VPN' or 'Simulate Traffic' to resume inspection", color = TextMuted, fontSize = 10.sp)
        }
    }
}
