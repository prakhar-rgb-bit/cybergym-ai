package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SportsKabaddi
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CyberCard
import com.example.ui.components.CyberPrimaryButton
import com.example.ui.components.CyberSecondaryButton
import com.example.ui.components.LivePulseDot
import com.example.ui.components.NetworkTopologyGraph
import com.example.ui.components.SectionHeader
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.CyberGymViewModel
import com.example.viewmodel.ScreenRoute

@Composable
fun CyberGymScreen(
    viewModel: CyberGymViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val nodes by viewModel.repository.networkNodes.collectAsState()
    val isAttacking by viewModel.isAttackActive.collectAsState()
    val activeScenario by viewModel.activeScenario.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "CYBER GYM RANGE",
                    color = CyberCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Interactive Cyber Range",
                    color = TextPrimary,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black
                )
            }
            LivePulseDot(label = if (isAttacking) "ATTACK IN PROGRESS" else "RANGE STANDBY")
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Range Action CTAs
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            CyberPrimaryButton(
                text = "Red Team Attack →",
                icon = Icons.Default.SportsKabaddi,
                onClick = { viewModel.navigateTo(ScreenRoute.RED_TEAM) },
                modifier = Modifier.weight(1f)
            )
            CyberSecondaryButton(
                text = "Blue Team Defense →",
                icon = Icons.Default.Shield,
                onClick = { viewModel.navigateTo(ScreenRoute.BLUE_TEAM) },
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Virtual Topology
        NetworkTopologyGraph(
            nodes = nodes,
            onNodeSelected = { node ->
                viewModel.pushNotification("Selected host ${node.name} (${node.ip}) for telemetry audit.")
            }
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Range Status Info
        CyberCard {
            Text(
                text = "RANGE ENVIRONMENT TELEMETRY",
                color = CyberCyan,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "The Cyber Gym virtual network is partitioned into edge clients, BGP gateway router, stateful firewall, and isolated host VLANs. Network state transitions are updated in real-time as Red Team offensive vectors or Blue Team tactical mitigations are executed.",
                color = TextSecondary,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            CyberSecondaryButton(
                text = "Reset Cyber Gym Network State",
                icon = Icons.Default.Refresh,
                onClick = {
                    viewModel.repository.resetAllNodes()
                    viewModel.stopRedTeamScenario()
                },
                modifier = Modifier.fillMaxWidth()
            )
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}
