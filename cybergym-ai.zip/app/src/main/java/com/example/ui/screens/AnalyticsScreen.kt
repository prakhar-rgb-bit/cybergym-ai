package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AttackProbabilityBarChart
import com.example.ui.components.CyberCard
import com.example.ui.components.LivePulseDot
import com.example.ui.components.MetricPill
import com.example.ui.components.SectionHeader
import com.example.ui.components.TelemetryLineChart
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberCrimson
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberEmerald
import com.example.ui.theme.CyberPurple
import com.example.ui.theme.CyberSurfaceCard
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.CyberGymViewModel

@Composable
fun AnalyticsScreen(
    viewModel: CyberGymViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val timeSeries by viewModel.timeSeriesHistory.collectAsState()
    val breakdowns by viewModel.probabilitiesBreakdown.collectAsState()
    val modelMetrics by viewModel.repository.modelMetrics.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "SECURITY METRICS & ANALYTICS",
                    color = CyberCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Performance Insights",
                    color = TextPrimary,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black
                )
            }
            LivePulseDot(label = "AGGREGATED")
        }

        Spacer(modifier = Modifier.height(16.dp))

        // High Level Analytics KPI Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MetricPill("Model Accuracy", "${modelMetrics.trainingAccuracy}%", subtitle = "Ensemble", accentColor = CyberCyan, modifier = Modifier.weight(1f))
            MetricPill("F1-Score", "${modelMetrics.f1Score}", subtitle = "Macro Avg", accentColor = CyberEmerald, modifier = Modifier.weight(1f))
            MetricPill("Avg Response", "2.1s", subtitle = "Blue Team", accentColor = CyberPurple, modifier = Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Ingress Volume Over Time
        SectionHeader(
            title = "Traffic Volume Ingress (PPS)",
            subtitle = "Measured over rolling telemetry interval"
        )
        TelemetryLineChart(
            points = timeSeries,
            valueSelector = { it.pps },
            lineColor = CyberCyan,
            unit = "PPS"
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Anomaly Score Distribution
        SectionHeader(
            title = "Isolation Forest Anomaly Trajectory",
            subtitle = "Statistical outlier deviation index"
        )
        TelemetryLineChart(
            points = timeSeries,
            valueSelector = { it.anomalyScore },
            lineColor = CyberAmber,
            unit = "/100"
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Multi-Class Attack Distribution
        SectionHeader(
            title = "Forecast Attack Class Distribution",
            subtitle = "Ensemble model probability clustering"
        )
        CyberCard {
            AttackProbabilityBarChart(breakdowns = breakdowns)
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}
