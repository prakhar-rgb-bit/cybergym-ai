package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CrisisAlert
import androidx.compose.material.icons.filled.Lan
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DefenseAction
import com.example.model.RiskLevel
import com.example.ui.components.CyberCard
import com.example.ui.components.CyberPrimaryButton
import com.example.ui.components.CyberSecondaryButton
import com.example.ui.components.LivePulseDot
import com.example.ui.components.MetricPill
import com.example.ui.components.SectionHeader
import com.example.ui.components.ThreatBadge
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberCrimson
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberEmerald
import com.example.ui.theme.CyberPurple
import com.example.ui.theme.CyberSurfaceCard
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.CyberGymViewModel
import com.example.viewmodel.ScreenRoute

@Composable
fun BlueTeamScreen(
    viewModel: CyberGymViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    val forecast by viewModel.attackForecast.collectAsState()
    val isAttacking by viewModel.isAttackActive.collectAsState()
    val evaluation by viewModel.latestEvaluation.collectAsState()
    val activeMitigations by viewModel.activeMitigations.collectAsState()
    val defenseActions = viewModel.repository.defenseActions

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "BLUE TEAM DEFENSE CENTER",
                    color = CyberCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Incident Response & Mitigations",
                    color = TextPrimary,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black
                )
            }
            LivePulseDot(label = if (isAttacking) "THREAT INCOMING" else "GUARD ONLINE")
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Threat Forecast Alert Banner
        CyberCard(
            borderColor = if (forecast.riskLevel == RiskLevel.CRITICAL) CyberCrimson else CyberCyan,
            backgroundColor = CyberSurfaceCard
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CrisisAlert,
                        contentDescription = null,
                        tint = if (forecast.riskLevel == RiskLevel.CRITICAL) CyberCrimson else CyberCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "FORECAST ALERT: ${forecast.attackType.displayName.uppercase()}",
                        color = TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
                ThreatBadge(risk = forecast.riskLevel)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Impending ${forecast.attackType.displayName} detected with ${forecast.probability.toInt()}% probability. Window: ${forecast.forecastWindow}.",
                color = TextSecondary,
                fontSize = 12.sp
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Defense Action Grid (8 Options)
        SectionHeader(
            title = "Deploy Tactical Defense Action",
            subtitle = "Select optimal containment countermeasure"
        )

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            defenseActions.forEach { action ->
                val icon = when (action.iconName) {
                    "Block" -> Icons.Default.Block
                    "Speed" -> Icons.Default.Speed
                    "Lan" -> Icons.Default.Lan
                    "Lock" -> Icons.Default.Lock
                    "Security" -> Icons.Default.Security
                    "Search" -> Icons.Default.Search
                    "Assessment" -> Icons.Default.Assessment
                    else -> Icons.Default.Warning
                }

                CyberCard(
                    modifier = Modifier.clickable { viewModel.executeDefenseAction(action) },
                    borderColor = CyberBorder,
                    backgroundColor = CyberSurfaceCard
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(CyberCyan.copy(alpha = 0.15f))
                                .border(1.dp, CyberCyan.copy(alpha = 0.4f), RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = icon, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(20.dp))
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = action.name,
                                    color = TextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${action.effectivenessScore}% Eff.",
                                    color = CyberEmerald,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Text(
                                text = action.description,
                                color = TextSecondary,
                                fontSize = 11.sp,
                                maxLines = 2
                            )
                        }
                    }
                }
            }
        }

        // Evaluation Result Modal / Card
        evaluation?.let { eval ->
            Spacer(modifier = Modifier.height(20.dp))
            CyberCard(
                borderColor = if (eval.finalScore >= 85) CyberEmerald else CyberAmber,
                backgroundColor = Color(0xFF07191A)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = CyberEmerald, modifier = Modifier.size(22.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "DEFENSE EVALUATION SCORECARD",
                            color = CyberEmerald,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Text(
                        text = "${eval.finalScore}/100",
                        color = CyberEmerald,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = eval.aiFeedback,
                    color = TextPrimary,
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )

                if (eval.badgeUnlocked != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(CyberAmber.copy(alpha = 0.2f))
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.Star, contentDescription = null, tint = CyberAmber, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Badge Unlocked: ${eval.badgeUnlocked}",
                            color = CyberAmber,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    ScoreMetric("Response", "${String.format("%.1f", eval.responseTimeSeconds)}s")
                    ScoreMetric("Accuracy", "${eval.detectionAccuracy.toInt()}%")
                    ScoreMetric("Damage Prev.", "${eval.damagePrevented.toInt()}%")
                    ScoreMetric("Quality", "${eval.decisionQuality.toInt()}%")
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun ScoreMetric(label: String, value: String) {
    Column {
        Text(text = label, color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Text(text = value, color = CyberCyan, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, fontFamily = FontFamily.Monospace)
    }
}
