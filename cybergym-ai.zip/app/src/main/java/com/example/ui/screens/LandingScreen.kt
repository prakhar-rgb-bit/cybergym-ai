package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CyberCard
import com.example.ui.components.CyberPrimaryButton
import com.example.ui.components.CyberSecondaryButton
import com.example.ui.components.LivePulseDot
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberBorderGlow
import com.example.ui.theme.CyberCrimson
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberEmerald
import com.example.ui.theme.CyberPurple
import com.example.ui.theme.CyberSurfaceCard
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.CyberGymViewModel
import com.example.viewmodel.ScreenRoute

@Composable
fun LandingScreen(
    viewModel: CyberGymViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Platform Intelligence Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(CyberBorderGlow.copy(alpha = 0.3f))
                .border(1.dp, CyberCyan.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = CyberCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "CyberGym AI | Network Defense Intelligence",
                        color = CyberCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
                LivePulseDot(label = "AI MODEL ONLINE")
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Hero Brand Title
        Text(
            text = "CYBERGYM AI",
            fontSize = 32.sp,
            fontWeight = FontWeight.Black,
            color = TextPrimary,
            letterSpacing = 2.sp,
            fontFamily = FontFamily.Monospace
        )
        Text(
            text = "Predict the Attack. Prepare the Defense.",
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            color = CyberCyan,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = "AI-Powered Network Attack Forecasting & Cyber Defense Platform that transforms raw network telemetry into predictive security intelligence before attacks occur.",
            fontSize = 13.sp,
            color = TextSecondary,
            textAlign = TextAlign.Center,
            lineHeight = 18.sp,
            modifier = Modifier.padding(horizontal = 8.dp)
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Primary Action CTAs
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            CyberPrimaryButton(
                text = "Launch CyberGym",
                icon = Icons.Default.Hub,
                onClick = { viewModel.navigateTo(ScreenRoute.CYBER_GYM) },
                modifier = Modifier.weight(1f),
                testTag = "launch_cybergym_button"
            )
            CyberSecondaryButton(
                text = "One-Click Demo",
                icon = Icons.Default.PlayArrow,
                onClick = { viewModel.navigateTo(ScreenRoute.LIVE_DEMO) },
                modifier = Modifier.weight(1f),
                testTag = "explore_demo_button"
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        CyberSecondaryButton(
            text = "View AI Forecast Engine",
            icon = Icons.Default.Psychology,
            onClick = { viewModel.navigateTo(ScreenRoute.FORECAST) },
            modifier = Modifier.fillMaxWidth(),
            testTag = "view_forecast_button"
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Core Pipeline Architecture
        CyberCard(
            borderColor = CyberCyan.copy(alpha = 0.5f),
            backgroundColor = CyberSurfaceCard
        ) {
            Text(
                text = "PREDICTIVE AI SECURITY PIPELINE",
                color = CyberCyan,
                fontSize = 12.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 1.sp,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(12.dp))

            PipelineStepItem("1. NETWORK TRAFFIC", "Real-time & simulated flow packet stream", Icons.Default.Speed, CyberCyan)
            PipelineArrow()
            PipelineStepItem("2. AI FEATURE EXTRACTION", "14 dimensional statistical flow metrics", Icons.Default.BarChart, CyberPurple)
            PipelineArrow()
            PipelineStepItem("3. ISOLATION FOREST ANOMALY", "Unsupervised anomaly detection scoring (0-100)", Icons.Default.TrendingUp, CyberAmber)
            PipelineArrow()
            PipelineStepItem("4. ATTACK FORECAST & XAI", "Multi-class classification & explainable reasons", Icons.Default.Psychology, CyberCrimson)
            PipelineArrow()
            PipelineStepItem("5. CYBER GYM BLUE DEFENSE", "Interactive tactical response & AI evaluation", Icons.Default.Shield, CyberEmerald)
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Feature Grid Cards
        FeatureCard(
            title = "Proactive Attack Forecasting",
            description = "Predicts DDoS, Port Scans, Brute Force, and Data Exfiltration 2–5 minutes before network degradation.",
            icon = Icons.Default.Psychology,
            accentColor = CyberCyan
        )

        Spacer(modifier = Modifier.height(10.dp))

        FeatureCard(
            title = "Explainable AI (XAI)",
            description = "Natural language justification explaining the exact flow vectors that triggered the threat prediction.",
            icon = Icons.Default.AutoAwesome,
            accentColor = CyberPurple
        )

        Spacer(modifier = Modifier.height(10.dp))

        FeatureCard(
            title = "Red vs Blue Cyber Gym",
            description = "Simulate offensive attack vectors and test defensive countermeasures on an interactive virtual range.",
            icon = Icons.Default.Hub,
            accentColor = CyberEmerald
        )

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun PipelineStepItem(
    title: String,
    subtitle: String,
    icon: ImageVector,
    color: Color
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(CyberSurfaceVariant.copy(alpha = 0.5f))
            .border(1.dp, CyberBorder, RoundedCornerShape(8.dp))
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(color.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column {
            Text(text = title, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            Text(text = subtitle, color = TextSecondary, fontSize = 11.sp)
        }
    }
}

@Composable
private fun PipelineArrow() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text = "▼", color = CyberCyan, fontSize = 12.sp)
    }
}

@Composable
private fun FeatureCard(
    title: String,
    description: String,
    icon: ImageVector,
    accentColor: Color
) {
    CyberCard(borderColor = CyberBorder) {
        Row(verticalAlignment = Alignment.Top) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(accentColor.copy(alpha = 0.15f))
                    .border(1.dp, accentColor.copy(alpha = 0.4f), RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(22.dp))
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(text = title, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(2.dp))
                Text(text = description, color = TextSecondary, fontSize = 12.sp, lineHeight = 16.sp)
            }
        }
    }
}
