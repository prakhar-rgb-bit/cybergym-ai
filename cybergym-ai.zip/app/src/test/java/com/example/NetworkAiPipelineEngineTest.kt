package com.example

import com.example.engine.NetworkAiPipelineEngine
import com.example.model.AttackType
import com.example.model.CapturedPacket
import com.example.model.RiskLevel
import com.example.model.Severity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class NetworkAiPipelineEngineTest {

    @Test
    fun `test pipeline under normal baseline traffic`() {
        val normalPackets = listOf(
            CapturedPacket(
                id = 1L,
                packetNumber = 1L,
                timestamp = "12:00:01.000",
                sourceIp = "192.168.1.50",
                destIp = "142.250.190.46",
                sourcePort = 54321,
                destPort = 443,
                protocol = "HTTPS/TCP",
                length = 240,
                tcpFlags = "ACK",
                riskLevel = RiskLevel.LOW,
                status = "NORMAL",
                anomalyScore = 5.0,
                info = "TLS Application Data"
            ),
            CapturedPacket(
                id = 2L,
                packetNumber = 2L,
                timestamp = "12:00:01.010",
                sourceIp = "192.168.1.50",
                destIp = "8.8.8.8",
                sourcePort = 54322,
                destPort = 53,
                protocol = "DNS",
                length = 78,
                tcpFlags = "",
                riskLevel = RiskLevel.LOW,
                status = "NORMAL",
                anomalyScore = 2.0,
                info = "Standard query A example.com"
            )
        )

        val result = NetworkAiPipelineEngine.executePipeline(
            observedPackets = normalPackets,
            currentPps = 140.0,
            currentBps = 95.0,
            failedConnections = 0,
            activeScenario = "NORMAL",
            isAttacking = false,
            totalCumulativePackets = 500L
        )

        // Stage 1 & 2: Observed & Features
        assertEquals(140.0, result.trafficFeature.packetRate, 0.01)

        // Stage 3 & 4: Baseline & Anomaly
        assertTrue("Anomaly score should be low under normal traffic", result.anomalyResult.anomalyScore < 30.0)

        // Stage 5: Attack Classification
        assertEquals(AttackType.NORMAL, result.classifiedAttack)

        // Stage 6: Attack Probability
        assertTrue("Attack probability should be low under normal traffic", result.attackProbability < 30.0)

        // Stage 7: Risk Score
        assertEquals(RiskLevel.LOW, result.securityRiskScore.threatLevel)

        // Stage 8: Alert
        assertNull("No alert should be dispatched under normal baseline", result.activeAlert)

        // Contributing features should be generated
        assertTrue("Contributing features should be present", result.contributingFeatures.isNotEmpty())
    }

    @Test
    fun `test pipeline under volumetric DDoS attack`() {
        val ddosPackets = (1..20).map { i ->
            CapturedPacket(
                id = i.toLong(),
                packetNumber = i.toLong(),
                timestamp = "12:05:0$i.000",
                sourceIp = "185.220.101.$i",
                destIp = "10.0.0.1",
                sourcePort = 40000 + i,
                destPort = 443,
                protocol = "TCP",
                length = 1200,
                tcpFlags = "SYN",
                riskLevel = RiskLevel.CRITICAL,
                status = "ATTACK_BURST",
                anomalyScore = 85.0,
                info = "SYN Flood volumetric burst"
            )
        }

        val result = NetworkAiPipelineEngine.executePipeline(
            observedPackets = ddosPackets,
            currentPps = 3800.0,
            currentBps = 2900.0,
            failedConnections = 65,
            activeScenario = "DDOS",
            isAttacking = true,
            totalCumulativePackets = 15000L
        )

        // Stage 4: High anomaly score
        assertTrue("DDoS anomaly score must be high", result.anomalyResult.anomalyScore >= 60.0)

        // Stage 5: Classification
        assertEquals(AttackType.DDOS, result.classifiedAttack)

        // Stage 6: Probability must be elevated
        assertTrue("DDoS attack probability must be high (>70%)", result.attackProbability >= 70.0)

        // Stage 7: High/Critical Risk
        assertTrue(
            "Risk must be HIGH or CRITICAL",
            result.securityRiskScore.threatLevel == RiskLevel.HIGH || result.securityRiskScore.threatLevel == RiskLevel.CRITICAL
        )

        // Stage 8: Security Alert Dispatched
        assertNotNull("Alert must be dispatched during DDoS attack", result.activeAlert)
        val alert = result.activeAlert!!
        assertTrue("Alert severity must be HIGH or CRITICAL", alert.severity == Severity.HIGH || alert.severity == Severity.CRITICAL)
        assertEquals(AttackType.DDOS, alert.attackType)

        // Contributing Features must explain the prediction
        val packetRateFeature = result.contributingFeatures.firstOrNull { it.featureName.contains("Packet Rate") }
        assertNotNull("Packet rate feature should be among drivers", packetRateFeature)
        assertTrue("Packet rate multiplier must be elevated", packetRateFeature!!.deviationMultiplier > 5.0)
    }

    @Test
    fun `test pipeline determinism`() {
        val packets = listOf(
            CapturedPacket(
                id = 101L,
                packetNumber = 101L,
                timestamp = "12:10:00.000",
                sourceIp = "10.0.0.5",
                destIp = "10.0.0.1",
                sourcePort = 50000,
                destPort = 22,
                protocol = "TCP",
                length = 64,
                tcpFlags = "SYN",
                riskLevel = RiskLevel.MEDIUM,
                status = "SUSPICIOUS",
                anomalyScore = 45.0,
                info = "SSH probe"
            )
        )

        val run1 = NetworkAiPipelineEngine.executePipeline(
            observedPackets = packets,
            currentPps = 800.0,
            currentBps = 120.0,
            failedConnections = 45,
            activeScenario = "PORT_SCAN",
            isAttacking = true,
            totalCumulativePackets = 2000L
        )

        val run2 = NetworkAiPipelineEngine.executePipeline(
            observedPackets = packets,
            currentPps = 800.0,
            currentBps = 120.0,
            failedConnections = 45,
            activeScenario = "PORT_SCAN",
            isAttacking = true,
            totalCumulativePackets = 2000L
        )

        assertEquals("Anomaly score must be strictly deterministic", run1.anomalyResult.anomalyScore, run2.anomalyResult.anomalyScore, 0.0001)
        assertEquals("Attack probability must be strictly deterministic", run1.attackProbability, run2.attackProbability, 0.0001)
        assertEquals("Classified attack must match", run1.classifiedAttack, run2.classifiedAttack)
        assertEquals("Risk score must match", run1.securityRiskScore.score, run2.securityRiskScore.score)
    }
}
